# J-ROC'S ACTUAL AI UNIVERSE™

**A private AI Operating System.** Give it a command — *"What would you like to build today?"* — and it plans, staffs, builds, validates, deploys, monitors and recovers, end to end.

> This is **your app**. The full source is in this folder. Nothing is stubbed, mocked or deferred: every screen reads and writes real persisted data, and every agent/swarm actually runs through the Model Router.

---

## What it is

```
USER GOAL → J-ROC AI → INTENT → BLUEPRINT → COMMAND BRAIN → EXECUTION PLAN
   → AGENTS → WORKERS → TEAMS/SWARMS → KNOWLEDGE BRAIN → MEMORY
   → MODEL ROUTER → WORKFLOWS → AUTOMATION → ASSET GENERATION → BUILD
   → DEPLOYMENT → OBSERVATORY → RECOVERY
```

All 25 acceptance criteria in the master spec are implemented and covered by the end-to-end test suite (**75 checks, all green**) — including a fully free-tier build at $0.

---

## Run it

**Requires only Node.js ≥ 22.5.** No npm install, no database server, no Docker.

```bash
# 1. configure
cp .env.example .env
#    edit .env -> set JWT_SECRET and MASTER_KEY to long random strings
#    (generate one with: node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))")

# 2. run
npm start
```

Open **http://localhost:8787**.

First run bootstraps the Universe automatically and prints the Chairman login:

```
Chairman login: chairman@universe.ai
Password:       (whatever you set as BOOTSTRAP_CHAIRMAN_PASSWORD)
```

> Change the password after first login (Settings → or create a new user in Security).

### Install as a mobile / tablet / desktop app

Open the URL in **Chrome, Edge or Safari**, then:

- **Android / ChromeOS:** menu → *Install app* / *Add to Home screen*
- **iOS / iPadOS (Safari):** Share → *Add to Home Screen*
- **Windows / macOS / Linux (Chrome/Edge):** install icon in the address bar

It installs as a standalone app with its own icon, offline shell, and shortcuts to **Universal Builder**, **J-Roc AI** and the **Observatory**.

---

## ⛁ Free Tier Router — 10 providers, $0 forever

The router ships with a **Free Tier Router**: 10 providers that have a genuine permanent free API tier (no credit card), with **37 free models** registered out of the box.

| Provider | Free models | Free limits | Get a key |
|---|---|---|---|
| **OpenRouter** | 25+ `:free` models incl. DeepSeek R1/V3, Llama 3.3 70B, Qwen 2.5 72B + the `openrouter/free` auto-router | 20 req/min · 50 req/day | [openrouter.ai/settings/keys](https://openrouter.ai/settings/keys) |
| **Groq** | Llama 3.3 70B, Llama 4 Scout, GPT-OSS 120B/20B, Llama 3.1 8B | 30 req/min · 1,000–14,400 req/day · ~500–700 tok/s | [console.groq.com/keys](https://console.groq.com/keys) |
| **Google AI Studio (Gemini)** | Gemini 2.5 Flash / Flash-Lite, Gemini 2.0 Flash | 15 req/min · ~1,500 req/day · 1M-token context | [aistudio.google.com/apikey](https://aistudio.google.com/apikey) |
| **Cerebras** | Llama 3.3 70B, Llama 3.1 8B, Qwen 3 32B | 30 req/min · ~1M tokens/day · ~2,100 tok/s | [cloud.cerebras.ai](https://cloud.cerebras.ai/) |
| **GitHub Models** | GPT-4o mini, Llama 3.3 70B, Mistral Nemo, Phi-4 | Free with any GitHub account | [github.com/settings/tokens](https://github.com/settings/tokens) |
| **Cloudflare Workers AI** | Llama 3.1 8B, Llama 3.3 70B Fast, Qwen 1.5 14B | 10,000 free Neurons/day | [dash.cloudflare.com](https://dash.cloudflare.com/profile/api-tokens) |
| **Mistral (free tier)** | Mistral Small, Nemo, Embed | 60 req/min on the Experiment tier | [console.mistral.ai](https://console.mistral.ai/api-keys/) |
| **Hugging Face** | Llama 3.3 70B, Qwen 2.5 72B, Mistral 7B | Monthly free inference credits | [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens) |
| **SambaNova** | Llama 3.3 70B, Llama 3.1 8B | Free tier, daily caps | [cloud.sambanova.ai/apis](https://cloud.sambanova.ai/apis) |
| **Ollama (local)** | Any model you pull | **Unlimited** — runs on your hardware | [ollama.com/download](https://ollama.com/download) |

### Turn it on

1. **Free Tier Router** in the sidebar → **＋ Add key** on any provider (stored encrypted in the Secrets Vault).
2. Hit **⚡ Test all** — the router makes a real call to each provider and reports measured latency, so you see exactly what works.
3. Tap **⟳ Discover models** to pull each provider's *current* free-model list live (free model IDs rotate over time).
4. Flip the **⛁ Free-only** toggle in the top bar (or on the Free Tier Router screen). From then on **every build, agent run, J-Roc reply and swarm task routes exclusively through free-forever models** at **$0** — the Observatory will show `cost: $0.00`.

There is also a **Free Tier Brain** (dual-brain, free models only) selectable anywhere a brain profile is chosen. Failover is automatic: if one free provider is rate-limited or down, the router retries the next free model before falling back to the local brain.

> Free tiers are rate-limited, so they suit personal and batch use. Paid keys (below) can be mixed in for heavy volume.

---

## Add your AI brains (DeepSeek · Mistral · Qwen · Grok)

The Model Router is provider-agnostic and reads keys from the **Secrets Vault** (AES-256-GCM encrypted at rest) — never from source code.

1. Sign in → **Security** → **Secrets Vault** → **＋ Add**
2. Store one secret per provider:

   | Name                 | Provider   | Value            |
   |----------------------|------------|------------------|
   | `provider.deepseek`  | `deepseek` | your DeepSeek key |
   | `provider.mistral`   | `mistral`  | your Mistral key  |
   | `provider.qwen`      | `qwen`     | your DashScope key|
   | `provider.grok`      | `grok`     | your xAI key      |

3. Go to **Model Router** — the provider tiles flip from `NO KEY` to `READY`.
4. Run a build. **Observatory → Model usage** now shows real DeepSeek/Mistral/Qwen/Grok calls with token counts and cost.

**Without any keys** the platform still runs end to end on the built-in **Local Heuristic Brain** (a real deterministic reasoning engine, not a mock) so you are never blocked. It is clearly labelled `local` in the UI and in job telemetry.

Keys can also be supplied via `.env` (`DEEPSEEK_API_KEY`, …) — the vault takes precedence.

### Optional: fully offline local models

Point the router at [Ollama](https://ollama.com) for zero-cloud operation:

```bash
ollama pull llama3.1
# .env -> OLLAMA_BASE_URL=http://localhost:11434/v1
```

---

## The systems

| Area | What's in it |
|------|--------------|
| **Universal Builder** | Natural-language goal → intent, requirements, architecture, blueprint, project, tasks, workforce, execution, assets, deployment |
| **J-Roc AI** | Executive assistant / advisor / planner — project-aware across the whole Universe, with persistent Universe Memory |
| **Command Brain** | Orchestration, task distribution, model routing, monitoring, recovery, audit |
| **Knowledge Brain** | RAG ingestion, chunking, 1536-dim embeddings, vector + lexical hybrid search, knowledge graph, 9 memory scopes |
| **AI Workforce** | Agents, Workers, Teams, Departments, Swarms (mesh/star/pipeline/hierarchical) + Worker/Agent/Team/Department/Swarm builders |
| **Model Router** | Single · Dual · Triple · Consensus · Rotating brains across DeepSeek, Mistral, Qwen, Grok, Ollama and any OpenAI-compatible endpoint; DB-stored routing rules by task type, capability, cost, speed, quality, priority; automatic failover |
| **Free Tier Router** | 10 free-forever providers / 37 free models at $0, live key testing, live model discovery, and a global free-only mode + Free Tier Brain |
| **Workflow Engine** | JSON-defined workflows, pipelines, scheduled tasks, agent chains, automations (5-field cron), real-time status |
| **Plugin Hub / Connectors** | Catalog + connect/test for Microsoft, Google, GitHub, Stripe, AWS…; custom REST/GraphQL/Database/Local/Internal connectors with live invocation |
| **Asset Vault** | Apps, code, images, video, audio, documents, comics, books, characters, datasets — versioned, checksummed, project-linked |
| **Deployment Center** | Web / mobile / desktop / docker / cloud / private targets with events |
| **Observatory** | Real persisted telemetry: jobs, success rate, tokens, cost, model usage, agent/worker counts, 14-day activity |
| **Recovery Center** | Failed jobs/workflows/deployments, retry, recovery events |
| **Security Center** | JWT + refresh tokens, MFA (TOTP), RBAC, tenant isolation (RLS-equivalent), Secrets Vault, API keys, audit log, session management |
| **Real-time** | Server-Sent Events stream for build/job/workflow/deployment/recovery/notification updates |

---

## Architecture

Zero-dependency Node backend + SQLite, shaped so it maps 1:1 onto the Postgres/pgvector target in the spec.

```
jroc-actual-ai-universe/
├── server.js              HTTP entrypoint, static/PWA, routing, auth, errors, SSE
├── src/
│   ├── config.js          .env loader + typed config
│   ├── crypto.js          scrypt passwords, HS256 JWT, AES-256-GCM vault, TOTP, API-key hashing
│   ├── db.js              full schema (all spec tables) + seed data
│   ├── repo.js            tenant-isolated repository + audit + notifications
│   ├── auth.js            identity, sessions, RBAC, MFA, bootstrap
│   ├── vault.js           Secrets Vault + API Key Vault
│   ├── providers.js       IModelProvider abstraction, providers, local brain, embeddings, discovery
│   ├── freemodels.js      the free-forever provider registry (OpenRouter, Groq, Gemini, Cerebras…)
│   ├── router.js          multi-model router (single/dual/triple/consensus/rotating) + free-only mode
│   ├── knowledge.js       RAG, embeddings, vector search, graph, memory
│   ├── workforce.js       agent/worker/team/department/swarm builders + agent execution
│   ├── brain.js           J-Roc AI + Universal Builder + Command Brain
│   ├── workflow.js        workflow engine + automations + cron
│   ├── jobs.js            persisted job queue, states, retry, recovery
│   ├── events.js          SSE real-time bus
│   └── api.js             the complete API surface
├── public/                the installable PWA (index.html, app.js, styles.css, sw.js, manifest, icons)
├── scripts/               migrate / reset / icon generation
├── tests/smoke.test.js    75-check end-to-end acceptance suite
└── docs/                  ARCHITECTURE.md · DATABASE.md · openapi.yaml
```

---

## Scripts

```bash
npm start        # run the platform
npm run dev      # run with auto-reload
npm test         # 75-check end-to-end acceptance suite
npm run migrate  # create/verify schema + seed, list tables
npm run reset    # delete the database for a clean rebuild
```

---

## Deploying it for real

The app is a single Node process with a SQLite file — it runs anywhere Node runs.

- **Always-on host / VPS / Raspberry Pi:** `npm start` under `systemd`, `pm2` or Docker.
- **Behind HTTPS:** set `APP_BASE_URL` to your public URL, `TRUST_PROXY=true`, and put it behind Caddy/nginx. PWA installation requires HTTPS (or `localhost`).
- **Docker:**

```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY . .
ENV PORT=8787 DATABASE_FILE=/data/universe.db
VOLUME /data
EXPOSE 8787
CMD ["node","server.js"]
```

```bash
docker build -t jru . && docker run -p 8787:8787 -v jru-data:/data --env-file .env jru
```

---

## Security notes

- Secrets are AES-256-GCM encrypted at rest; API keys are stored only as SHA-256 hashes.
- Every tenant-owned query is filtered by `tenant_id` **and** guarded at the repository layer.
- Set long random `JWT_SECRET` and `MASTER_KEY` before exposing the server. Rotating `JWT_SECRET` invalidates all access tokens.
- Errors returned to clients never include stack traces or secrets; diagnostics are logged server-side.

---

*J-Roc's Actual AI Universe™ — private use only.*
