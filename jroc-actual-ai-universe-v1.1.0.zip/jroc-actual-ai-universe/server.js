'use strict';
/**
 * server.js - J-Roc's Actual AI Universe(TM) HTTP entrypoint.
 * Zero dependencies. Serves the PWA, the REST API, the SSE real-time stream,
 * enforces auth/RBAC, structured errors, security headers and rate limiting.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');

const config = require('./src/config');
const db = require('./src/db');
const repo = require('./src/repo');
const auth = require('./src/auth');
const vault = require('./src/vault');
const events = require('./src/events');
const jobs = require('./src/jobs');
const workflow = require('./src/workflow');
const { routes } = require('./src/api');
require('./src/brain'); // registers the build job handler
require('./src/workforce');

const PUBLIC_DIR = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};

/* ------------------------- compile route matchers ------------------------- */
const compiled = routes.map((r) => {
  const keys = [];
  const pattern = r.path.replace(/:([A-Za-z0-9_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; });
  return { ...r, regex: new RegExp(`^${pattern}$`), keys };
});

/* ----------------------------- rate limiting ------------------------------ */
const buckets = new Map();
function rateLimit(key, max = 300, windowMs = 60000) {
  const now = Date.now();
  const b = buckets.get(key) || { count: 0, reset: now + windowMs };
  if (now > b.reset) { b.count = 0; b.reset = now + windowMs; }
  b.count++;
  buckets.set(key, b);
  return b.count <= max;
}

function send(res, status, payload, headers = {}) {
  const body = typeof payload === 'string' ? payload : JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    ...headers,
  });
  res.end(body);
}

function sendError(res, status, code, message, traceId) {
  send(res, status, { error: { code, message, traceId } });
}

function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('Payload too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      const raw = Buffer.concat(chunks).toString('utf8');
      try { resolve(raw ? JSON.parse(raw) : {}); } catch { resolve({ _raw: raw }); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) { sendError(res, 403, 'FORBIDDEN', 'Forbidden', null); return; }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    // SPA fallback for client-side routes.
    filePath = path.join(PUBLIC_DIR, 'index.html');
    if (!fs.existsSync(filePath)) { sendError(res, 404, 'NOT_FOUND', 'Not found', null); return; }
  }
  const ext = path.extname(filePath).toLowerCase();
  const data = fs.readFileSync(filePath);
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': data.length,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
  });
  res.end(data);
}

/* -------------------------------- request --------------------------------- */
async function handle(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = decodeURIComponent(url.pathname);
  const ip = (config.TRUST_PROXY && req.headers['x-forwarded-for']) || req.socket.remoteAddress || '';

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // ---- health ----
  if (pathname === '/health' || pathname === '/api/health') {
    return send(res, 200, { status: 'ok', service: "J-Roc's Actual AI Universe", time: new Date().toISOString(), uptimeSec: Math.round(process.uptime()) });
  }

  // ---- real-time SSE ----
  if (pathname === '/api/v1/events') {
    const queryToken = url.searchParams.get('token');
    const identity = auth.authenticate({
      authorization: req.headers.authorization || (queryToken ? `Bearer ${queryToken}` : undefined),
      apiKey: req.headers['x-api-key'] || url.searchParams.get('apiKey'),
    });
    if (!identity) return sendError(res, 401, 'UNAUTHORIZED', 'Authentication required.', null);
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    const unsub = events.subscribe(identity.tenantId, identity.userId, res);
    req.on('close', unsub);
    return;
  }

  // ---- API ----
  if (pathname.startsWith('/api/')) {
    if (!rateLimit(ip + ':' + pathname, 600)) return sendError(res, 429, 'RATE_LIMITED', 'Too many requests.', null);
    const match = compiled.find((r) => r.method === req.method && r.regex.test(pathname));
    if (!match) {
      // method mismatch detection
      const pathOnly = compiled.find((r) => r.regex.test(pathname));
      if (pathOnly) return sendError(res, 405, 'METHOD_NOT_ALLOWED', `${req.method} not allowed on ${pathname}.`, null);
      return sendError(res, 404, 'NOT_FOUND', `No route for ${req.method} ${pathname}.`, null);
    }
    const values = match.regex.exec(pathname).slice(1);
    const params = Object.fromEntries(match.keys.map((k, i) => [k, values[i]]));
    let body = {};
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      try { body = await readBody(req); } catch (e) { return sendError(res, 413, 'PAYLOAD_TOO_LARGE', e.message, null); }
    }
    const query = Object.fromEntries(url.searchParams.entries());

    let identity = null;
    if (match.perm) {
      identity = auth.authenticate({ authorization: req.headers.authorization, apiKey: req.headers['x-api-key'] });
      if (!identity) return sendError(res, 401, 'UNAUTHORIZED', 'Authentication required.', null);
      if (match.perm !== 'authenticated' && !auth.hasPermission(identity, match.perm)) {
        return sendError(res, 403, 'FORBIDDEN', `Missing permission: ${match.perm}`, null);
      }
    } else {
      identity = auth.authenticate({ authorization: req.headers.authorization, apiKey: req.headers['x-api-key'] });
    }

    const ctx = {
      identity, tenantId: identity?.tenantId || null, user: null,
      body, query, params, ip, userAgent: req.headers['user-agent'] || '',
      bearer: req.headers.authorization || '',
      limit: Math.min(Number(query.limit || 100), 1000),
      offset: Number(query.offset || 0),
      vaultLookup: identity?.tenantId ? vault.lookupFor(identity.tenantId) : (() => null),
    };

    try {
      const result = await match.handler(ctx);
      if (result && result.error && !result.ok) {
        const status = result.error === 'INVALID_CREDENTIALS' || result.error === 'MFA_INVALID' ? 401
          : result.error === 'MFA_REQUIRED' ? 401
            : result.error === 'NOT_FOUND' ? 404
              : result.error === 'FORBIDDEN' ? 403 : 400;
        return sendError(res, status, result.error, result.message || result.error, null);
      }
      return send(res, 200, result ?? { ok: true });
    } catch (err) {
      console.error(`[api] ${req.method} ${pathname}`, err);
      const traceId = require('node:crypto').randomUUID();
      return sendError(res, 500, 'INTERNAL_ERROR', 'An internal error occurred. Diagnostics logged server-side.', traceId);
    }
  }

  // ---- static / PWA ----
  if (req.method === 'GET') return serveStatic(req, res, pathname);
  sendError(res, 405, 'METHOD_NOT_ALLOWED', 'Method not allowed.', null);
}

/* --------------------------------- boot ----------------------------------- */
function boot() {
  db.connect();
  const created = auth.bootstrap();
  if (!config.JWT_SECRET || !config.MASTER_KEY) {
    console.warn('[security] JWT_SECRET / MASTER_KEY not set - using development fallbacks. Set them in .env before exposing this server.');
  }
  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      console.error('[fatal]', err);
      if (!res.headersSent) sendError(res, 500, 'INTERNAL_ERROR', 'Internal error.', null);
    });
  });
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\n  Port ${config.PORT} is already in use. Set PORT in .env to a free port and retry.\n`);
      process.exit(1);
    }
    throw err;
  });
  server.listen(config.PORT, () => {
    console.log(`\n  J-ROC'S ACTUAL AI UNIVERSE(TM)`);
    console.log(`  ------------------------------------------------`);
    console.log(`  Listening:   ${config.APP_BASE_URL}`);
    console.log(`  Database:    ${config.DATABASE_FILE}`);
    console.log(`  API:         ${config.APP_BASE_URL}/api/v1`);
    console.log(`  Health:      ${config.APP_BASE_URL}/health`);
    if (created) {
      console.log(`\n  First-run bootstrap complete.`);
      console.log(`  Chairman login: ${created.email}`);
      console.log(`  Password:       (BOOTSTRAP_CHAIRMAN_PASSWORD)`);
    }
    console.log('');
  });

  // Automations scheduler (60s tick).
  const tick = setInterval(() => {
    try {
      for (const t of repo.rows('SELECT id FROM tenants')) workflow.tickAutomations(t.id);
    } catch (e) { console.error('[automations]', e.message); }
  }, 60000);
  if (tick.unref) tick.unref();

  const shutdown = () => {
    console.log('\nShutting down...');
    clearInterval(tick);
    jobs.stop();
    server.close(() => { db.close(); process.exit(0); });
    setTimeout(() => process.exit(0), 3000);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  return server;
}

if (require.main === module) boot();

module.exports = { boot, handle };
