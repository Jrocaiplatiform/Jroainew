@echo off
REM J-Roc's Actual AI Universe(TM) - launcher (Windows)
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required ^(^>= 22.5^). Install from https://nodejs.org
  pause
  exit /b 1
)

if not exist .env (
  echo No .env found - creating one from .env.example with generated secrets.
  copy .env.example .env >nul
  for /f "delims=" %%A in ('node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"') do set JWT=%%A
  for /f "delims=" %%A in ('node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"') do set MK=%%A
  node -e "const f='.env',fs=require('fs');let s=fs.readFileSync(f,'utf8');s=s.replace(/^JWT_SECRET=.*/m,'JWT_SECRET='+process.argv[1]).replace(/^MASTER_KEY=.*/m,'MASTER_KEY='+process.argv[2]);fs.writeFileSync(f,s)" "%JWT%" "%MK%"
  echo Generated JWT_SECRET and MASTER_KEY.
  echo Default login: chairman@universe.ai / changeme  ^(change it!^)
)

echo Starting J-Roc's Actual AI Universe(TM)...
node server.js
pause
