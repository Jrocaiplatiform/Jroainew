'use strict';
/**
 * config.js - zero-dependency .env loader + typed configuration surface.
 * Reads .env (if present), then process.env, and exposes a frozen config object.
 */
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  const text = fs.readFileSync(file, 'utf8');
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadDotEnv();

function str(name, def) {
  const v = process.env[name];
  return v === undefined || v === '' ? def : v;
}
function int(name, def) {
  const v = parseInt(process.env[name] ?? '', 10);
  return Number.isFinite(v) ? v : def;
}
function bool(name, def) {
  const v = (process.env[name] ?? '').toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(v)) return true;
  if (['0', 'false', 'no', 'off'].includes(v)) return false;
  return def;
}

const DATABASE_FILE = str('DATABASE_FILE', './data/universe.db');

const config = Object.freeze({
  ROOT,
  NODE_ENV: str('NODE_ENV', 'development'),
  PORT: int('PORT', 8787),
  APP_BASE_URL: str('APP_BASE_URL', 'http://localhost:' + int('PORT', 8787)),
  TRUST_PROXY: bool('TRUST_PROXY', false),
  DATABASE_FILE: path.isAbsolute(DATABASE_FILE)
    ? DATABASE_FILE
    : path.join(ROOT, DATABASE_FILE),
  MASTER_KEY: str('MASTER_KEY', ''),
  JWT_SECRET: str('JWT_SECRET', ''),
  ACCESS_TOKEN_TTL: int('ACCESS_TOKEN_TTL', 3600),
  REFRESH_TOKEN_TTL: int('REFRESH_TOKEN_TTL', 60 * 60 * 24 * 30),
  BOOTSTRAP_TENANT_NAME: str('BOOTSTRAP_TENANT_NAME', "J-Roc's Actual AI Universe"),
  BOOTSTRAP_CHAIRMAN_EMAIL: str('BOOTSTRAP_CHAIRMAN_EMAIL', 'chairman@universe.ai'),
  BOOTSTRAP_CHAIRMAN_PASSWORD: str('BOOTSTRAP_CHAIRMAN_PASSWORD', 'changeme'),
  providers: {
    deepseek: {
      id: 'deepseek', label: 'DeepSeek', kind: 'cloud',
      apiKey: str('DEEPSEEK_API_KEY', ''),
      baseUrl: str('DEEPSEEK_BASE_URL', 'https://api.deepseek.com/v1'),
      model: str('DEEPSEEK_MODEL', 'deepseek-chat'),
    },
    mistral: {
      id: 'mistral', label: 'Mistral', kind: 'cloud',
      apiKey: str('MISTRAL_API_KEY', ''),
      baseUrl: str('MISTRAL_BASE_URL', 'https://api.mistral.ai/v1'),
      model: str('MISTRAL_MODEL', 'mistral-large-latest'),
    },
    qwen: {
      id: 'qwen', label: 'Qwen', kind: 'cloud',
      apiKey: str('QWEN_API_KEY', ''),
      baseUrl: str('QWEN_BASE_URL', 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1'),
      model: str('QWEN_MODEL', 'qwen-max'),
    },
    grok: {
      id: 'grok', label: 'Grok (xAI)', kind: 'cloud',
      apiKey: str('GROK_API_KEY', ''),
      baseUrl: str('GROK_BASE_URL', 'https://api.x.ai/v1'),
      model: str('GROK_MODEL', 'grok-2-latest'),
    },
    ollama: {
      id: 'ollama', label: 'Ollama (local)', kind: 'local',
      apiKey: str('OLLAMA_API_KEY', 'ollama'),
      baseUrl: str('OLLAMA_BASE_URL', 'http://localhost:11434/v1'),
      model: str('OLLAMA_MODEL', 'llama3.1'),
    },
    compat: {
      id: 'compat', label: 'OpenAI-compatible', kind: 'cloud',
      apiKey: str('OPENAI_COMPAT_API_KEY', ''),
      baseUrl: str('OPENAI_COMPAT_BASE_URL', ''),
      model: str('OPENAI_COMPAT_MODEL', ''),
    },
  },
});

module.exports = config;
