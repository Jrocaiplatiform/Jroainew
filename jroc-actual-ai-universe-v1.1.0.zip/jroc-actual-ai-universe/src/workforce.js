'use strict';
/**
 * workforce.js - the AI Workforce Center (spec section 8).
 * Worker/Agent/Team/Department/Swarm builders and the execution of agent runs.
 */
const repo = require('./repo');
const router = require('./router');
const knowledge = require('./knowledge');
const providers = require('./providers');
const events = require('./events');
const { uuid } = require('./crypto');

/* ------------------------------- builders --------------------------------- */
function createWorker(tenantId, data) {
  return repo.insert('workers', tenantId, {
    agent_id: data.agentId || null,
    department_id: data.departmentId || null,
    name: data.name || 'Worker',
    role: data.role || 'worker',
    skills: JSON.stringify(data.skills || []),
    permissions: JSON.stringify(data.permissions || []),
    brain_profile: data.brainProfile || 'Executive Brain',
    memory_scope: data.memoryScope || 'Worker Memory',
    status: 'idle',
    config: JSON.stringify(data.config || {}),
    updated_at: new Date().toISOString(),
  });
}

function createAgent(tenantId, data) {
  return repo.insert('agents', tenantId, {
    name: data.name || 'Agent',
    role: data.role || 'generalist',
    system_prompt: data.systemPrompt || 'You are an agent in J-Roc\'s Actual AI Universe.',
    brain_profile: data.brainProfile || 'Executive Brain',
    memory_scope: data.memoryScope || 'Agent Memory',
    project_id: data.projectId || null,
    status: 'idle',
    config: JSON.stringify(data.config || {}),
    updated_at: new Date().toISOString(),
  });
}

function createTeam(tenantId, data) {
  const team = repo.insert('teams', tenantId, {
    department_id: data.departmentId || null,
    name: data.name || 'Team',
    purpose: data.purpose || '',
    strategy: data.strategy || 'parallel',
    status: 'active',
    config: JSON.stringify(data.config || {}),
  });
  for (const m of data.members || []) addTeamMember(tenantId, team.id, m.type, m.id);
  return team;
}

function addTeamMember(tenantId, teamId, type, memberId) {
  repo.db().prepare('INSERT OR IGNORE INTO team_members (team_id, member_type, member_id) VALUES (?,?,?)').run(teamId, type, memberId);
}

function createDepartment(tenantId, data) {
  const dept = repo.insert('departments', tenantId, {
    name: data.name || 'Department',
    mandate: data.mandate || '',
    status: 'active',
  });
  for (const m of data.members || []) {
    repo.db().prepare('INSERT OR IGNORE INTO department_members (department_id, member_type, member_id) VALUES (?,?,?)').run(dept.id, m.type, m.id);
  }
  return dept;
}

function createSwarm(tenantId, data) {
  const swarm = repo.insert('swarms', tenantId, {
    project_id: data.projectId || null,
    name: data.name || 'Swarm',
    objective: data.objective || '',
    topology: data.topology || 'mesh',
    status: 'idle',
    config: JSON.stringify(data.config || {}),
  });
  for (const w of data.workers || []) {
    repo.db().prepare('INSERT OR IGNORE INTO swarm_members (swarm_id, worker_id, role) VALUES (?,?,?)').run(swarm.id, w.id, w.role || 'member');
  }
  return swarm;
}

/**
 * Provision a full workforce for a build from a plan's suggested agents/workers.
 * Wires workers to agents, groups them into a team, a department and a swarm.
 */
function provisionWorkforce(tenantId, { projectId, plan }) {
  const agents = [];
  for (const a of plan.suggestedAgents || []) {
    agents.push(createAgent(tenantId, { ...a, projectId }));
  }
  const workers = [];
  const suggested = plan.suggestedWorkers?.length ? plan.suggestedWorkers : [{ name: 'General Worker', role: 'worker', skills: [] }];
  suggested.forEach((w, i) => {
    workers.push(createWorker(tenantId, { ...w, agentId: agents[i % Math.max(agents.length, 1)]?.id || null }));
  });

  const dept = createDepartment(tenantId, {
    name: `${plan.goal.slice(0, 40) || 'Build'} Department`,
    mandate: `Deliver: ${plan.goal}`,
    members: [...agents.map((a) => ({ type: 'agent', id: a.id })), ...workers.map((w) => ({ type: 'worker', id: w.id }))],
  });
  for (const w of workers) repo.update('workers', tenantId, w.id, { department_id: dept.id });

  const team = createTeam(tenantId, {
    departmentId: dept.id,
    name: `${plan.goal.slice(0, 40) || 'Build'} Team`,
    purpose: plan.intent || plan.goal,
    strategy: 'pipeline',
    members: [...agents.map((a) => ({ type: 'agent', id: a.id })), ...workers.map((w) => ({ type: 'worker', id: w.id }))],
  });

  const swarm = createSwarm(tenantId, {
    projectId,
    name: `${plan.goal.slice(0, 40) || 'Build'} Swarm`,
    objective: plan.goal,
    topology: 'mesh',
    workers: workers.map((w, i) => ({ id: w.id, role: i === 0 ? 'coordinator' : 'member' })),
  });

  events.publish(tenantId, 'workforce', { agents: agents.length, workers: workers.length, team: team.id, swarm: swarm.id });
  return { agents, workers, team, department: dept, swarm };
}

/* ----------------------------- agent execution ---------------------------- */
/**
 * Run an agent against a task. Grounds in knowledge + memory, routes through the
 * Model Router, and returns the deliverable plus usage telemetry.
 */
async function runAgent({ tenantId, agent, task, projectId = null, vaultLookup, brainProfile = null, context = '', freeOnly = false }) {
  const started = Date.now();
  const grounding = await knowledge.contextFor({ tenantId, query: `${task}\n${projectId || ''}`, limit: 4, vaultLookup });
  const memories = await knowledge.recall({ tenantId, query: task, ownerId: agent.id, limit: 3, vaultLookup });
  const memoryText = memories.filter((m) => m.score > 0.05).map((m) => `- ${m.memory.content}`).join('\n');

  const messages = [
    { role: 'system', content: agent.system_prompt || 'You are an agent in J-Roc\'s Actual AI Universe. Deliver complete, production-grade work.' },
  ];
  if (grounding) messages.push({ role: 'system', content: `Knowledge Brain context:\n${grounding}` });
  if (memoryText) messages.push({ role: 'system', content: `Memory:\n${memoryText}` });
  if (context) messages.push({ role: 'system', content: `Prior work context:\n${context}` });
  messages.push({ role: 'user', content: task });

  const taskType = classify(task);
  const routed = await router.route({
    tenantId, taskType,
    brainProfile: freeOnly ? 'Free Tier Brain' : (brainProfile || agent.brain_profile || 'Executive Brain'),
    messages, vaultLookup, freeOnly,
  });

  repo.update('agents', tenantId, agent.id, { status: 'active', updated_at: new Date().toISOString() });
  const result = {
    content: routed.primary.content,
    brain: brainProfile || agent.brain_profile,
    mode: routed.mode,
    model: `${routed.primary.provider}/${routed.primary.model}`,
    models: routed.models,
    tokensIn: routed.primary.tokensIn || 0,
    tokensOut: routed.primary.tokensOut || 0,
    degraded: Boolean(routed.primary.degraded),
    freeOnly: Boolean(routed.freeOnly),
    durationMs: Date.now() - started,
    cost: estimateCost(routed.primary, { freeOnly: routed.freeOnly }),
    alternatives: routed.results.length > 1 ? routed.results.map((r) => ({ model: `${r.provider}/${r.model}`, content: r.content })) : undefined,
  };
  repo.update('agents', tenantId, agent.id, { status: 'idle', updated_at: new Date().toISOString() });
  return result;
}

function classify(text) {
  const t = String(text).toLowerCase();
  if (/code|api|implement|function|bug|software|backend|frontend|database/.test(t)) return 'coding';
  if (/research|investigate|find|source|study|compare/.test(t)) return 'research';
  if (/plan|roadmap|schedule|strategy|organi[sz]e/.test(t)) return 'planning';
  if (/design|creative|story|brand|content|copy|comic/.test(t)) return 'creativity';
  if (/validate|review|test|qa|verify|audit/.test(t)) return 'validation';
  if (/write|draft|article|document|summary/.test(t)) return 'writing';
  if (/reason|why|logic|prove|solve/.test(t)) return 'reasoning';
  return 'analysis';
}

/**
 * Real cost accounting. Zero for free-tier models, the local brain, and any
 * free-only run; otherwise priced from the model's own cost_in/cost_out.
 */
function estimateCost(res, { freeOnly = false } = {}) {
  if (freeOnly || res.degraded) return 0;
  let row = null;
  try {
    row = repo.row('SELECT cost_in, cost_out, free_tier FROM models WHERE provider = ? AND model_id = ?', res.provider, res.model);
  } catch { row = null; }
  if (row && row.free_tier === 1) return 0;
  const inRate = row ? row.cost_in : 1;
  const outRate = row ? row.cost_out : 3;
  return Number((((res.tokensIn || 0) / 1e6) * inRate + ((res.tokensOut || 0) / 1e6) * outRate).toFixed(6));
}

module.exports = {
  createWorker, createAgent, createTeam, createDepartment, createSwarm,
  addTeamMember, provisionWorkforce, runAgent, classify, estimateCost,
};
