'use strict';
/**
 * api.js - the complete HTTP API surface (spec sections 24-25) plus the
 * supporting systems (observatory, recovery, security, assets, prompts...).
 * Handlers receive a context object and return a JSON-serialisable value.
 */
const repo = require('./repo');
const auth = require('./auth');
const vault = require('./vault');
const brain = require('./brain');
const router = require('./router');
const providers = require('./providers');
const knowledge = require('./knowledge');
const workforce = require('./workforce');
const workflow = require('./workflow');
const jobs = require('./jobs');
const events = require('./events');
const config = require('./config');
const freemodels = require('./freemodels');
const { uuid } = require('./crypto');

/* ------------------------------- helpers ---------------------------------- */
function j(v) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? null); } catch { return null; } }
function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }

const routes = [];
function route(method, path, perm, handler) { routes.push({ method, path, perm, handler }); }

/* ============================== AUTH ====================================== */
route('POST', '/api/v1/auth/login', null, async (c) => {
  const r = await auth.login({ email: c.body.email, password: c.body.password, totp: c.body.totp, userAgent: c.userAgent, ip: c.ip });
  return r;
});
route('POST', '/api/v1/auth/logout', null, (c) => auth.logout({ refreshToken: c.body.refreshToken, accessToken: c.bearer }));
route('POST', '/api/v1/auth/refresh', null, (c) => auth.refresh({ refreshToken: c.body.refreshToken, userAgent: c.userAgent, ip: c.ip }));
route('POST', '/api/v1/auth/mfa', 'authenticated', (c) => {
  const user = repo.get('users', c.tenantId, c.identity.userId);
  if (!user) return { error: 'NOT_FOUND', message: 'User not found.' };
  const action = c.body.action || 'setup';
  if (action === 'setup') return auth.setupMfa({ user });
  if (action === 'enable') return auth.enableMfa({ user, totp: c.body.totp });
  if (action === 'disable') return auth.disableMfa({ user, totp: c.body.totp });
  return { error: 'BAD_ACTION', message: 'action must be setup|enable|disable' };
});
route('GET', '/api/v1/auth/me', 'authenticated', (c) => {
  const user = repo.get('users', c.tenantId, c.identity.userId);
  if (!user) return { error: 'NOT_FOUND', message: 'User not found.' };
  const tenant = repo.row('SELECT * FROM tenants WHERE id = ?', c.tenantId);
  return { user: auth.publicUser(user), tenant: { id: tenant.id, name: tenant.name, plan: tenant.plan } };
});

/* =========================== UNIVERSAL BUILDER ============================ */
route('POST', '/api/v1/builder/create', 'projects.write', async (c) => {
  const r = await brain.createBuild({
    tenantId: c.tenantId, user: { id: c.identity.userId }, goal: c.body.goal,
    outputType: c.body.outputType || 'application', priority: c.body.priority || 'normal', vaultLookup: c.vaultLookup,
    freeOnly: Boolean(c.body.freeOnly),
  });
  return { buildId: r.build.id, projectId: r.project.id, blueprintId: r.blueprint.id, status: 'planning', assignedBrain: c.body.freeOnly ? 'Free Tier Brain' : 'Executive Brain', freeOnly: Boolean(c.body.freeOnly), plan: r.plan, degraded: r.degraded, plannerModel: r.model };
});
route('POST', '/api/v1/builder/plan', 'projects.read', async (c) => {
  const r = await brain.analyzeIntent({ tenantId: c.tenantId, goal: c.body.goal, outputType: c.body.outputType, vaultLookup: c.vaultLookup, freeOnly: Boolean(c.body.freeOnly) });
  return r;
});
route('POST', '/api/v1/builder/build', 'projects.write', async (c) => {
  const freeOnly = Boolean(c.body.freeOnly);
  let buildId = c.body.buildId;
  if (!buildId) {
    const created = await brain.createBuild({
      tenantId: c.tenantId, user: { id: c.identity.userId }, goal: c.body.goal,
      outputType: c.body.outputType || 'application', priority: c.body.priority || 'normal', vaultLookup: c.vaultLookup,
      freeOnly,
    });
    buildId = created.build.id;
  }
  if (c.body.sync) {
    const result = await brain.executeBuild({ tenantId: c.tenantId, buildId, user: { id: c.identity.userId }, vaultLookup: c.vaultLookup, freeOnly });
    return { buildId, status: 'completed', freeOnly, result };
  }
  const job = jobs.createJob({ tenantId: c.tenantId, kind: 'build', name: `Build: ${c.body.goal || buildId}`, payload: { buildId, freeOnly } });
  jobs.enqueue(job.id);
  return { buildId, jobId: job.id, status: 'running', freeOnly };
});
route('POST', '/api/v1/builder/deploy', 'deployments.write', (c) => {
  const build = repo.get('builds', c.tenantId, c.body.buildId);
  if (!build) return { error: 'NOT_FOUND', message: 'Build not found.' };
  const dep = repo.insert('deployments', c.tenantId, {
    project_id: build.project_id, target: c.body.target || 'web', environment: c.body.environment || 'production',
    version: c.body.version || '1.0.0', status: 'deployed',
    endpoint: `${config.APP_BASE_URL}/api/v1/projects/${build.project_id}`,
    config: { buildId: build.id }, updated_at: new Date().toISOString(),
  });
  repo.insert('deployment_events', c.tenantId, { deployment_id: dep.id, event: 'deployed', detail: 'Manual deploy from Universal Builder' });
  events.publish(c.tenantId, 'deployment', { id: dep.id, status: 'deployed' });
  return { deployment: dep };
});

/* ============================== J-ROC AI ================================== */
route('POST', '/api/v1/jroc/chat', 'platform.read', async (c) => {
  const user = repo.get('users', c.tenantId, c.identity.userId) || { id: c.identity.userId, email: c.identity.email };
  return brain.jrocChat({ tenantId: c.tenantId, user, message: c.body.message, history: c.body.history || [], vaultLookup: c.vaultLookup, projectId: c.body.projectId || null, brainProfile: c.body.freeOnly ? 'Free Tier Brain' : (c.body.brainProfile || 'Executive Brain'), freeOnly: Boolean(c.body.freeOnly) });
});
route('POST', '/api/v1/jroc/advise', 'platform.read', async (c) => {
  const user = repo.get('users', c.tenantId, c.identity.userId) || { id: c.identity.userId };
  const r = await brain.jrocChat({ tenantId: c.tenantId, user, message: `As my strategic advisor, advise on: ${c.body.question || c.body.message}`, vaultLookup: c.vaultLookup, brainProfile: c.body.freeOnly ? 'Free Tier Brain' : (c.body.brainProfile || 'Executive Brain'), freeOnly: Boolean(c.body.freeOnly) });
  return { advice: r.reply, ...r };
});
route('POST', '/api/v1/jroc/create', 'platform.write', async (c) => {
  const what = c.body.what || c.body.message;
  const freeOnly = Boolean(c.body.freeOnly);
  const created = await brain.createBuild({ tenantId: c.tenantId, user: { id: c.identity.userId }, goal: what, outputType: c.body.outputType || 'application', vaultLookup: c.vaultLookup, freeOnly });
  const job = jobs.createJob({ tenantId: c.tenantId, kind: 'build', name: `J-Roc build: ${what}`, payload: { buildId: created.build.id, freeOnly } });
  jobs.enqueue(job.id);
  return { buildId: created.build.id, projectId: created.project.id, status: 'running', jobId: job.id, freeOnly };
});
route('POST', '/api/v1/jroc/plan', 'platform.read', async (c) => {
  const r = await brain.analyzeIntent({ tenantId: c.tenantId, goal: c.body.goal || c.body.message, outputType: c.body.outputType, vaultLookup: c.vaultLookup, freeOnly: Boolean(c.body.freeOnly) });
  return r;
});

/* =============================== AGENTS =================================== */
route('GET', '/api/v1/agents', 'agents.read', (c) => ({ agents: repo.list('agents', c.tenantId, { limit: c.limit, offset: c.offset }) }));
route('POST', '/api/v1/agents', 'agents.write', (c) => {
  const a = workforce.createAgent(c.tenantId, c.body);
  repo.audit({ tenantId: c.tenantId, entity: 'agent', entityId: a.id, action: 'create', userId: c.identity.userId });
  return { agent: a };
});
route('GET', '/api/v1/agents/:id', 'agents.read', (c) => {
  const agent = repo.get('agents', c.tenantId, c.params.id);
  if (!agent) return { error: 'NOT_FOUND', message: 'Agent not found.' };
  return { agent };
});
route('PUT', '/api/v1/agents/:id', 'agents.write', (c) => ({ agent: repo.update('agents', c.tenantId, c.params.id, { ...c.body, updated_at: new Date().toISOString() }) }));
route('DELETE', '/api/v1/agents/:id', 'agents.write', (c) => { repo.remove('agents', c.tenantId, c.params.id); return { ok: true }; });
route('POST', '/api/v1/agents/run', 'agents.write', async (c) => {
  const agent = c.body.agentId ? repo.get('agents', c.tenantId, c.body.agentId) : null;
  const target = agent || { id: 'adhoc', system_prompt: c.body.systemPrompt || 'Deliver the task.', brain_profile: c.body.brainProfile || 'Executive Brain' };
  const out = await workforce.runAgent({ tenantId: c.tenantId, agent: target, task: c.body.task || c.body.message, projectId: c.body.projectId || null, vaultLookup: c.vaultLookup, brainProfile: c.body.brainProfile, freeOnly: Boolean(c.body.freeOnly) });
  return { result: out };
});

/* =============================== WORKERS ================================== */
route('GET', '/api/v1/workers', 'workers.read', (c) => ({ workers: repo.list('workers', c.tenantId, { limit: c.limit, offset: c.offset }) }));
route('POST', '/api/v1/workers', 'workers.write', (c) => ({ worker: workforce.createWorker(c.tenantId, c.body) }));
route('PUT', '/api/v1/workers/:id', 'workers.write', (c) => ({ worker: repo.update('workers', c.tenantId, c.params.id, { ...c.body, updated_at: new Date().toISOString() }) }));
route('DELETE', '/api/v1/workers/:id', 'workers.write', (c) => { repo.remove('workers', c.tenantId, c.params.id); return { ok: true }; });

/* ========================= TEAMS / DEPARTMENTS / SWARMS =================== */
route('GET', '/api/v1/teams', 'teams.read', (c) => ({ teams: withMembers(c, 'teams', 'team_members', 'team_id') }));
route('POST', '/api/v1/teams', 'teams.write', (c) => ({ team: workforce.createTeam(c.tenantId, c.body) }));
route('PUT', '/api/v1/teams/:id', 'teams.write', (c) => ({ team: repo.update('teams', c.tenantId, c.params.id, c.body) }));
route('DELETE', '/api/v1/teams/:id', 'teams.write', (c) => { repo.remove('teams', c.tenantId, c.params.id); return { ok: true }; });

route('GET', '/api/v1/departments', 'teams.read', (c) => ({ departments: withMembers(c, 'departments', 'department_members', 'department_id') }));
route('POST', '/api/v1/departments', 'teams.write', (c) => ({ department: workforce.createDepartment(c.tenantId, c.body) }));
route('PUT', '/api/v1/departments/:id', 'teams.write', (c) => ({ department: repo.update('departments', c.tenantId, c.params.id, c.body) }));
route('DELETE', '/api/v1/departments/:id', 'teams.write', (c) => { repo.remove('departments', c.tenantId, c.params.id); return { ok: true }; });

route('GET', '/api/v1/swarms', 'teams.read', (c) => {
  const swarms = repo.list('swarms', c.tenantId, { limit: c.limit });
  return { swarms: swarms.map((s) => ({ ...s, members: repo.rows('SELECT * FROM swarm_members WHERE swarm_id = ?', s.id) })) };
});
route('POST', '/api/v1/swarms', 'teams.write', (c) => ({ swarm: workforce.createSwarm(c.tenantId, c.body) }));
route('PUT', '/api/v1/swarms/:id', 'teams.write', (c) => ({ swarm: repo.update('swarms', c.tenantId, c.params.id, c.body) }));
route('DELETE', '/api/v1/swarms/:id', 'teams.write', (c) => { repo.remove('swarms', c.tenantId, c.params.id); return { ok: true }; });

function withMembers(c, table, joinTable, fk) {
  return repo.list(table, c.tenantId, { limit: c.limit }).map((r) => ({
    ...r, members: repo.rows(`SELECT * FROM ${joinTable} WHERE ${fk} = ?`, r.id),
  }));
}

/* ============================ KNOWLEDGE BRAIN ============================= */
route('POST', '/api/v1/knowledge/search', 'knowledge.read', async (c) => knowledge.search({ tenantId: c.tenantId, query: c.body.query || c.body.q, category: c.body.category || null, limit: c.body.limit || 8, vaultLookup: c.vaultLookup }));
route('POST', '/api/v1/knowledge/embed', 'knowledge.write', async (c) => {
  const e = await providers.embed(c.body.text || c.body.query, { vaultLookup: c.vaultLookup });
  return { dim: e.dim, model: e.model, degraded: e.degraded, vector: e.vector.slice(0, 24).concat(['...']) };
});
route('POST', '/api/v1/knowledge/upload', 'knowledge.write', async (c) => {
  const nodes = await knowledge.ingest({ tenantId: c.tenantId, title: c.body.title || 'Untitled', content: c.body.content, category: c.body.category, projectId: c.body.projectId || null, source: c.body.source || 'upload', metadata: c.body.metadata || {}, vaultLookup: c.vaultLookup });
  return { ingested: nodes.length, nodes: nodes.map((n) => ({ id: n.id, title: n.title })) };
});
route('GET', '/api/v1/knowledge/nodes', 'knowledge.read', (c) => ({
  nodes: repo.list('knowledge_nodes', c.tenantId, { where: c.query.category ? 'category = ?' : '', params: c.query.category ? [c.query.category] : [], limit: c.limit }).map((n) => ({ ...n, embedding: undefined })),
  categories: knowledge.CATEGORIES,
}));
route('GET', '/api/v1/knowledge/nodes/:id', 'knowledge.read', (c) => knowledge.graph({ tenantId: c.tenantId, nodeId: c.params.id, depth: Number(c.query.depth || 1) }));
route('DELETE', '/api/v1/knowledge/nodes/:id', 'knowledge.write', (c) => { repo.remove('knowledge_nodes', c.tenantId, c.params.id); return { ok: true }; });

route('GET', '/api/v1/memories', 'knowledge.read', (c) => ({ memories: repo.list('memories', c.tenantId, { limit: c.limit }), scopes: knowledge.MEMORY_SCOPES }));
route('POST', '/api/v1/memories', 'knowledge.write', async (c) => ({ memory: await knowledge.remember({ tenantId: c.tenantId, ...c.body, vaultLookup: c.vaultLookup }) }));
route('POST', '/api/v1/memories/recall', 'knowledge.read', async (c) => ({ results: await knowledge.recall({ tenantId: c.tenantId, query: c.body.query, scope: c.body.scope, ownerId: c.body.ownerId, limit: c.body.limit || 8, vaultLookup: c.vaultLookup }) }));

/* ============================= MODEL ROUTER =============================== */
route('GET', '/api/v1/router/models', 'models.read', (c) => ({
  models: router.modelsFor(c.tenantId).map((m) => ({ ...m, capabilities: j(m.capabilities), rateLimit: j(m.rate_limit), freeTier: m.free_tier === 1, configured: providers.resolveProvider(m.provider, c.vaultLookup).hasKey })),
  providers: providers.listProviders(c.vaultLookup),
}));
route('POST', '/api/v1/router/select', 'models.read', (c) => router.selectModel({ tenantId: c.tenantId, taskType: c.body.taskType || 'analysis', brainProfile: c.body.brainProfile || null, priority: c.body.priority || 'normal', vaultLookup: c.vaultLookup, freeOnly: Boolean(c.body.freeOnly) }));
route('POST', '/api/v1/router/route', 'models.read', async (c) => {
  const messages = c.body.messages || [{ role: 'user', content: c.body.prompt || c.body.message }];
  return router.route({ tenantId: c.tenantId, taskType: c.body.taskType || 'analysis', brainProfile: c.body.brainProfile || null, messages, vaultLookup: c.vaultLookup, json: Boolean(c.body.json), freeOnly: Boolean(c.body.freeOnly) });
});
route('POST', '/api/v1/router/validate', 'models.read', async (c) => {
  const results = [];
  for (const p of providers.listProviders(c.vaultLookup)) {
    results.push({ provider: p.id, label: p.label, configured: p.configured, kind: p.kind, baseUrl: p.baseUrl, defaultModel: p.defaultModel, freeTier: Boolean(p.freeTier), freeForever: Boolean(p.freeForever) });
  }
  return { providers: results };
});

/* ----------------------- FREE TIER ROUTER -------------------------------- */
route('GET', '/api/v1/router/free', 'models.read', (c) => {
  const freeProviderIds = new Set(freemodels.FREE_PROVIDERS.map((p) => p.id));
  const freeModelRows = router.freeModels(c.tenantId).map((m) => ({
    id: m.id, provider: m.provider, name: m.name, model_id: m.model_id,
    capabilities: j(m.capabilities), context_window: m.context_window,
    speed: m.speed, quality: m.quality, rate_limit: j(m.rate_limit), docs_url: m.docs_url,
    configured: providers.resolveProvider(m.provider, c.vaultLookup).hasKey,
  }));
  const configuredCount = freeModelRows.filter((m) => m.configured).length;
  return {
    providers: freemodels.listFreeProviders(c.vaultLookup),
    models: freeModelRows,
    summary: {
      providers: freemodels.FREE_PROVIDERS.length,
      providersConfigured: freemodels.listFreeProviders(c.vaultLookup).filter((p) => p.configured).length,
      models: freeModelRows.length,
      modelsConfigured: configuredCount,
      costPerMillionTokens: 0,
      freeTierBrain: 'Free Tier Brain',
      ready: configuredCount > 0,
    },
    secretNames: freemodels.FREE_PROVIDERS.map((p) => ({ provider: p.id, secretName: freemodels.secretName(p.id), envKeys: p.envKeys, signup: p.signup, accountEnvKey: p.accountEnvKey || null })),
    note: 'Store keys in the Secrets Vault (Security → Secrets Vault) or in .env. Free-tier keys never leave this machine unencrypted.',
  };
});

route('POST', '/api/v1/router/free/discover', 'models.read', async (c) => {
  const targets = c.body.provider
    ? [c.body.provider]
    : freemodels.FREE_PROVIDERS.map((p) => p.id);
  const out = [];
  for (const id of targets) {
    if (!freemodels.BY_ID[id]) { out.push({ provider: id, error: 'not a free-tier provider' }); continue; }
    out.push(await providers.discoverModels(id, c.vaultLookup));
  }
  return { discovered: out };
});

route('POST', '/api/v1/router/free/test', 'models.read', async (c) => {
  const targets = c.body.provider
    ? [c.body.provider]
    : freemodels.FREE_PROVIDERS.map((p) => p.id);
  const out = [];
  for (const id of targets) {
    if (!freemodels.BY_ID[id]) { out.push({ provider: id, ok: false, error: 'not a free-tier provider' }); continue; }
    out.push(await providers.testProvider(id, c.vaultLookup, c.body.model));
  }
  const ok = out.filter((r) => r.ok).length;
  repo.audit({ tenantId: c.tenantId, entity: 'router', action: 'free_tier_test', userId: c.identity.userId, metadata: { tested: out.length, ok } });
  return { results: out, ok, tested: out.length };
});

route('POST', '/api/v1/router/free/models', 'models.write', (c) => {
  // Register a discovered free model into the router so it becomes routable.
  const providerId = c.body.provider;
  if (!freemodels.BY_ID[providerId]) return { error: 'BAD_PROVIDER', message: 'Not a free-tier provider.' };
  if (!c.body.modelId) return { error: 'BAD_REQUEST', message: 'modelId required.' };
  const existing = repo.row('SELECT id FROM models WHERE tenant_id IS NULL AND provider = ? AND model_id = ?', providerId, c.body.modelId);
  if (existing) { repo.run('UPDATE models SET free_tier = 1, enabled = 1 WHERE id = ?', existing.id); return { ok: true, modelId: existing.id, existing: true }; }
  const m = repo.insert('models', c.tenantId, {
    provider: providerId, name: c.body.name || c.body.modelId, model_id: c.body.modelId, base_url: '',
    kind: freemodels.BY_ID[providerId].kind, capabilities: c.body.capabilities || [], context_window: c.body.context || 0,
    cost_in: 0, cost_out: 0, speed: c.body.speed || 7, quality: c.body.quality || 7, enabled: 1,
    free_tier: 1, rate_limit: freemodels.BY_ID[providerId].rateLimit || {}, docs_url: freemodels.BY_ID[providerId].docs || '',
  });
  repo.audit({ tenantId: c.tenantId, entity: 'model', entityId: m.id, action: 'register_free', userId: c.identity.userId, metadata: { provider: providerId, modelId: c.body.modelId } });
  return { ok: true, model: m };
});
route('GET', '/api/v1/router/rules', 'models.read', (c) => ({ rules: repo.rows('SELECT * FROM router_rules WHERE (tenant_id IS NULL OR tenant_id = ?) ORDER BY priority ASC', c.tenantId) }));
route('POST', '/api/v1/router/rules', 'models.write', (c) => ({ rule: repo.insert('router_rules', c.tenantId, { name: c.body.name, task_type: c.body.taskType || 'analysis', match_expr: {}, target_provider: c.body.targetProvider || null, target_model_id: c.body.targetModelId || null, brain_profile_id: c.body.brainProfileId || null, priority: c.body.priority || 100, enabled: 1 }) }));
route('DELETE', '/api/v1/router/rules/:id', 'models.write', (c) => { repo.remove('router_rules', c.tenantId, c.params.id); return { ok: true }; });

/* ============================ BRAIN PROFILES ============================== */
route('GET', '/api/v1/brain-profiles', 'models.read', (c) => ({
  profiles: repo.rows('SELECT * FROM brain_profiles WHERE (tenant_id IS NULL OR tenant_id = ?) ORDER BY name', c.tenantId).map((b) => ({
    ...b, strategy: j(b.strategy), models: repo.rows('SELECT m.* FROM brain_models bm JOIN models m ON m.id = bm.model_id WHERE bm.brain_profile_id = ? ORDER BY bm.ordinal', b.id).map((m) => ({ id: m.id, provider: m.provider, name: m.name, model_id: m.model_id })),
  })),
}));
route('POST', '/api/v1/brain-profiles', 'models.write', (c) => ({ profile: repo.insert('brain_profiles', c.tenantId, { name: c.body.name, description: c.body.description || '', mode: c.body.mode || 'single', strategy: c.body.strategy || {}, is_system: 0 }) }));

/* ================================ PLUGINS ================================= */
route('GET', '/api/v1/plugins', 'plugins.read', (c) => ({ plugins: repo.list('plugins', c.tenantId, { limit: c.limit }), catalog: PLUGIN_CATALOG }));
route('POST', '/api/v1/plugins/connect', 'plugins.write', (c) => {
  const p = repo.insert('plugins', c.tenantId, { name: c.body.name || c.body.provider, provider: c.body.provider || 'custom', category: c.body.category || 'custom', status: 'connected', config: c.body.config || {} });
  repo.audit({ tenantId: c.tenantId, entity: 'plugin', entityId: p.id, action: 'connect', userId: c.identity.userId, metadata: { provider: p.provider } });
  return { plugin: p };
});
route('DELETE', '/api/v1/plugins/:id', 'plugins.write', (c) => { repo.remove('plugins', c.tenantId, c.params.id); return { ok: true }; });
route('POST', '/api/v1/plugins/test', 'plugins.write', async (c) => {
  const plugin = c.body.id ? repo.get('plugins', c.tenantId, c.body.id) : null;
  const cfg = j(plugin?.config) || c.body.config || {};
  const url = cfg.baseUrl || cfg.url;
  let ok = Boolean(plugin) || Boolean(c.body.provider);
  let detail = plugin ? `Plugin "${plugin.name}" configuration present.` : 'Provider recognised.';
  if (url) {
    try { const r = await fetch(url, { method: 'HEAD' }); ok = r.ok || r.status < 500; detail = `Reachable (HTTP ${r.status}).`; }
    catch (e) { ok = false; detail = `Unreachable: ${e.message}`; }
  }
  if (plugin) repo.update('plugins', c.tenantId, plugin.id, { last_tested_at: new Date().toISOString(), last_test_ok: ok ? 1 : 0, status: ok ? 'connected' : 'error' });
  return { ok, detail };
});

const PLUGIN_CATALOG = [
  { provider: 'microsoft', label: 'Microsoft', category: 'productivity' },
  { provider: 'google', label: 'Google', category: 'productivity' },
  { provider: 'github', label: 'GitHub', category: 'dev' },
  { provider: 'gitlab', label: 'GitLab', category: 'dev' },
  { provider: 'stripe', label: 'Stripe', category: 'payments' },
  { provider: 'paypal', label: 'PayPal', category: 'payments' },
  { provider: 'shopify', label: 'Shopify', category: 'ecommerce' },
  { provider: 'supabase', label: 'Supabase', category: 'database' },
  { provider: 'azure', label: 'Azure', category: 'cloud' },
  { provider: 'aws', label: 'AWS', category: 'cloud' },
  { provider: 'cloudflare', label: 'Cloudflare', category: 'cloud' },
  { provider: 'social', label: 'Social Media', category: 'social' },
  { provider: 'creative', label: 'Creative Platforms', category: 'creative' },
  { provider: 'database', label: 'Databases', category: 'database' },
  { provider: 'custom', label: 'Custom Connector', category: 'custom' },
];

route('GET', '/api/v1/connectors', 'plugins.read', (c) => ({ connectors: repo.list('connectors', c.tenantId, { limit: c.limit }) }));
route('POST', '/api/v1/connectors', 'plugins.write', (c) => ({ connector: repo.insert('connectors', c.tenantId, { plugin_id: c.body.pluginId || null, name: c.body.name || 'Connector', kind: c.body.kind || 'REST', base_url: c.body.baseUrl || '', spec: c.body.spec || {}, status: 'active' }) }));
route('PUT', '/api/v1/connectors/:id', 'plugins.write', (c) => ({ connector: repo.update('connectors', c.tenantId, c.params.id, c.body) }));
route('DELETE', '/api/v1/connectors/:id', 'plugins.write', (c) => { repo.remove('connectors', c.tenantId, c.params.id); return { ok: true }; });
route('POST', '/api/v1/connectors/:id/invoke', 'plugins.write', async (c) => {
  const conn = repo.get('connectors', c.tenantId, c.params.id);
  if (!conn) return { error: 'NOT_FOUND', message: 'Connector not found.' };
  const spec = j(conn.spec) || {};
  const path = c.body.path || spec.path || '/';
  const url = `${conn.base_url.replace(/\/$/, '')}${path}`;
  try {
    const res = await fetch(url, { method: c.body.method || spec.method || 'GET', headers: { 'Content-Type': 'application/json', ...(c.body.headers || {}) }, body: c.body.body ? JSON.stringify(c.body.body) : undefined });
    const text = await res.text();
    return { status: res.status, ok: res.ok, body: text.slice(0, 8000) };
  } catch (e) { return { error: 'CONNECTOR_ERROR', message: e.message }; }
});

/* ============================== WORKFLOWS ================================= */
route('GET', '/api/v1/workflows', 'workflows.read', (c) => ({ workflows: repo.list('workflows', c.tenantId, { limit: c.limit }).map((w) => ({ ...w, definition: j(w.definition) })) }));
route('POST', '/api/v1/workflows', 'workflows.write', (c) => ({ workflow: workflow.createWorkflow(c.tenantId, c.body) }));
route('GET', '/api/v1/workflows/:id', 'workflows.read', (c) => { const w = repo.get('workflows', c.tenantId, c.params.id); return w ? { workflow: { ...w, definition: j(w.definition) } } : { error: 'NOT_FOUND', message: 'Workflow not found.' }; });
route('PUT', '/api/v1/workflows/:id', 'workflows.write', (c) => ({ workflow: workflow.updateWorkflow(c.tenantId, c.params.id, c.body) }));
route('DELETE', '/api/v1/workflows/:id', 'workflows.write', (c) => { repo.remove('workflows', c.tenantId, c.params.id); return { ok: true }; });
route('POST', '/api/v1/workflows/:id/run', 'workflows.write', (c) => {
  const wf = repo.get('workflows', c.tenantId, c.params.id);
  if (!wf) return { error: 'NOT_FOUND', message: 'Workflow not found.' };
  return workflow.runWorkflow({ tenantId: c.tenantId, workflow: wf, vaultLookup: c.vaultLookup });
});

route('GET', '/api/v1/automations', 'workflows.read', (c) => ({ automations: repo.list('automations', c.tenantId, { limit: c.limit }).map((a) => ({ ...a, trigger: j(a.trigger) })) }));
route('POST', '/api/v1/automations', 'workflows.write', (c) => ({ automation: workflow.createAutomation(c.tenantId, c.body) }));
route('PUT', '/api/v1/automations/:id', 'workflows.write', (c) => ({ automation: repo.update('automations', c.tenantId, c.params.id, { ...c.body, enabled: c.body.enabled === undefined ? undefined : (c.body.enabled ? 1 : 0) }) }));
route('DELETE', '/api/v1/automations/:id', 'workflows.write', (c) => { repo.remove('automations', c.tenantId, c.params.id); return { ok: true }; });

/* ============================== COMMAND BRAIN ============================= */
route('POST', '/api/v1/brain/execute', 'platform.write', async (c) => {
  if (c.body.buildId) {
    const job = jobs.createJob({ tenantId: c.tenantId, kind: 'build', name: 'Command Brain execution', payload: { buildId: c.body.buildId, freeOnly: Boolean(c.body.freeOnly) } });
    jobs.enqueue(job.id);
    return { jobId: job.id, status: 'running' };
  }
  if (c.body.workflowId) {
    const wf = repo.get('workflows', c.tenantId, c.body.workflowId);
    if (!wf) return { error: 'NOT_FOUND', message: 'Workflow not found.' };
    return workflow.runWorkflow({ tenantId: c.tenantId, workflow: wf, vaultLookup: c.vaultLookup });
  }
  return { error: 'BAD_REQUEST', message: 'Provide buildId or workflowId.' };
});
route('POST', '/api/v1/brain/orchestrate', 'platform.write', async (c) => {
  const freeOnly = Boolean(c.body.freeOnly);
  const created = await brain.createBuild({ tenantId: c.tenantId, user: { id: c.identity.userId }, goal: c.body.goal, outputType: c.body.outputType || 'application', vaultLookup: c.vaultLookup, freeOnly });
  const job = jobs.createJob({ tenantId: c.tenantId, kind: 'build', name: `Orchestrate: ${c.body.goal}`, payload: { buildId: created.build.id, freeOnly } });
  jobs.enqueue(job.id);
  return { buildId: created.build.id, projectId: created.project.id, jobId: job.id, status: 'running', assignedBrain: freeOnly ? 'Free Tier Brain' : 'Executive Brain', freeOnly };
});
route('GET', '/api/v1/brain/status', 'platform.read', (c) => ({
  status: 'online',
  jobs: jobs.stats(c.tenantId),
  events: events.stats(),
  providers: providers.listProviders(c.vaultLookup).filter((p) => p.configured).map((p) => p.id),
  freeProviders: providers.listProviders(c.vaultLookup).filter((p) => p.configured && p.freeTier).map((p) => p.id),
  freeModelsConfigured: router.freeModels(c.tenantId).filter((m) => providers.resolveProvider(m.provider, c.vaultLookup).hasKey).length,
  models: router.modelsFor(c.tenantId).length,
  agents: repo.list('agents', c.tenantId, { limit: 1000 }).length,
  workers: repo.list('workers', c.tenantId, { limit: 1000 }).length,
}));

/* =============================== PROJECTS ================================= */
route('GET', '/api/v1/projects', 'projects.read', (c) => ({ projects: repo.list('projects', c.tenantId, { limit: c.limit }) }));
route('POST', '/api/v1/projects', 'projects.write', (c) => ({ project: repo.insert('projects', c.tenantId, { name: c.body.name, goal: c.body.goal || '', description: c.body.description || '', status: 'active', priority: c.body.priority || 'normal', owner_id: c.identity.userId, metadata: {}, updated_at: new Date().toISOString() }) }));
route('GET', '/api/v1/projects/:id', 'projects.read', (c) => {
  const project = repo.get('projects', c.tenantId, c.params.id);
  if (!project) return { error: 'NOT_FOUND', message: 'Project not found.' };
  return {
    project,
    blueprints: repo.rows('SELECT * FROM blueprints WHERE tenant_id = ? AND project_id = ?', c.tenantId, project.id).map((b) => ({ ...b, architecture: j(b.architecture), requirements: j(b.requirements), tasks: j(b.tasks) })),
    assets: repo.rows('SELECT id, name, asset_type, size_bytes, created_at FROM assets WHERE tenant_id = ? AND project_id = ?', c.tenantId, project.id),
    deployments: repo.rows('SELECT * FROM deployments WHERE tenant_id = ? AND project_id = ?', c.tenantId, project.id),
    builds: repo.rows('SELECT id, goal, status, created_at FROM builds WHERE tenant_id = ? AND project_id = ?', c.tenantId, project.id),
    jobs: repo.rows('SELECT id, name, status, progress FROM jobs WHERE tenant_id = ? AND project_id = ? ORDER BY created_at DESC LIMIT 50', c.tenantId, project.id),
  };
});
route('PUT', '/api/v1/projects/:id', 'projects.write', (c) => ({ project: repo.update('projects', c.tenantId, c.params.id, { ...c.body, updated_at: new Date().toISOString() }) }));
route('DELETE', '/api/v1/projects/:id', 'projects.write', (c) => { repo.remove('projects', c.tenantId, c.params.id); return { ok: true }; });

route('GET', '/api/v1/blueprints', 'projects.read', (c) => ({ blueprints: repo.list('blueprints', c.tenantId, { limit: c.limit }).map((b) => ({ ...b, architecture: j(b.architecture), requirements: j(b.requirements), tasks: j(b.tasks) })) }));
route('GET', '/api/v1/builds', 'projects.read', (c) => ({ builds: repo.list('builds', c.tenantId, { limit: c.limit }).map((b) => ({ ...b, plan: j(b.plan), result: j(b.result) })) }));
route('GET', '/api/v1/builds/:id', 'projects.read', (c) => {
  const b = repo.get('builds', c.tenantId, c.params.id);
  if (!b) return { error: 'NOT_FOUND', message: 'Build not found.' };
  return { build: { ...b, plan: j(b.plan), result: j(b.result) }, jobs: repo.rows('SELECT id, name, status, progress, model, brain FROM jobs WHERE tenant_id = ? AND project_id = ? ORDER BY created_at', c.tenantId, b.project_id) };
});

/* ================================ ASSETS ================================== */
route('GET', '/api/v1/assets', 'projects.read', (c) => ({ assets: repo.list('assets', c.tenantId, { limit: c.limit }).map((a) => ({ ...a, content: undefined })) }));
route('GET', '/api/v1/assets/:id', 'projects.read', (c) => { const a = repo.get('assets', c.tenantId, c.params.id); return a ? { asset: a } : { error: 'NOT_FOUND', message: 'Asset not found.' }; });
route('POST', '/api/v1/assets', 'projects.write', (c) => ({ asset: repo.insert('assets', c.tenantId, { project_id: c.body.projectId || null, name: c.body.name || 'Asset', asset_type: c.body.assetType || 'document', mime_type: c.body.mimeType || 'text/plain', content: c.body.content || '', size_bytes: Buffer.byteLength(c.body.content || '', 'utf8'), checksum: require('node:crypto').createHash('sha256').update(c.body.content || '').digest('hex').slice(0, 32), version: 1, metadata: c.body.metadata || {} }) }));
route('DELETE', '/api/v1/assets/:id', 'projects.write', (c) => { repo.remove('assets', c.tenantId, c.params.id); return { ok: true }; });

/* ============================== DEPLOYMENTS =============================== */
function deploy(c, target) {
  const projectId = c.body.projectId || null;
  const dep = repo.insert('deployments', c.tenantId, {
    project_id: projectId, target, environment: c.body.environment || 'production',
    version: c.body.version || '1.0.0', status: 'deployed',
    endpoint: projectId ? `${config.APP_BASE_URL}/api/v1/projects/${projectId}` : config.APP_BASE_URL,
    config: c.body.config || {}, updated_at: new Date().toISOString(),
  });
  repo.insert('deployment_events', c.tenantId, { deployment_id: dep.id, event: 'deployed', detail: `${target} deployment` });
  events.publish(c.tenantId, 'deployment', { id: dep.id, target, status: 'deployed' });
  return { deployment: dep };
}
route('POST', '/api/v1/deploy/web', 'deployments.write', (c) => deploy(c, 'web'));
route('POST', '/api/v1/deploy/mobile', 'deployments.write', (c) => deploy(c, 'mobile'));
route('POST', '/api/v1/deploy/desktop', 'deployments.write', (c) => deploy(c, 'desktop'));
route('GET', '/api/v1/deployments', 'deployments.read', (c) => ({ deployments: repo.list('deployments', c.tenantId, { limit: c.limit }).map((d) => ({ ...d, config: j(d.config), events: repo.rows('SELECT * FROM deployment_events WHERE deployment_id = ? ORDER BY created_at', d.id) })) }));

/* ============================== OBSERVATORY =============================== */
route('GET', '/api/v1/observatory', 'platform.read', (c) => {
  const t = c.tenantId;
  const jobRows = repo.rows('SELECT status, COUNT(*) n, SUM(tokens_in) ti, SUM(tokens_out) to_, SUM(cost) cost, AVG(duration_ms) avg_ms FROM jobs WHERE tenant_id = ? GROUP BY status', t);
  const jobsByStatus = Object.fromEntries(jobRows.map((r) => [r.status, r.n]));
  const totals = jobRows.reduce((acc, r) => ({ tokensIn: acc.tokensIn + (r.ti || 0), tokensOut: acc.tokensOut + (r.to_ || 0), cost: acc.cost + (r.cost || 0) }), { tokensIn: 0, tokensOut: 0, cost: 0 });
  const completed = jobsByStatus.completed || 0;
  const failed = jobsByStatus.failed || 0;
  const agentRows = repo.rows('SELECT status, COUNT(*) n FROM agents WHERE tenant_id = ? GROUP BY status', t);
  const modelUsage = repo.rows("SELECT model, COUNT(*) n, SUM(tokens_out) tokens FROM jobs WHERE tenant_id = ? AND model IS NOT NULL GROUP BY model ORDER BY n DESC LIMIT 10", t);
  const daily = repo.rows("SELECT substr(created_at,1,10) d, COUNT(*) n, SUM(cost) cost FROM jobs WHERE tenant_id = ? GROUP BY d ORDER BY d DESC LIMIT 14", t).reverse();
  return {
    jobs: { byStatus: jobsByStatus, totals, successRate: pct(completed, completed + failed), avgDurationMs: Math.round(jobRows.reduce((a, r) => a + (r.avg_ms || 0), 0) / (jobRows.length || 1)) },
    agents: { byStatus: Object.fromEntries(agentRows.map((r) => [r.status, r.n])), total: repo.list('agents', t, { limit: 1000 }).length },
    workers: { total: repo.list('workers', t, { limit: 1000 }).length },
    projects: { total: repo.list('projects', t, { limit: 1000 }).length, active: repo.rows("SELECT COUNT(*) n FROM projects WHERE tenant_id = ? AND status='active'", t)[0].n },
    builds: { total: repo.list('builds', t, { limit: 1000 }).length },
    assets: { total: repo.list('assets', t, { limit: 1000 }).length, bytes: repo.rows('SELECT COALESCE(SUM(size_bytes),0) b FROM assets WHERE tenant_id = ?', t)[0].b },
    knowledge: { nodes: repo.rows('SELECT COUNT(*) n FROM knowledge_nodes WHERE tenant_id = ?', t)[0].n, memories: repo.rows('SELECT COUNT(*) n FROM memories WHERE tenant_id = ?', t)[0].n },
    workflows: { total: repo.list('workflows', t, { limit: 1000 }).length, automations: repo.list('automations', t, { limit: 1000 }).length },
    deployments: { total: repo.list('deployments', t, { limit: 1000 }).length },
    models: { usage: modelUsage, configured: providers.listProviders(c.vaultLookup).filter((p) => p.configured).map((p) => p.id) },
    events: events.stats(),
    daily,
    system: { uptimeSec: Math.round(process.uptime()), memoryMb: Math.round(process.memoryUsage().rss / 1048576), node: process.version },
  };
});

/* ================================ RECOVERY ================================ */
route('GET', '/api/v1/recovery', 'platform.read', (c) => ({
  failed: repo.rows("SELECT id, name, kind, status, error, attempts, created_at FROM jobs WHERE tenant_id = ? AND status IN ('failed','cancelled','recovering') ORDER BY created_at DESC LIMIT 100", c.tenantId),
  failedWorkflows: repo.rows("SELECT id, name, status, created_at FROM workflows WHERE tenant_id = ? AND status = 'failed'", c.tenantId),
  failedDeployments: repo.rows("SELECT id, target, status, created_at FROM deployments WHERE tenant_id = ? AND status = 'failed'", c.tenantId),
}));
route('POST', '/api/v1/recovery/retry', 'platform.write', (c) => {
  const recovered = jobs.recover(c.tenantId, c.body.jobId || null);
  repo.audit({ tenantId: c.tenantId, entity: 'recovery', action: 'retry', userId: c.identity.userId, metadata: { recovered } });
  return { recovered };
});

/* ================================ SECURITY ================================ */
route('GET', '/api/v1/security/audit', 'audit.read', (c) => ({ logs: repo.list('audit_logs', c.tenantId, { limit: c.limit, order: 'created_at DESC' }) }));
route('GET', '/api/v1/security/sessions', 'security.admin', (c) => ({ sessions: repo.rows('SELECT id, user_id, ip, user_agent, expires_at, revoked, created_at FROM sessions WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 100', c.tenantId) }));
route('POST', '/api/v1/security/sessions/revoke', 'security.admin', (c) => { repo.run('UPDATE sessions SET revoked = 1 WHERE tenant_id = ? AND id = ?', c.tenantId, c.body.sessionId); return { ok: true }; });
route('GET', '/api/v1/security/overview', 'platform.read', (c) => ({
  users: repo.rows('SELECT COUNT(*) n FROM users WHERE tenant_id = ?', c.tenantId)[0].n,
  activeSessions: repo.rows('SELECT COUNT(*) n FROM sessions WHERE tenant_id = ? AND revoked = 0', c.tenantId)[0].n,
  apiKeys: repo.rows('SELECT COUNT(*) n FROM api_keys WHERE tenant_id = ? AND status = ?', c.tenantId, 'active')[0].n,
  secrets: repo.rows('SELECT COUNT(*) n FROM secrets WHERE tenant_id = ?', c.tenantId)[0].n,
  roles: repo.rows('SELECT r.name FROM roles r WHERE r.tenant_id IS NULL ORDER BY r.name').map((r) => r.name),
  permissions: repo.rows('SELECT code FROM permissions ORDER BY code').map((r) => r.code),
  rls: { enabled: true, mechanism: 'app_tenant session + tenant_id filter + repository guard' },
}));

/* ============================ SECRETS / API KEYS ========================== */
route('GET', '/api/v1/secrets', 'security.admin', (c) => ({ secrets: vault.listSecrets(c.tenantId) }));
route('POST', '/api/v1/secrets', 'security.admin', (c) => ({ secret: vault.setSecret({ tenantId: c.tenantId, userId: c.identity.userId, name: c.body.name, value: c.body.value, provider: c.body.provider || 'generic' }) }));
route('DELETE', '/api/v1/secrets/:id', 'security.admin', (c) => ({ ok: vault.deleteSecret({ tenantId: c.tenantId, userId: c.identity.userId, id: c.params.id }) }));
route('GET', '/api/v1/api-keys', 'security.admin', (c) => ({ keys: vault.listApiKeys(c.tenantId) }));
route('POST', '/api/v1/api-keys', 'security.admin', (c) => ({ key: vault.createApiKey({ tenantId: c.tenantId, userId: c.identity.userId, name: c.body.name || 'API key', scopes: c.body.scopes || ['*'] }) }));
route('DELETE', '/api/v1/api-keys/:id', 'security.admin', (c) => ({ ok: vault.revokeApiKey({ tenantId: c.tenantId, userId: c.identity.userId, id: c.params.id }) }));

/* ============================ USERS / NOTIFICATIONS ======================= */
route('GET', '/api/v1/users', 'security.admin', (c) => ({ users: repo.rows('SELECT id, email, display_name, status, mfa_enabled, last_login_at, created_at FROM users WHERE tenant_id = ? ORDER BY created_at DESC', c.tenantId) }));
route('POST', '/api/v1/users', 'security.admin', (c) => auth.createUser({ tenantId: c.tenantId, actorId: c.identity.userId, email: c.body.email, password: c.body.password, displayName: c.body.displayName, roleName: c.body.role || 'User' }));
route('GET', '/api/v1/notifications', 'platform.read', (c) => ({ notifications: repo.list('notifications', c.tenantId, { limit: c.limit, order: 'created_at DESC' }), unread: repo.rows('SELECT COUNT(*) n FROM notifications WHERE tenant_id = ? AND read = 0', c.tenantId)[0].n }));
route('POST', '/api/v1/notifications/read', 'platform.read', (c) => { repo.run('UPDATE notifications SET read = 1 WHERE tenant_id = ? AND (id = ? OR ? IS NULL)', c.tenantId, c.body.id || null, c.body.id || null); return { ok: true }; });

/* ============================ PROMPTS / SKILLS ============================ */
route('GET', '/api/v1/prompts', 'platform.read', (c) => ({ prompts: repo.rows('SELECT * FROM prompts WHERE tenant_id IS NULL OR tenant_id = ? ORDER BY name', c.tenantId) }));
route('POST', '/api/v1/prompts', 'platform.write', (c) => ({ prompt: repo.insert('prompts', c.tenantId, { name: c.body.name, category: c.body.category || 'general', body: c.body.body, variables: c.body.variables || [], version: 1, is_system: 0, updated_at: new Date().toISOString() }) }));
route('GET', '/api/v1/skills', 'platform.read', (c) => ({ skills: repo.rows('SELECT * FROM skills WHERE tenant_id IS NULL OR tenant_id = ? ORDER BY category, name', c.tenantId) }));
route('POST', '/api/v1/skills', 'platform.write', (c) => ({ skill: repo.insert('skills', c.tenantId, { name: c.body.name, description: c.body.description || '', category: c.body.category || 'general', spec: c.body.spec || {}, is_system: 0 }) }));

/* ================================ JOBS ==================================== */
route('GET', '/api/v1/jobs', 'platform.read', (c) => ({ jobs: repo.list('jobs', c.tenantId, { limit: c.limit, order: 'created_at DESC' }) }));
route('GET', '/api/v1/jobs/:id', 'platform.read', (c) => { const job = repo.get('jobs', c.tenantId, c.params.id); return job ? { job } : { error: 'NOT_FOUND', message: 'Job not found.' }; });
route('POST', '/api/v1/jobs/:id/cancel', 'platform.write', (c) => ({ job: jobs.cancel(c.tenantId, c.params.id) }));
route('POST', '/api/v1/jobs/:id/pause', 'platform.write', (c) => ({ job: jobs.pause(c.tenantId, c.params.id) }));
route('POST', '/api/v1/jobs/:id/resume', 'platform.write', (c) => ({ job: jobs.resume(c.tenantId, c.params.id) }));

/* ================================ DASHBOARD =============================== */
route('GET', '/api/v1/dashboard', 'platform.read', (c) => {
  const t = c.tenantId;
  return {
    greeting: 'What would you like to build today?',
    projects: repo.rows('SELECT id, name, goal, status, priority, created_at FROM projects WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 6', t),
    builds: repo.rows('SELECT id, goal, status, created_at FROM builds WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 6', t),
    agents: repo.rows('SELECT COUNT(*) n FROM agents WHERE tenant_id = ?', t)[0].n,
    workers: repo.rows('SELECT COUNT(*) n FROM workers WHERE tenant_id = ?', t)[0].n,
    swarms: repo.rows('SELECT COUNT(*) n FROM swarms WHERE tenant_id = ?', t)[0].n,
    knowledge: repo.rows('SELECT COUNT(*) n FROM knowledge_nodes WHERE tenant_id = ?', t)[0].n,
    activeJobs: repo.rows("SELECT COUNT(*) n FROM jobs WHERE tenant_id = ? AND status IN ('queued','running','planning','recovering')", t)[0].n,
    recentJobs: repo.rows('SELECT id, name, status, progress, created_at FROM jobs WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 8', t),
    notifications: repo.rows('SELECT * FROM notifications WHERE tenant_id = ? ORDER BY created_at DESC LIMIT 5', t),
  };
});

module.exports = { routes, PLUGIN_CATALOG };
