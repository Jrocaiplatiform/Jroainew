'use strict';
/**
 * jobs.js - persisted background job queue + scheduler (Hangfire-equivalent).
 * Every job is persisted with a status and full state log. Supports retry,
 * cancellation, pause/resume and recovery. Work is executed by registered
 * handlers so the Command Brain and Workflow Engine can enqueue real work.
 */
const repo = require('./repo');
const events = require('./events');

const STATES = ['queued', 'planning', 'running', 'paused', 'completed', 'failed', 'cancelled', 'recovering'];
const handlers = new Map();
const queue = [];
let running = 0;
let CONCURRENCY = 4;
let stopped = false;

function register(kind, handler) { handlers.set(kind, handler); }

function createJob({ tenantId, projectId = null, workflowId = null, agentId = null, workerId = null, parentId = null, kind = 'task', name, payload = {}, maxAttempts = 3 }) {
  const job = repo.insert('jobs', tenantId, {
    project_id: projectId, workflow_id: workflowId, agent_id: agentId, worker_id: workerId,
    parent_id: parentId, kind, name, payload, result: {}, status: 'queued',
    state_log: [{ at: new Date().toISOString(), status: 'queued' }],
    progress: 0, attempts: 0, max_attempts: maxAttempts,
    updated_at: new Date().toISOString(),
  });
  events.publish(tenantId, 'job', { id: job.id, status: 'queued', name, kind });
  return job;
}

function setState(tenantId, jobId, status, extra = {}) {
  const job = repo.get('jobs', tenantId, jobId);
  if (!job) return null;
  const log = safeJson(job.state_log, []);
  log.push({ at: new Date().toISOString(), status, ...extra });
  const updated = repo.update('jobs', tenantId, jobId, {
    status,
    state_log: log,
    progress: extra.progress ?? job.progress,
    result: extra.result ?? job.result,
    error: extra.error ?? job.error,
    brain: extra.brain ?? job.brain,
    model: extra.model ?? job.model,
    tokens_in: extra.tokensIn ?? job.tokens_in,
    tokens_out: extra.tokensOut ?? job.tokens_out,
    cost: extra.cost ?? job.cost,
    duration_ms: extra.durationMs ?? job.duration_ms,
    started_at: status === 'running' && !job.started_at ? new Date().toISOString() : job.started_at,
    finished_at: ['completed', 'failed', 'cancelled'].includes(status) ? new Date().toISOString() : job.finished_at,
    updated_at: new Date().toISOString(),
  });
  events.publish(tenantId, 'job', { id: jobId, status, name: job.name, progress: updated.progress, error: extra.error });
  return updated;
}

function enqueue(jobId) {
  if (!queue.includes(jobId)) queue.push(jobId);
  pump();
}

async function pump() {
  if (stopped) return;
  while (running < CONCURRENCY && queue.length) {
    const jobId = queue.shift();
    running++;
    execute(jobId).finally(() => { running--; pump(); });
  }
}

async function execute(jobId) {
  const anyTenant = repo.rows('SELECT * FROM jobs WHERE id = ?', jobId)[0];
  if (!anyTenant) return;
  const tenantId = anyTenant.tenant_id;
  const handler = handlers.get(anyTenant.kind);
  if (!handler) {
    setState(tenantId, jobId, 'failed', { error: `No handler registered for kind "${anyTenant.kind}"` });
    return;
  }
  setState(tenantId, jobId, 'running', { progress: 5 });
  const attempt = (anyTenant.attempts || 0) + 1;
  repo.update('jobs', tenantId, jobId, { attempts: attempt });
  const t0 = Date.now();
  try {
    const result = await handler({ job: anyTenant, tenantId, update: (patch) => setState(tenantId, jobId, 'running', patch) });
    setState(tenantId, jobId, 'completed', {
      progress: 100, result: result ?? {}, durationMs: Date.now() - t0,
      brain: result?.brain, model: result?.model,
      tokensIn: result?.tokensIn, tokensOut: result?.tokensOut, cost: result?.cost,
    });
    if (anyTenant.parent_id) checkParent(tenantId, anyTenant.parent_id);
  } catch (err) {
    if (attempt < (anyTenant.max_attempts || 3)) {
      setState(tenantId, jobId, 'recovering', { error: String(err.message || err), progress: 0 });
      setTimeout(() => { setState(tenantId, jobId, 'queued', { progress: 0 }); enqueue(jobId); }, Math.min(5000 * attempt, 30000));
    } else {
      setState(tenantId, jobId, 'failed', { error: String(err.message || err), durationMs: Date.now() - t0 });
      if (anyTenant.parent_id) checkParent(tenantId, anyTenant.parent_id);
    }
  }
}

function checkParent(tenantId, parentId) {
  const children = repo.rows('SELECT status FROM jobs WHERE tenant_id = ? AND parent_id = ?', tenantId, parentId);
  if (!children.length) return;
  if (children.every((c) => c.status === 'completed')) setState(tenantId, parentId, 'completed', { progress: 100 });
  else if (children.some((c) => c.status === 'failed')) setState(tenantId, parentId, 'failed', { error: 'One or more child jobs failed' });
}

function cancel(tenantId, jobId) {
  const job = repo.get('jobs', tenantId, jobId);
  if (!job) return null;
  return setState(tenantId, jobId, 'cancelled');
}
function pause(tenantId, jobId) { return setState(tenantId, jobId, 'paused'); }
function resume(tenantId, jobId) { const j = setState(tenantId, jobId, 'queued', { progress: 0 }); enqueue(jobId); return j; }

/** Recovery: re-queue failed/cancelled jobs (Recovery Center). */
function recover(tenantId, jobId = null) {
  const targets = jobId
    ? [repo.get('jobs', tenantId, jobId)].filter(Boolean)
    : repo.rows("SELECT * FROM jobs WHERE tenant_id = ? AND status IN ('failed','cancelled') ORDER BY created_at DESC LIMIT 50", tenantId);
  const recovered = [];
  for (const job of targets) {
    repo.update('jobs', tenantId, job.id, { attempts: 0 });
    setState(tenantId, job.id, 'queued', { progress: 0 });
    enqueue(job.id);
    recovered.push(job.id);
  }
  events.publish(tenantId, 'recovery', { recovered: recovered.length, jobId });
  return recovered;
}

function stats(tenantId) {
  const all = repo.rows('SELECT status, COUNT(*) AS n FROM jobs WHERE tenant_id = ? GROUP BY status', tenantId);
  const out = Object.fromEntries(STATES.map((s) => [s, 0]));
  for (const r of all) out[r.status] = r.n;
  return { byStatus: out, queuedInMemory: queue.length, running, concurrency: CONCURRENCY };
}

function setConcurrency(n) { CONCURRENCY = Math.max(1, Math.min(32, n)); }
function stop() { stopped = true; }
function safeJson(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

module.exports = { STATES, register, createJob, enqueue, execute, cancel, pause, resume, recover, stats, setConcurrency, stop, setState };
