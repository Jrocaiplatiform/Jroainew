'use strict';
/**
 * workflow.js - the Workflow Engine (spec section 13) + Automations.
 * Definitions are persisted as JSON. Execution runs steps through the job
 * system (Hangfire-equivalent) and streams status over the event bus.
 */
const repo = require('./repo');
const jobs = require('./jobs');
const events = require('./events');
const workforce = require('./workforce');
const knowledge = require('./knowledge');

function createWorkflow(tenantId, data) {
  return repo.insert('workflows', tenantId, {
    project_id: data.projectId || null,
    name: data.name || 'Workflow',
    description: data.description || '',
    definition: JSON.stringify(data.definition || { steps: [] }),
    status: 'active', version: 1,
    updated_at: new Date().toISOString(),
  });
}

function updateWorkflow(tenantId, id, patch) {
  const data = { ...patch, updated_at: new Date().toISOString() };
  if (patch.definition) data.definition = JSON.stringify(patch.definition);
  return repo.update('workflows', tenantId, id, data);
}

/** Execute a workflow definition by enqueuing a job per step. */
function runWorkflow({ tenantId, workflow, projectId = null, vaultLookup }) {
  const def = safeJson(workflow.definition, { steps: [] });
  const steps = def.steps || [];
  const parent = jobs.createJob({
    tenantId, projectId, workflowId: workflow.id, kind: 'workflow', name: `Workflow: ${workflow.name}`,
    payload: { workflowId: workflow.id, steps: steps.length },
  });
  jobs.setState(tenantId, parent.id, 'running', { progress: 5 });
  const children = [];
  for (const s of steps) {
    const job = jobs.createJob({
      tenantId, projectId, workflowId: workflow.id, parentId: parent.id,
      kind: s.kind || 'step', name: s.name || 'Step', payload: { step: s, vaultLookup },
    });
    children.push(job.id);
    jobs.enqueue(job.id);
  }
  events.publish(tenantId, 'workflow', { id: workflow.id, parentJob: parent.id, steps: steps.length });
  return { parentJob: parent.id, children };
}

/* -------------------------- built-in step handlers ------------------------ */
jobs.register('step', async ({ tenantId, job, update }) => {
  const payload = safeJson(job.payload, {});
  const s = payload.step || {};
  update({ progress: 25 });
  const op = s.op || 'agent';
  if (op === 'knowledge') {
    const res = await knowledge.search({ tenantId, query: s.query || s.name, limit: s.limit || 5, vaultLookup: payload.vaultLookup });
    update({ progress: 100 });
    return { op, results: res.results.map((r) => ({ id: r.node.id, title: r.node.title, score: r.score })) };
  }
  if (op === 'http') {
    const res = await fetch(s.url, { method: s.method || 'GET', headers: s.headers || {}, body: s.body ? JSON.stringify(s.body) : undefined });
    const text = await res.text();
    update({ progress: 100 });
    return { op, status: res.status, body: text.slice(0, 4000) };
  }
  // default: run through an agent
  const agent = s.agentId ? repo.get('agents', tenantId, s.agentId) : repo.list('agents', tenantId, { limit: 1 })[0];
  const out = await workforce.runAgent({
    tenantId, agent: agent || { id: 'adhoc', system_prompt: 'Deliver the step.', brain_profile: 'Executive Brain' },
    task: s.prompt || s.name || 'Execute step', projectId: job.project_id, vaultLookup: payload.vaultLookup,
  });
  update({ progress: 100 });
  return { op: 'agent', content: out.content, model: out.model, brain: out.brain, tokensIn: out.tokensIn, tokensOut: out.tokensOut, cost: out.cost };
});

jobs.register('workflow', async ({ tenantId, job }) => ({ workflow: true, steps: safeJson(job.payload, {}).steps || 0 }));

jobs.register('maintenance', async () => ({ ok: true, at: new Date().toISOString() }));
jobs.register('embedding', async ({ tenantId, job }) => {
  const payload = safeJson(job.payload, {});
  const nodes = await knowledge.ingest({ tenantId, title: payload.title, content: payload.content, category: payload.category, source: 'job' });
  return { nodes: nodes.length };
});

/* ------------------------------ automations ------------------------------- */
function createAutomation(tenantId, data) {
  return repo.insert('automations', tenantId, {
    name: data.name || 'Automation',
    trigger: JSON.stringify(data.trigger || { type: 'manual' }),
    workflow_id: data.workflowId || null,
    cron: data.cron || null,
    enabled: data.enabled === false ? 0 : 1,
    next_run_at: data.cron ? nextCron(data.cron) : null,
  });
}

/** Minimal cron next-run computation (5-field). Deterministic, no deps. */
function nextCron(expr) {
  const parts = String(expr).trim().split(/\s+/);
  if (parts.length !== 5) return null;
  const now = new Date();
  for (let add = 1; add <= 60 * 24 * 366; add++) {
    const d = new Date(now.getTime() + add * 60000);
    if (matches(parts, d)) return d.toISOString();
  }
  return null;
}
function matches(parts, d) {
  const [min, hour, dom, mon, dow] = parts;
  const ok = (field, val) => field === '*' || field.split(',').some((f) => {
    if (f.includes('/')) { const [base, step] = f.split('/'); return base === '*' ? val % Number(step) === 0 : Number(base) + Math.floor((val - Number(base)) / Number(step)) * Number(step) === val; }
    if (f.includes('-')) { const [a, b] = f.split('-').map(Number); return val >= a && val <= b; }
    return Number(f) === val;
  });
  return ok(min, d.getMinutes()) && ok(hour, d.getHours()) && ok(dom, d.getDate()) && ok(mon, d.getMonth() + 1) && ok(dow, d.getDay());
}

function tickAutomations(tenantId) {
  const due = repo.rows("SELECT * FROM automations WHERE tenant_id = ? AND enabled = 1 AND next_run_at IS NOT NULL AND next_run_at <= ?", tenantId, new Date().toISOString());
  for (const a of due) {
    if (a.workflow_id) {
      const wf = repo.get('workflows', tenantId, a.workflow_id);
      if (wf) runWorkflow({ tenantId, workflow: wf, vaultLookup: undefined });
    }
    repo.update('automations', tenantId, a.id, { last_run_at: new Date().toISOString(), next_run_at: a.cron ? nextCron(a.cron) : null });
  }
  return due.length;
}

function safeJson(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

module.exports = { createWorkflow, updateWorkflow, runWorkflow, createAutomation, nextCron, tickAutomations };
