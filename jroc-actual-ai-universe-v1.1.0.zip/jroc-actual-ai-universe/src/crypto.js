'use strict';
/**
 * crypto.js - all platform cryptography, zero external dependencies.
 *  - Password hashing: scrypt with per-user salt.
 *  - JWT: HS256 sign/verify (access + refresh tokens).
 *  - Secrets Vault: AES-256-GCM authenticated encryption at rest.
 *  - API keys: SHA-256 hash + prefix for lookup, never stored in plaintext.
 *  - MFA: RFC 6238 TOTP (SHA-1, 6 digits, 30s step).
 */
const crypto = require('node:crypto');
const config = require('./config');

/* ----------------------------- IDs ---------------------------------------- */
function uuid() {
  return crypto.randomUUID();
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

/* --------------------------- Passwords ------------------------------------ */
const SCRYPT_N = 16384, SCRYPT_R = 8, SCRYPT_P = 1, KEYLEN = 64;

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, KEYLEN, {
    N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P, maxmem: 64 * 1024 * 1024,
  });
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(password, stored) {
  try {
    const [scheme, n, r, p, saltB64, hashB64] = String(stored).split('$');
    if (scheme !== 'scrypt') return false;
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(hashB64, 'base64');
    const actual = crypto.scryptSync(String(password), salt, expected.length, {
      N: parseInt(n, 10), r: parseInt(r, 10), p: parseInt(p, 10), maxmem: 64 * 1024 * 1024,
    });
    return crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

/* ------------------------------- JWT -------------------------------------- */
function b64url(input) {
  return Buffer.from(input).toString('base64url');
}
function b64urlJson(obj) {
  return Buffer.from(JSON.stringify(obj)).toString('base64url');
}

function jwtSecret() {
  const secret = config.JWT_SECRET || config.MASTER_KEY;
  if (!secret) {
    // Deterministic dev fallback so the platform always boots. A warning is
    // logged by the server; production must set JWT_SECRET.
    return crypto.createHash('sha256').update('jroc-universe-dev-secret').digest();
  }
  return crypto.createHash('sha256').update(secret).digest();
}

function signJwt(payload, ttlSeconds) {
  const now = Math.floor(Date.now() / 1000);
  const body = { iat: now, exp: now + ttlSeconds, jti: uuid(), ...payload };
  const header = { alg: 'HS256', typ: 'JWT' };
  const signingInput = `${b64urlJson(header)}.${b64urlJson(body)}`;
  const sig = crypto.createHmac('sha256', jwtSecret()).update(signingInput).digest('base64url');
  return `${signingInput}.${sig}`;
}

function verifyJwt(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  const signingInput = `${h}.${p}`;
  const expected = crypto.createHmac('sha256', jwtSecret()).update(signingInput).digest('base64url');
  const a = Buffer.from(s);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  let payload;
  try {
    payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}

/* --------------------------- AES-256-GCM Vault ---------------------------- */
function masterKey() {
  const raw = config.MASTER_KEY || config.JWT_SECRET;
  if (!raw) {
    return crypto.createHash('sha256').update('jroc-universe-dev-master-key').digest();
  }
  // Accept any-length secret; derive a stable 32-byte key.
  return crypto.createHash('sha256').update(String(raw)).digest();
}

/** Returns a compact string: v1.<iv>.<tag>.<ciphertext> (all base64url). */
function encryptSecret(plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', masterKey(), iv);
  const enc = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1.${iv.toString('base64url')}.${tag.toString('base64url')}.${enc.toString('base64url')}`;
}

function decryptSecret(blob) {
  if (!blob) return '';
  const parts = String(blob).split('.');
  if (parts[0] !== 'v1' || parts.length !== 4) {
    throw new Error('Malformed ciphertext');
  }
  const iv = Buffer.from(parts[1], 'base64url');
  const tag = Buffer.from(parts[2], 'base64url');
  const data = Buffer.from(parts[3], 'base64url');
  const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
}

/* ------------------------------ API keys ---------------------------------- */
function generateApiKey() {
  const raw = 'jru_' + crypto.randomBytes(32).toString('base64url');
  const prefix = raw.slice(0, 12);
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  return { raw, prefix, hash };
}
function hashApiKey(raw) {
  return crypto.createHash('sha256').update(String(raw)).digest('hex');
}
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

/* -------------------------------- TOTP ------------------------------------ */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(buf) {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
function base32Decode(str) {
  const clean = String(str).toUpperCase().replace(/=+$/, '').replace(/\s/g, '');
  let bits = 0, value = 0;
  const out = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}
function generateTotpSecret() {
  return base32Encode(crypto.randomBytes(20));
}
function totpAt(secret, counter) {
  const key = base32Decode(secret);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac('sha1', key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
  return String(code % 1000000).padStart(6, '0');
}
function verifyTotp(secret, token, window = 1) {
  const counter = Math.floor(Date.now() / 1000 / 30);
  for (let i = -window; i <= window; i++) {
    if (safeEqual(totpAt(secret, counter + i), String(token).padStart(6, '0'))) return true;
  }
  return false;
}
function totpUri(secret, email, issuer = "J-Roc's Actual AI Universe") {
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(email)}` +
    `?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

module.exports = {
  uuid, randomToken,
  hashPassword, verifyPassword,
  signJwt, verifyJwt,
  encryptSecret, decryptSecret,
  generateApiKey, hashApiKey, safeEqual,
  generateTotpSecret, verifyTotp, totpAt, totpUri,
};
