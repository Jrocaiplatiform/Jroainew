'use strict';
/**
 * events.js - the real-time event bus (SignalR-equivalent).
 * Server-Sent Events deliver build progress, job status, agent/worker status,
 * workflow execution, deployment progress, notifications, observatory updates
 * and recovery events to the PWA without polling.
 */
const clients = new Set();

function subscribe(tenantId, userId, res) {
  const client = { tenantId, userId, res, id: Math.random().toString(36).slice(2) };
  clients.add(client);
  res.write(`event: hello\ndata: ${JSON.stringify({ ok: true, clientId: client.id })}\n\n`);
  const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch { /* ignore */ } }, 25000);
  return () => { clearInterval(ping); clients.delete(client); };
}

function publish(tenantId, type, payload = {}) {
  const frame = `event: ${type}\ndata: ${JSON.stringify({ type, at: new Date().toISOString(), ...payload })}\n\n`;
  for (const c of clients) {
    if (c.tenantId !== tenantId) continue;
    try { c.res.write(frame); } catch { clients.delete(c); }
  }
}

function stats() {
  const byTenant = {};
  for (const c of clients) byTenant[c.tenantId] = (byTenant[c.tenantId] || 0) + 1;
  return { total: clients.size, byTenant };
}

module.exports = { subscribe, publish, stats };
