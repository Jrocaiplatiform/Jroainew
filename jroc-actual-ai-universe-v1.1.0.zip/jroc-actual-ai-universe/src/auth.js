'use strict';
/**
 * auth.js - Identity, sessions, RBAC, MFA, API keys, bootstrap.
 */
const repo = require('./repo');
const config = require('./config');
const {
  uuid, hashPassword, verifyPassword, signJwt, verifyJwt,
  randomToken, generateTotpSecret, verifyTotp, totpUri, hashApiKey,
} = require('./crypto');

function slugify(s) {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'universe';
}

/** First-run bootstrap: tenant, system roles assignment, Chairman user. */
function bootstrap() {
  const existing = repo.row('SELECT COUNT(*) AS n FROM tenants');
  if (existing && existing.n > 0) return null;
  const tenantId = uuid();
  const now = new Date().toISOString();
  repo.run('INSERT INTO tenants (id, name, slug, status, plan, settings, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)',
    tenantId, config.BOOTSTRAP_TENANT_NAME, slugify(config.BOOTSTRAP_TENANT_NAME), 'active', 'private', '{}', now, now);

  const userId = uuid();
  repo.run('INSERT INTO users (id, tenant_id, email, display_name, password_hash, status, settings, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    userId, tenantId, config.BOOTSTRAP_CHAIRMAN_EMAIL.toLowerCase(), 'Chairman', hashPassword(config.BOOTSTRAP_CHAIRMAN_PASSWORD), 'active', '{}', now, now);

  const chairmanRole = repo.row("SELECT id FROM roles WHERE tenant_id IS NULL AND name = 'Chairman'");
  if (chairmanRole) repo.run('INSERT OR IGNORE INTO user_roles (user_id, role_id, granted_at) VALUES (?,?,?)', userId, chairmanRole.id, now);

  // Seed a starter workflow + automation so the engine is live out of the box.
  const wfId = uuid();
  repo.run('INSERT INTO workflows (id, tenant_id, name, description, definition, status, version, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
    wfId, tenantId, 'Universe Health Check', 'Weekly platform health review across projects and jobs.',
    JSON.stringify({ steps: [
      { name: 'Gather project status', op: 'knowledge', query: 'project status summary', limit: 5 },
      { name: 'Executive review', op: 'agent', prompt: 'Review the current state of the Universe: projects, builds, jobs and deployments. Summarize health and recommend actions.' },
    ] }), 'active', 1, now, now);
  repo.run('INSERT INTO automations (id, tenant_id, name, trigger, workflow_id, cron, enabled, next_run_at, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
    uuid(), tenantId, 'Weekly Health Check', JSON.stringify({ type: 'schedule' }), wfId, '0 9 * * 1', 1, require('./workflow').nextCron('0 9 * * 1'), now);

  return { tenantId, userId, email: config.BOOTSTRAP_CHAIRMAN_EMAIL };
}

function getRoles(userId) {
  return repo.rows(
    `SELECT r.id, r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?`, userId,
  );
}

function getPermissions(userId) {
  const perms = repo.rows(
    `SELECT DISTINCT p.code FROM user_roles ur
     JOIN role_permissions rp ON rp.role_id = ur.role_id
     JOIN permissions p ON p.id = rp.permission_id
     WHERE ur.user_id = ?`, userId,
  ).map((r) => r.code);
  return perms;
}

function publicUser(user) {
  return {
    id: user.id, tenantId: user.tenant_id, email: user.email, displayName: user.display_name,
    status: user.status, mfaEnabled: Boolean(user.mfa_enabled), roles: getRoles(user.id).map((r) => r.name),
    permissions: getPermissions(user.id), lastLoginAt: user.last_login_at,
  };
}

async function login({ email, password, totp, userAgent, ip }) {
  const user = repo.row('SELECT * FROM users WHERE lower(email) = lower(?)', String(email || '').trim());
  if (!user || !verifyPassword(password, user.password_hash)) {
    return { error: 'INVALID_CREDENTIALS', message: 'Invalid email or password.' };
  }
  if (user.status !== 'active') return { error: 'ACCOUNT_DISABLED', message: 'Account is not active.' };
  if (user.mfa_enabled) {
    if (!totp) return { error: 'MFA_REQUIRED', message: 'MFA code required.', mfaRequired: true };
    if (!verifyTotp(user.mfa_secret, totp)) return { error: 'MFA_INVALID', message: 'Invalid MFA code.', mfaRequired: true };
  }
  const session = issueSession({ user, userAgent, ip });
  repo.update('users', user.tenant_id, user.id, { last_login_at: new Date().toISOString() });
  repo.audit({ tenantId: user.tenant_id, entity: 'auth', entityId: user.id, action: 'login', userId: user.id, ip });
  return { ...session, user: publicUser(user) };
}

function issueSession({ user, userAgent, ip }) {
  const accessToken = signJwt(
    { sub: user.id, tenantId: user.tenant_id, role: getRoles(user.id)[0]?.name || 'User', email: user.email },
    config.ACCESS_TOKEN_TTL,
  );
  const refreshToken = randomToken(40);
  const sessionId = uuid();
  const expires = new Date(Date.now() + config.REFRESH_TOKEN_TTL * 1000).toISOString();
  repo.run(
    'INSERT INTO sessions (id, tenant_id, user_id, refresh_hash, user_agent, ip, expires_at, revoked, created_at) VALUES (?,?,?,?,?,?,?,0,?)',
    sessionId, user.tenant_id, user.id, hashApiKey(refreshToken), userAgent || '', ip || '', expires, new Date().toISOString(),
  );
  return { accessToken, refreshToken, expiresIn: config.ACCESS_TOKEN_TTL, sessionId };
}

function refresh({ refreshToken, userAgent, ip }) {
  if (!refreshToken) return { error: 'NO_TOKEN', message: 'Refresh token required.' };
  const session = repo.row('SELECT * FROM sessions WHERE refresh_hash = ? AND revoked = 0', hashApiKey(refreshToken));
  if (!session) return { error: 'INVALID_TOKEN', message: 'Invalid refresh token.' };
  if (new Date(session.expires_at).getTime() < Date.now()) return { error: 'EXPIRED', message: 'Refresh token expired.' };
  const user = repo.get('users', session.tenant_id, session.user_id);
  if (!user) return { error: 'INVALID_TOKEN', message: 'User not found.' };
  repo.run('UPDATE sessions SET revoked = 1 WHERE id = ?', session.id);
  return { ...issueSession({ user, userAgent, ip }), user: publicUser(user) };
}

function logout({ refreshToken, accessToken }) {
  if (refreshToken) repo.run('UPDATE sessions SET revoked = 1 WHERE refresh_hash = ?', hashApiKey(refreshToken));
  const payload = accessToken ? verifyJwt(accessToken) : null;
  if (payload) repo.audit({ tenantId: payload.tenantId, entity: 'auth', entityId: payload.sub, action: 'logout', userId: payload.sub });
  return { ok: true };
}

function setupMfa({ user }) {
  const secret = generateTotpSecret();
  repo.update('users', user.tenant_id, user.id, { mfa_secret: secret, mfa_enabled: 0 });
  return { secret, otpauthUri: totpUri(secret, user.email) };
}

function enableMfa({ user, totp }) {
  const fresh = repo.get('users', user.tenant_id, user.id);
  if (!fresh?.mfa_secret) return { error: 'NO_SECRET', message: 'Call MFA setup first.' };
  if (!verifyTotp(fresh.mfa_secret, totp)) return { error: 'MFA_INVALID', message: 'Invalid code.' };
  repo.update('users', user.tenant_id, user.id, { mfa_enabled: 1 });
  repo.audit({ tenantId: user.tenant_id, entity: 'security', entityId: user.id, action: 'mfa_enabled', userId: user.id });
  return { ok: true };
}

function disableMfa({ user, totp }) {
  const fresh = repo.get('users', user.tenant_id, user.id);
  if (fresh?.mfa_enabled && !verifyTotp(fresh.mfa_secret, totp)) return { error: 'MFA_INVALID', message: 'Invalid code.' };
  repo.update('users', user.tenant_id, user.id, { mfa_enabled: 0, mfa_secret: null });
  return { ok: true };
}

function createUser({ tenantId, actorId, email, password, displayName = '', roleName = 'User' }) {
  const existing = repo.row('SELECT id FROM users WHERE tenant_id = ? AND lower(email) = lower(?)', tenantId, email);
  if (existing) return { error: 'DUPLICATE', message: 'A user with that email already exists.' };
  const user = repo.insert('users', tenantId, {
    email: String(email).toLowerCase(), display_name: displayName || email.split('@')[0],
    password_hash: hashPassword(password), status: 'active', settings: {}, updated_at: new Date().toISOString(),
  });
  const role = repo.row('SELECT id FROM roles WHERE tenant_id IS NULL AND name = ?', roleName);
  if (role) repo.run('INSERT OR IGNORE INTO user_roles (user_id, role_id, granted_at) VALUES (?,?,?)', user.id, role.id, new Date().toISOString());
  repo.audit({ tenantId, entity: 'user', entityId: user.id, action: 'create', userId: actorId, metadata: { roleName } });
  return { user: publicUser(user) };
}

/** Resolve a request identity from either a JWT or an API key. */
function authenticate({ authorization, apiKey }) {
  if (apiKey) {
    const hash = hashApiKey(apiKey);
    const key = repo.row('SELECT * FROM api_keys WHERE key_hash = ? AND status = ?', hash, 'active');
    if (!key) return null;
    repo.run('UPDATE api_keys SET last_used_at = ? WHERE id = ?', new Date().toISOString(), key.id);
    const user = key.user_id ? repo.get('users', key.tenant_id, key.user_id) : null;
    return { userId: user?.id || null, tenantId: key.tenant_id, role: 'ApiKey', viaApiKey: true, scopes: safeJson(key.scopes, []) };
  }
  const token = String(authorization || '').replace(/^Bearer\s+/i, '');
  const payload = verifyJwt(token);
  if (!payload) return null;
  return { userId: payload.sub, tenantId: payload.tenantId, role: payload.role, email: payload.email };
}

function hasPermission(identity, code) {
  if (!identity) return false;
  if (identity.viaApiKey) return (identity.scopes || []).includes(code) || (identity.scopes || []).includes('*');
  const perms = getPermissions(identity.userId);
  return perms.includes(code) || perms.includes('platform.admin');
}

function safeJson(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

module.exports = {
  bootstrap, login, logout, refresh, issueSession,
  getRoles, getPermissions, publicUser, createUser,
  setupMfa, enableMfa, disableMfa, authenticate, hasPermission,
};
