'use strict';
/**
 * knowledge.js - the Knowledge Brain: RAG ingestion, embeddings, vector search,
 * semantic search, knowledge graph foundations, memory and context injection.
 */
const repo = require('./repo');
const providers = require('./providers');

const CATEGORIES = [
  'Business', 'Marketing', 'Sales', 'Finance', 'Software', 'Design', 'Comics',
  'Publishing', 'Games', 'Video', 'Music', 'Healthcare', 'Education', 'Legal', 'Operations',
];

const MEMORY_SCOPES = [
  'Universe Memory', 'Project Memory', 'Agent Memory', 'Worker Memory', 'Character Memory',
  'Business Memory', 'Personal Memory', 'Document Memory', 'Archive Memory',
];

function chunk(text, size = 1200, overlap = 150) {
  const clean = String(text).replace(/\r\n/g, '\n').trim();
  if (clean.length <= size) return [clean];
  const out = [];
  let i = 0;
  while (i < clean.length) {
    out.push(clean.slice(i, i + size));
    i += size - overlap;
  }
  return out;
}

async function ingest({ tenantId, title, content, category = 'Business', projectId = null, source = 'manual', metadata = {}, vaultLookup }) {
  const parts = chunk(content);
  const created = [];
  for (let i = 0; i < parts.length; i++) {
    const emb = await providers.embed(parts[i], { vaultLookup });
    const node = repo.insert('knowledge_nodes', tenantId, {
      category: CATEGORIES.includes(category) ? category : 'Business',
      title: parts.length > 1 ? `${title} (${i + 1}/${parts.length})` : title,
      content: parts[i],
      source,
      project_id: projectId,
      parent_id: null,
      embedding: JSON.stringify(emb.vector),
      dim: emb.dim,
      metadata: { ...metadata, chunk: i, chunks: parts.length, embedding_model: emb.model },
      updated_at: repo.db().prepare('SELECT datetime(\'now\') AS t').get().t,
    });
    created.push(node);
  }
  return created;
}

function parseEmbedding(node) {
  try { return JSON.parse(node.embedding || '[]'); } catch { return []; }
}

/** Vector + lexical hybrid search across knowledge nodes. */
async function search({ tenantId, query, category = null, limit = 8, vaultLookup }) {
  const emb = await providers.embed(query, { vaultLookup });
  const params = [];
  const clauses = [];
  if (category) { clauses.push('category = ?'); params.push(category); }
  const where = clauses.join(' AND ');
  const nodes = repo.list('knowledge_nodes', tenantId, { where, params, limit: 2000, order: 'created_at DESC' });
  const qTerms = new Set((String(query).toLowerCase().match(/[a-z0-9]+/g) || []).filter((t) => t.length > 2));
  const scored = nodes.map((n) => {
    const vec = parseEmbedding(n);
    const semantic = vec.length ? providers.cosine(emb.vector, vec) : 0;
    const text = `${n.title} ${n.content}`.toLowerCase();
    let lexical = 0;
    for (const t of qTerms) if (text.includes(t)) lexical += 1;
    lexical = qTerms.size ? lexical / qTerms.size : 0;
    const score = 0.7 * semantic + 0.3 * lexical;
    return { node: n, score, semantic, lexical };
  }).filter((s) => s.score > 0.02)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  return { query, embeddingModel: emb.model, degraded: emb.degraded, results: scored };
}

/** Retrieve grounding context for a task (context injection). */
async function contextFor({ tenantId, query, limit = 5, vaultLookup }) {
  const { results } = await search({ tenantId, query, limit, vaultLookup });
  if (!results.length) return '';
  return results.map((r, i) => `[${i + 1}] (${r.node.category}) ${r.node.title}\n${r.node.content.slice(0, 600)}`).join('\n\n');
}

/** Knowledge graph neighbourhood (parent/child + category peers). */
function graph({ tenantId, nodeId, depth = 1 }) {
  const root = repo.get('knowledge_nodes', tenantId, nodeId);
  if (!root) return null;
  const visited = new Set([root.id]);
  let frontier = [root];
  for (let d = 0; d < depth; d++) {
    const next = [];
    for (const n of frontier) {
      const children = repo.rows('SELECT * FROM knowledge_nodes WHERE tenant_id = ? AND parent_id = ?', tenantId, n.id);
      const parent = n.parent_id ? repo.get('knowledge_nodes', tenantId, n.parent_id) : null;
      for (const c of [...children, ...(parent ? [parent] : [])]) {
        if (c && !visited.has(c.id)) { visited.add(c.id); next.push(c); }
      }
    }
    frontier = next;
  }
  return { root, neighbors: [...visited].filter((id) => id !== root.id).map((id) => repo.get('knowledge_nodes', tenantId, id)) };
}

/* -------------------------------- memory ---------------------------------- */
async function remember({ tenantId, scope = 'Project Memory', ownerType = 'project', ownerId = null, projectId = null, key = '', content, importance = 5, metadata = {}, vaultLookup }) {
  const emb = await providers.embed(content, { vaultLookup });
  return repo.insert('memories', tenantId, {
    scope: MEMORY_SCOPES.includes(scope) ? scope : 'Project Memory',
    owner_type: ownerType,
    owner_id: ownerId,
    project_id: projectId,
    key,
    content,
    importance,
    embedding: JSON.stringify(emb.vector),
    metadata,
  });
}

async function recall({ tenantId, query, scope = null, ownerId = null, limit = 5, vaultLookup }) {
  const emb = await providers.embed(query, { vaultLookup });
  const params = [];
  const clauses = [];
  if (scope) { clauses.push('scope = ?'); params.push(scope); }
  if (ownerId) { clauses.push('owner_id = ?'); params.push(ownerId); }
  const where = clauses.join(' AND ');
  const mems = repo.list('memories', tenantId, { where, params, limit: 2000, order: 'created_at DESC' });
  return mems.map((m) => {
    let vec = [];
    try { vec = JSON.parse(m.embedding || '[]'); } catch { /* ignore */ }
    const sim = vec.length ? providers.cosine(emb.vector, vec) : 0;
    return { memory: m, score: sim * (0.6 + m.importance / 20) };
  }).sort((a, b) => b.score - a.score).slice(0, limit);
}

module.exports = { CATEGORIES, MEMORY_SCOPES, chunk, ingest, search, contextFor, graph, remember, recall };
