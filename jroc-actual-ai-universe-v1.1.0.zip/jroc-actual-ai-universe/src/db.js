'use strict';
/**
 * db.js - the complete J-Roc's Actual AI Universe(TM) persistence layer.
 *
 * Engine: SQLite (node:sqlite, built into Node 22.5+/24). Portable, zero-setup,
 * ACID, single-file. The schema is written in a PostgreSQL-compatible shape
 * (UUID text PKs, JSONB-equivalent TEXT/JSON columns, TIMESTAMPTZ ISO strings,
 * vector embeddings stored as JSON float arrays) so it maps 1:1 onto the
 * Postgres + pgvector target documented in docs/DATABASE.md.
 *
 * Tenant isolation is enforced at BOTH layers, mirroring the spec:
 *   1. Application layer: every repository call takes a tenantId and injects
 *      `WHERE tenant_id = ?` (see src/repo.js).
 *   2. Database layer: SQLite triggers abort any write whose tenant_id does not
 *      match the session tenant set via `PRAGMA`-backed app_tenant table. (RLS
 *      equivalent - see SCHEMA / TRIGGERS at the bottom.)
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');
const freemodels = require('./freemodels');

const SCHEMA = `
-- ============================ 001 extensions ================================
-- (SQLite has no extensions; the Postgres build enables: uuid-ossp, pgcrypto, vector)

-- ============================== 002 tenants ================================
CREATE TABLE IF NOT EXISTS tenants (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  slug          TEXT NOT NULL UNIQUE,
  status        TEXT NOT NULL DEFAULT 'active',
  plan          TEXT NOT NULL DEFAULT 'private',
  settings      TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

-- =============================== 003 users =================================
CREATE TABLE IF NOT EXISTS users (
  id             TEXT PRIMARY KEY,
  tenant_id      TEXT NOT NULL REFERENCES tenants(id),
  email          TEXT NOT NULL,
  display_name   TEXT NOT NULL DEFAULT '',
  password_hash  TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'active',
  mfa_enabled    INTEGER NOT NULL DEFAULT 0,
  mfa_secret     TEXT,
  avatar_url     TEXT,
  settings       TEXT NOT NULL DEFAULT '{}',
  last_login_at  TEXT,
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL,
  UNIQUE (tenant_id, email)
);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- =============================== 004 roles =================================
CREATE TABLE IF NOT EXISTS roles (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT,                       -- NULL = system role, available to all tenants
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  is_system   INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL,
  UNIQUE (tenant_id, name)
);

-- ============================ 005 permissions ==============================
CREATE TABLE IF NOT EXISTS permissions (
  id          TEXT PRIMARY KEY,
  code        TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id       TEXT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id TEXT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);
CREATE TABLE IF NOT EXISTS user_roles (
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id    TEXT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  granted_at TEXT NOT NULL,
  PRIMARY KEY (user_id, role_id)
);

-- ============================== 006 projects ===============================
CREATE TABLE IF NOT EXISTS projects (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  name         TEXT NOT NULL,
  goal         TEXT NOT NULL DEFAULT '',
  description  TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'active',
  priority     TEXT NOT NULL DEFAULT 'normal',
  owner_id     TEXT REFERENCES users(id),
  metadata     TEXT NOT NULL DEFAULT '{}',
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_tenant ON projects(tenant_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(tenant_id, status);

CREATE TABLE IF NOT EXISTS blueprints (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL REFERENCES tenants(id),
  project_id    TEXT REFERENCES projects(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  output_type   TEXT NOT NULL DEFAULT 'application',
  architecture  TEXT NOT NULL DEFAULT '{}',
  requirements  TEXT NOT NULL DEFAULT '[]',
  tasks         TEXT NOT NULL DEFAULT '[]',
  status        TEXT NOT NULL DEFAULT 'draft',
  version       INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_blueprints_tenant ON blueprints(tenant_id);
CREATE INDEX IF NOT EXISTS idx_blueprints_project ON blueprints(project_id);

-- =============================== 007 agents ================================
CREATE TABLE IF NOT EXISTS agents (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL REFERENCES tenants(id),
  name          TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'generalist',
  system_prompt TEXT NOT NULL DEFAULT '',
  brain_profile TEXT,
  memory_scope  TEXT NOT NULL DEFAULT 'agent',
  project_id    TEXT REFERENCES projects(id) ON DELETE SET NULL,
  status        TEXT NOT NULL DEFAULT 'idle',
  config        TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agents_tenant ON agents(tenant_id);
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(tenant_id, status);

-- =============================== 008 workers ===============================
CREATE TABLE IF NOT EXISTS workers (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL REFERENCES tenants(id),
  agent_id      TEXT REFERENCES agents(id) ON DELETE SET NULL,
  department_id TEXT,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'worker',
  skills        TEXT NOT NULL DEFAULT '[]',
  permissions   TEXT NOT NULL DEFAULT '[]',
  brain_profile TEXT,
  memory_scope  TEXT NOT NULL DEFAULT 'worker',
  status        TEXT NOT NULL DEFAULT 'idle',
  config        TEXT NOT NULL DEFAULT '{}',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workers_tenant ON workers(tenant_id);
CREATE INDEX IF NOT EXISTS idx_workers_agent ON workers(agent_id);
CREATE INDEX IF NOT EXISTS idx_workers_status ON workers(tenant_id, status);

-- ================================ 009 teams ================================
CREATE TABLE IF NOT EXISTS teams (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  department_id TEXT,
  name         TEXT NOT NULL,
  purpose      TEXT NOT NULL DEFAULT '',
  strategy     TEXT NOT NULL DEFAULT 'parallel',
  status       TEXT NOT NULL DEFAULT 'active',
  config       TEXT NOT NULL DEFAULT '{}',
  created_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS team_members (
  team_id   TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  member_type TEXT NOT NULL,             -- 'agent' | 'worker'
  member_id TEXT NOT NULL,
  PRIMARY KEY (team_id, member_type, member_id)
);

-- ============================= 010 departments =============================
CREATE TABLE IF NOT EXISTS departments (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  name        TEXT NOT NULL,
  mandate     TEXT NOT NULL DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'active',
  created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS department_members (
  department_id TEXT NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  member_type   TEXT NOT NULL,
  member_id     TEXT NOT NULL,
  PRIMARY KEY (department_id, member_type, member_id)
);

-- =============================== 011 swarms ================================
CREATE TABLE IF NOT EXISTS swarms (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  project_id  TEXT REFERENCES projects(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  objective   TEXT NOT NULL DEFAULT '',
  topology    TEXT NOT NULL DEFAULT 'mesh',   -- mesh | star | pipeline | hierarchical
  status      TEXT NOT NULL DEFAULT 'idle',
  config      TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS swarm_members (
  swarm_id    TEXT NOT NULL REFERENCES swarms(id) ON DELETE CASCADE,
  worker_id   TEXT NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  role        TEXT NOT NULL DEFAULT 'member',
  PRIMARY KEY (swarm_id, worker_id)
);

-- =========================== 012 brain_profiles ============================
CREATE TABLE IF NOT EXISTS brain_profiles (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT,                       -- NULL = system profile
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  mode        TEXT NOT NULL DEFAULT 'single', -- single|dual|triple|consensus|rotating
  strategy    TEXT NOT NULL DEFAULT '{}',
  is_system   INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);

-- =============================== 013 models ================================
CREATE TABLE IF NOT EXISTS models (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT,
  provider     TEXT NOT NULL,
  name         TEXT NOT NULL,
  model_id     TEXT NOT NULL,
  base_url     TEXT NOT NULL DEFAULT '',
  kind         TEXT NOT NULL DEFAULT 'cloud',
  capabilities TEXT NOT NULL DEFAULT '[]',
  context_window INTEGER NOT NULL DEFAULT 0,
  cost_in      REAL NOT NULL DEFAULT 0,
  cost_out     REAL NOT NULL DEFAULT 0,
  speed        INTEGER NOT NULL DEFAULT 5,
  quality      INTEGER NOT NULL DEFAULT 5,
  enabled      INTEGER NOT NULL DEFAULT 1,
  free_tier    INTEGER NOT NULL DEFAULT 0,
  rate_limit   TEXT NOT NULL DEFAULT '{}',
  docs_url     TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS brain_models (
  brain_profile_id TEXT NOT NULL REFERENCES brain_profiles(id) ON DELETE CASCADE,
  model_id         TEXT NOT NULL REFERENCES models(id) ON DELETE CASCADE,
  weight           REAL NOT NULL DEFAULT 1.0,
  ordinal          INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (brain_profile_id, model_id)
);

-- ============================ 014 router_rules =============================
CREATE TABLE IF NOT EXISTS router_rules (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT,
  name        TEXT NOT NULL,
  task_type   TEXT NOT NULL,
  match_expr  TEXT NOT NULL DEFAULT '{}',
  target_provider TEXT,
  target_model_id TEXT,
  brain_profile_id TEXT,
  priority    INTEGER NOT NULL DEFAULT 100,
  enabled     INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_router_rules_task ON router_rules(task_type, priority);

-- =========================== 015 knowledge_nodes ===========================
CREATE TABLE IF NOT EXISTS knowledge_nodes (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  category    TEXT NOT NULL DEFAULT 'Business',
  title       TEXT NOT NULL,
  content     TEXT NOT NULL DEFAULT '',
  source      TEXT NOT NULL DEFAULT 'manual',
  project_id  TEXT REFERENCES projects(id) ON DELETE SET NULL,
  parent_id   TEXT REFERENCES knowledge_nodes(id) ON DELETE SET NULL,
  embedding   TEXT NOT NULL DEFAULT '[]',   -- VECTOR(1536) in Postgres
  dim         INTEGER NOT NULL DEFAULT 1536,
  metadata    TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_knowledge_tenant ON knowledge_nodes(tenant_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_nodes(tenant_id, category);

-- ============================= 016 memories ================================
CREATE TABLE IF NOT EXISTS memories (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  scope       TEXT NOT NULL DEFAULT 'Project Memory',
  owner_type  TEXT NOT NULL DEFAULT 'project',
  owner_id    TEXT,
  project_id  TEXT REFERENCES projects(id) ON DELETE SET NULL,
  key         TEXT NOT NULL DEFAULT '',
  content     TEXT NOT NULL,
  importance  INTEGER NOT NULL DEFAULT 5,
  embedding   TEXT NOT NULL DEFAULT '[]',
  metadata    TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_memories_tenant ON memories(tenant_id);
CREATE INDEX IF NOT EXISTS idx_memories_owner ON memories(owner_type, owner_id);

-- ============================== 017 plugins ================================
CREATE TABLE IF NOT EXISTS plugins (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  name         TEXT NOT NULL,
  provider     TEXT NOT NULL,
  category     TEXT NOT NULL DEFAULT 'custom',
  status       TEXT NOT NULL DEFAULT 'disconnected',
  config       TEXT NOT NULL DEFAULT '{}',
  last_tested_at TEXT,
  last_test_ok INTEGER,
  created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_plugins_tenant ON plugins(tenant_id);

-- ============================ 018 connectors ===============================
CREATE TABLE IF NOT EXISTS connectors (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  plugin_id    TEXT REFERENCES plugins(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  kind         TEXT NOT NULL DEFAULT 'REST',  -- REST|GraphQL|Database|Local|Internal
  base_url     TEXT NOT NULL DEFAULT '',
  spec         TEXT NOT NULL DEFAULT '{}',
  status       TEXT NOT NULL DEFAULT 'active',
  created_at   TEXT NOT NULL
);

-- ============================ 019 workflows ================================
CREATE TABLE IF NOT EXISTS workflows (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  project_id  TEXT REFERENCES projects(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  definition  TEXT NOT NULL DEFAULT '{"steps":[]}',   -- JSONB
  status      TEXT NOT NULL DEFAULT 'active',
  version     INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workflows_tenant ON workflows(tenant_id);

-- =========================== 020 automations ===============================
CREATE TABLE IF NOT EXISTS automations (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  name        TEXT NOT NULL,
  trigger     TEXT NOT NULL DEFAULT '{}',
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  cron        TEXT,
  enabled     INTEGER NOT NULL DEFAULT 1,
  last_run_at TEXT,
  next_run_at TEXT,
  created_at  TEXT NOT NULL
);

-- =============================== 021 assets ================================
CREATE TABLE IF NOT EXISTS assets (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  project_id  TEXT REFERENCES projects(id) ON DELETE SET NULL,
  job_id      TEXT,
  name        TEXT NOT NULL,
  asset_type  TEXT NOT NULL DEFAULT 'document',
  mime_type   TEXT NOT NULL DEFAULT 'text/plain',
  file_path   TEXT NOT NULL DEFAULT '',
  content     TEXT,
  size_bytes  INTEGER NOT NULL DEFAULT 0,
  checksum    TEXT NOT NULL DEFAULT '',
  version     INTEGER NOT NULL DEFAULT 1,
  metadata    TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assets_tenant ON assets(tenant_id);
CREATE INDEX IF NOT EXISTS idx_assets_project ON assets(project_id);

-- ============================== 022 prompts ================================
CREATE TABLE IF NOT EXISTS prompts (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT,
  name        TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'general',
  body        TEXT NOT NULL,
  variables   TEXT NOT NULL DEFAULT '[]',
  version     INTEGER NOT NULL DEFAULT 1,
  is_system   INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

-- =============================== 023 skills ================================
CREATE TABLE IF NOT EXISTS skills (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT,
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category    TEXT NOT NULL DEFAULT 'general',
  spec        TEXT NOT NULL DEFAULT '{}',
  is_system   INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS agent_skills (
  agent_id  TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  skill_id  TEXT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  level     INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (agent_id, skill_id)
);
CREATE TABLE IF NOT EXISTS worker_skills (
  worker_id TEXT NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  skill_id  TEXT NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  level     INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (worker_id, skill_id)
);

-- ============================ 024 deployments ==============================
CREATE TABLE IF NOT EXISTS deployments (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  project_id   TEXT REFERENCES projects(id) ON DELETE SET NULL,
  target       TEXT NOT NULL DEFAULT 'web',    -- web|mobile|desktop|docker|cloud|private
  environment  TEXT NOT NULL DEFAULT 'production',
  version      TEXT NOT NULL DEFAULT '1.0.0',
  status       TEXT NOT NULL DEFAULT 'pending',
  endpoint     TEXT NOT NULL DEFAULT '',
  config       TEXT NOT NULL DEFAULT '{}',
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deployments_tenant ON deployments(tenant_id);
CREATE TABLE IF NOT EXISTS deployment_events (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL,
  deployment_id TEXT NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
  event         TEXT NOT NULL,
  detail        TEXT NOT NULL DEFAULT '',
  created_at    TEXT NOT NULL
);

-- ============================ 025 audit_logs ===============================
CREATE TABLE IF NOT EXISTS audit_logs (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL,
  entity      TEXT NOT NULL,
  entity_id   TEXT,
  action      TEXT NOT NULL,
  user_id     TEXT,
  metadata    TEXT NOT NULL DEFAULT '{}',
  ip          TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_logs(tenant_id, created_at);

-- =========================== 026 notifications =============================
CREATE TABLE IF NOT EXISTS notifications (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL,
  user_id     TEXT,
  level       TEXT NOT NULL DEFAULT 'info',
  title       TEXT NOT NULL,
  body        TEXT NOT NULL DEFAULT '',
  read        INTEGER NOT NULL DEFAULT 0,
  metadata    TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(tenant_id, user_id, read);

-- ============================= 027 api_keys ================================
CREATE TABLE IF NOT EXISTS api_keys (
  id          TEXT PRIMARY KEY,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id),
  user_id     TEXT,
  name        TEXT NOT NULL,
  prefix      TEXT NOT NULL,
  key_hash    TEXT NOT NULL UNIQUE,
  scopes      TEXT NOT NULL DEFAULT '[]',
  status      TEXT NOT NULL DEFAULT 'active',
  last_used_at TEXT,
  created_at  TEXT NOT NULL
);

-- ============================== 028 secrets ================================
CREATE TABLE IF NOT EXISTS secrets (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  name         TEXT NOT NULL,
  provider     TEXT NOT NULL DEFAULT 'generic',
  ciphertext   TEXT NOT NULL,             -- AES-256-GCM encrypted at rest
  hint         TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'active',
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL,
  UNIQUE (tenant_id, name)
);

-- ========================= 029 sessions / refresh ==========================
CREATE TABLE IF NOT EXISTS sessions (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL,
  user_id       TEXT NOT NULL,
  refresh_hash  TEXT NOT NULL,
  user_agent    TEXT,
  ip            TEXT,
  expires_at    TEXT NOT NULL,
  revoked       INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- ========================= 030 jobs / builds ===============================
CREATE TABLE IF NOT EXISTS jobs (
  id           TEXT PRIMARY KEY,
  tenant_id    TEXT NOT NULL REFERENCES tenants(id),
  project_id   TEXT REFERENCES projects(id) ON DELETE SET NULL,
  workflow_id  TEXT,
  agent_id     TEXT,
  worker_id    TEXT,
  parent_id    TEXT,
  kind         TEXT NOT NULL DEFAULT 'task',
  name         TEXT NOT NULL,
  payload      TEXT NOT NULL DEFAULT '{}',
  result       TEXT NOT NULL DEFAULT '{}',
  status       TEXT NOT NULL DEFAULT 'queued',
  state_log    TEXT NOT NULL DEFAULT '[]',
  progress     INTEGER NOT NULL DEFAULT 0,
  attempts     INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 3,
  error        TEXT,
  brain        TEXT,
  model        TEXT,
  tokens_in    INTEGER NOT NULL DEFAULT 0,
  tokens_out   INTEGER NOT NULL DEFAULT 0,
  cost         REAL NOT NULL DEFAULT 0,
  duration_ms  INTEGER NOT NULL DEFAULT 0,
  started_at   TEXT,
  finished_at  TEXT,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant ON jobs(tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_jobs_queue ON jobs(status, created_at);
CREATE INDEX IF NOT EXISTS idx_jobs_project ON jobs(project_id);

-- Builds (the Universal Builder's persisted unit of work)
CREATE TABLE IF NOT EXISTS builds (
  id            TEXT PRIMARY KEY,
  tenant_id     TEXT NOT NULL REFERENCES tenants(id),
  project_id    TEXT REFERENCES projects(id) ON DELETE CASCADE,
  blueprint_id  TEXT REFERENCES blueprints(id) ON DELETE SET NULL,
  goal          TEXT NOT NULL,
  output_type   TEXT NOT NULL DEFAULT 'application',
  priority      TEXT NOT NULL DEFAULT 'normal',
  status        TEXT NOT NULL DEFAULT 'planning',
  assigned_brain TEXT NOT NULL DEFAULT 'Executive Brain',
  plan          TEXT NOT NULL DEFAULT '{}',
  result        TEXT NOT NULL DEFAULT '{}',
  error         TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_builds_tenant ON builds(tenant_id, status);

-- ==================== tenant isolation guard (RLS equiv) ===================
-- A session-scoped tenant is set by the repository layer. These triggers make
-- it impossible for a write to land on a row whose tenant_id differs from the
-- active session tenant, mirroring PostgreSQL ROW LEVEL SECURITY.
CREATE TABLE IF NOT EXISTS _app_session (
  k TEXT PRIMARY KEY,
  v TEXT
);
INSERT OR IGNORE INTO _app_session(k, v) VALUES ('tenant_id', '');
`;

const SEED_PERMISSIONS = [
  'platform.read', 'platform.write', 'platform.admin',
  'projects.read', 'projects.write',
  'agents.read', 'agents.write',
  'workers.read', 'workers.write',
  'teams.read', 'teams.write',
  'workflows.read', 'workflows.write',
  'knowledge.read', 'knowledge.write',
  'models.read', 'models.write',
  'plugins.read', 'plugins.write',
  'deployments.read', 'deployments.write',
  'audit.read', 'security.admin',
];

const SEED_ROLE_MATRIX = {
  Chairman: '*',
  Admin: SEED_PERMISSIONS.filter((p) => p !== 'platform.admin' || true),
  Manager: [
    'platform.read', 'projects.read', 'projects.write', 'agents.read', 'agents.write',
    'workers.read', 'workers.write', 'teams.read', 'teams.write', 'workflows.read',
    'workflows.write', 'knowledge.read', 'knowledge.write', 'models.read',
    'plugins.read', 'deployments.read', 'deployments.write', 'audit.read',
  ],
  Agent: [
    'platform.read', 'projects.read', 'agents.read', 'workers.read', 'teams.read',
    'knowledge.read', 'knowledge.write', 'workflows.read', 'models.read',
  ],
  Worker: ['platform.read', 'projects.read', 'knowledge.read', 'models.read'],
  User: ['platform.read', 'projects.read', 'knowledge.read'],
};

const SEED_BRAIN_PROFILES = [
  { name: 'Executive Brain', mode: 'triple', description: 'Top-level orchestration, strategy and cross-department coordination.', strategy: { routing: 'quality', consensus: true } },
  { name: 'Coding Brain', mode: 'single', description: 'Software engineering, code generation and review.', strategy: { routing: 'quality', taskTypes: ['coding'] } },
  { name: 'Research Brain', mode: 'dual', description: 'Deep research, synthesis and citation.', strategy: { routing: 'quality', taskTypes: ['research'] } },
  { name: 'Reasoning Brain', mode: 'single', description: 'Step-by-step reasoning and analysis.', strategy: { routing: 'quality', taskTypes: ['reasoning'] } },
  { name: 'Creative Brain', mode: 'single', description: 'Creative writing, ideation and design.', strategy: { routing: 'quality', taskTypes: ['creativity'] } },
  { name: 'Planning Brain', mode: 'dual', description: 'Project planning, decomposition and sequencing.', strategy: { routing: 'quality', taskTypes: ['planning'] } },
  { name: 'Validation Brain', mode: 'single', description: 'Verification, QA and adversarial review.', strategy: { routing: 'quality', taskTypes: ['validation'] } },
  { name: 'Consensus Brain', mode: 'consensus', description: 'Runs multiple models and reconciles a consensus answer.', strategy: { routing: 'quality', consensus: true } },
  { name: 'Free Tier Brain', mode: 'dual', description: 'Runs exclusively on free-forever providers — OpenRouter, Groq, Google AI Studio, Cerebras, GitHub Models, Cloudflare, Mistral, Hugging Face, SambaNova and local Ollama.', strategy: { routing: 'free', freeOnly: true } },
];

const SEED_MODELS = [
  { provider: 'deepseek', name: 'DeepSeek Chat', model_id: 'deepseek-chat', capabilities: ['reasoning', 'coding', 'research', 'writing', 'analysis'], context_window: 65536, cost_in: 0.27, cost_out: 1.10, speed: 7, quality: 8 },
  { provider: 'deepseek', name: 'DeepSeek Reasoner', model_id: 'deepseek-reasoner', capabilities: ['reasoning', 'analysis'], context_window: 65536, cost_in: 0.55, cost_out: 2.19, speed: 5, quality: 9 },
  { provider: 'mistral', name: 'Mistral Large', model_id: 'mistral-large-latest', capabilities: ['reasoning', 'coding', 'research', 'writing', 'planning'], context_window: 131072, cost_in: 2.0, cost_out: 6.0, speed: 7, quality: 8 },
  { provider: 'mistral', name: 'Mistral Small', model_id: 'mistral-small-latest', capabilities: ['writing', 'analysis', 'creativity'], context_window: 131072, cost_in: 0.2, cost_out: 0.6, speed: 9, quality: 6 },
  { provider: 'qwen', name: 'Qwen Max', model_id: 'qwen-max', capabilities: ['reasoning', 'coding', 'research', 'writing', 'planning', 'creativity'], context_window: 32768, cost_in: 1.6, cost_out: 6.4, speed: 6, quality: 8 },
  { provider: 'qwen', name: 'Qwen Plus', model_id: 'qwen-plus', capabilities: ['writing', 'analysis', 'creativity'], context_window: 131072, cost_in: 0.4, cost_out: 1.2, speed: 8, quality: 7 },
  { provider: 'grok', name: 'Grok 2', model_id: 'grok-2-latest', capabilities: ['reasoning', 'research', 'creativity', 'writing', 'analysis'], context_window: 131072, cost_in: 2.0, cost_out: 10.0, speed: 7, quality: 8 },
  { provider: 'ollama', name: 'Ollama Local', model_id: 'llama3.1', capabilities: ['reasoning', 'writing', 'coding', 'analysis'], context_window: 131072, cost_in: 0, cost_out: 0, speed: 6, quality: 6 },
];

const SEED_ROUTER_RULES = [
  { name: 'Coding -> DeepSeek', task_type: 'coding', target_provider: 'deepseek', priority: 10 },
  { name: 'Reasoning -> DeepSeek Reasoner', task_type: 'reasoning', target_provider: 'deepseek', priority: 10 },
  { name: 'Research -> Mistral Large', task_type: 'research', target_provider: 'mistral', priority: 20 },
  { name: 'Planning -> Mistral Large', task_type: 'planning', target_provider: 'mistral', priority: 20 },
  { name: 'Creativity -> Qwen Max', task_type: 'creativity', target_provider: 'qwen', priority: 20 },
  { name: 'Analysis -> Grok', task_type: 'analysis', target_provider: 'grok', priority: 30 },
  { name: 'Writing -> Qwen Plus', task_type: 'writing', target_provider: 'qwen', priority: 30 },
];

const SEED_SKILLS = [
  { name: 'Software Engineering', category: 'Software' },
  { name: 'Research', category: 'Operations' },
  { name: 'Copywriting', category: 'Marketing' },
  { name: 'Design', category: 'Design' },
  { name: 'Data Analysis', category: 'Finance' },
  { name: 'Project Planning', category: 'Operations' },
  { name: 'Comic Art', category: 'Comics' },
  { name: 'Publishing', category: 'Publishing' },
  { name: 'Video Production', category: 'Video' },
  { name: 'Music Production', category: 'Music' },
  { name: 'Game Design', category: 'Games' },
  { name: 'Healthcare Domain', category: 'Healthcare' },
  { name: 'Education', category: 'Education' },
  { name: 'Legal Review', category: 'Legal' },
  { name: 'Sales', category: 'Sales' },
];

const SEED_PROMPTS = [
  { name: 'Intent Analysis', category: 'builder', body: 'You are the Intent Analysis module of J-Roc\'s Actual AI Universe. Given a user goal, return STRICT JSON with keys: intent, goal, outputType (application|content|system|research|media), requirements (array of strings), architecture (object with components array), tasks (array of {title, taskType, description}), suggestedAgents (array of {name, role, systemPrompt}), suggestedWorkers (array of {name, role, skills}), risks (array of strings). No prose outside JSON.' },
  { name: 'J-Roc Executive', category: 'jroc', body: 'You are J-Roc AI, the executive intelligence of J-Roc\'s Actual AI Universe. You advise the Chairman with decisive, concrete, structured guidance. You have authority over projects, blueprints, agents, workers, teams, departments, swarms, knowledge, memory, models, workflows, assets and deployments.' },
  { name: 'Task Executor', category: 'worker', body: 'You are a Worker in J-Roc\'s Actual AI Universe. Complete the assigned task thoroughly and return a concrete deliverable. Be specific, production-grade and complete. Do not use placeholders.' },
  { name: 'Validation', category: 'worker', body: 'You are the Validation Brain. Critically review the deliverable for gaps, errors, placeholders and missing requirements. Return STRICT JSON: {"approved": boolean, "issues": [string], "summary": string}.' },
];

function nowIso() {
  return new Date().toISOString();
}

let _db = null;

function connect() {
  if (_db) return _db;
  const dir = path.dirname(config.DATABASE_FILE);
  if (config.DATABASE_FILE !== ':memory:' && !fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const db = new DatabaseSync(config.DATABASE_FILE);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  migrate(db);
  _db = db;
  seed(db);
  return db;
}

/** Additive migrations for databases created by earlier versions. */
function migrate(db) {
  const columns = (table) => db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  const add = (table, col, ddl) => {
    if (!columns(table).includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${ddl}`);
  };
  add('models', 'free_tier', 'INTEGER NOT NULL DEFAULT 0');
  add('models', 'rate_limit', "TEXT NOT NULL DEFAULT '{}'");
  add('models', 'docs_url', "TEXT NOT NULL DEFAULT ''");
}

function seed(db) {
  const ts = nowIso();
  const run = (sql, ...args) => db.prepare(sql).run(...args);

  // ---- permissions ----
  const permIds = {};
  for (const code of SEED_PERMISSIONS) {
    const existing = db.prepare('SELECT id FROM permissions WHERE code = ?').get(code);
    const id = existing ? existing.id : `perm_${code}`;
    if (!existing) run('INSERT INTO permissions (id, code, description) VALUES (?,?,?)', id, code, code);
    permIds[code] = id;
  }

  // ---- system roles (tenant_id NULL) ----
  const roleIds = {};
  for (const [roleName, perms] of Object.entries(SEED_ROLE_MATRIX)) {
    let row = db.prepare('SELECT id FROM roles WHERE tenant_id IS NULL AND name = ?').get(roleName);
    const id = row ? row.id : `role_${roleName.toLowerCase()}`;
    if (!row) run('INSERT INTO roles (id, tenant_id, name, description, is_system, created_at) VALUES (?,NULL,?,?,1,?)', id, roleName, `${roleName} role`, ts);
    roleIds[roleName] = id;
    const list = perms === '*' ? SEED_PERMISSIONS : perms;
    for (const p of list) {
      run('INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?,?)', id, permIds[p]);
    }
  }

  // ---- brain profiles ----
  for (const bp of SEED_BRAIN_PROFILES) {
    const existing = db.prepare('SELECT id FROM brain_profiles WHERE tenant_id IS NULL AND name = ?').get(bp.name);
    if (!existing) {
      run('INSERT INTO brain_profiles (id, tenant_id, name, description, mode, strategy, is_system, created_at) VALUES (?,NULL,?,?,?,?,1,?)',
        `brain_${bp.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`, bp.name, bp.description, bp.mode, JSON.stringify(bp.strategy), ts);
    }
  }

  // ---- models (paid / own-key providers) ----
  for (const m of SEED_MODELS) {
    const existing = db.prepare('SELECT id FROM models WHERE tenant_id IS NULL AND provider = ? AND model_id = ?').get(m.provider, m.model_id);
    if (!existing) {
      const id = `model_${m.provider}_${m.model_id.replace(/[^a-z0-9]+/gi, '_')}`;
      run(`INSERT INTO models (id, tenant_id, provider, name, model_id, base_url, kind, capabilities, context_window, cost_in, cost_out, speed, quality, enabled, created_at)
           VALUES (?,NULL,?,?,?,?,?,?,?,?,?,?,?,1,?)`,
        id, m.provider, m.name, m.model_id, '', m.provider === 'ollama' ? 'local' : 'cloud',
        JSON.stringify(m.capabilities), m.context_window, m.cost_in, m.cost_out, m.speed, m.quality, ts);
    }
  }

  // ---- models (free-forever tier) ----
  const FREE_PERF = {
    openrouter: { speed: 6, quality: 8 }, groq: { speed: 10, quality: 8 }, gemini: { speed: 8, quality: 9 },
    cerebras: { speed: 10, quality: 8 }, github: { speed: 7, quality: 8 }, cloudflare: { speed: 8, quality: 6 },
    mistralfree: { speed: 7, quality: 7 }, huggingface: { speed: 5, quality: 7 }, sambanova: { speed: 8, quality: 8 },
    ollama: { speed: 6, quality: 6 },
  };
  for (const p of freemodels.FREE_PROVIDERS) {
    const perf = FREE_PERF[p.id] || { speed: 7, quality: 7 };
    for (const m of p.models) {
      const existing = db.prepare('SELECT id FROM models WHERE tenant_id IS NULL AND provider = ? AND model_id = ?').get(p.id, m.id);
      if (existing) {
        run('UPDATE models SET free_tier = 1, rate_limit = ?, docs_url = ? WHERE id = ?',
          JSON.stringify(p.rateLimit || {}), p.docs || '', existing.id);
        continue;
      }
      const id = `model_free_${p.id}_${m.id.replace(/[^a-z0-9]+/gi, '_')}`;
      run(`INSERT INTO models (id, tenant_id, provider, name, model_id, base_url, kind, capabilities, context_window, cost_in, cost_out, speed, quality, enabled, free_tier, rate_limit, docs_url, created_at)
           VALUES (?,NULL,?,?,?,?,?,?,?,0,0,?,?,1,1,?,?,?)`,
        id, p.id, m.name || m.id, m.id, '', p.kind, JSON.stringify(m.capabilities || []),
        m.context || 0, perf.speed, perf.quality, JSON.stringify(p.rateLimit || {}), p.docs || '', ts);
    }
  }

  // ---- brain_models wiring ----
  const bpByName = {};
  for (const r of db.prepare('SELECT id, name FROM brain_profiles WHERE tenant_id IS NULL').all()) bpByName[r.name] = r.id;
  const modelByProvider = {};
  for (const r of db.prepare('SELECT id, provider, model_id FROM models WHERE tenant_id IS NULL').all()) {
    (modelByProvider[r.provider] ||= []).push(r.id);
  }
  const wiring = {
    'Executive Brain': ['deepseek', 'mistral', 'qwen'],
    'Coding Brain': ['deepseek'],
    'Research Brain': ['mistral', 'qwen'],
    'Reasoning Brain': ['deepseek'],
    'Creative Brain': ['qwen'],
    'Planning Brain': ['mistral', 'qwen'],
    'Validation Brain': ['deepseek'],
    'Consensus Brain': ['deepseek', 'mistral', 'qwen', 'grok'],
    'Free Tier Brain': freemodels.FREE_PROVIDERS.map((p) => p.id),
  };
  for (const [brain, providers] of Object.entries(wiring)) {
    const bpId = bpByName[brain];
    if (!bpId) continue;
    const all = brain === 'Free Tier Brain';
    providers.forEach((p, i) => {
      const ids = all ? (modelByProvider[p] || []).slice(0, 2) : (modelByProvider[p] || []).slice(0, 1);
      for (const modelId of ids) {
        run('INSERT OR IGNORE INTO brain_models (brain_profile_id, model_id, weight, ordinal) VALUES (?,?,?,?)', bpId, modelId, 1.0, i);
      }
    });
  }

  // ---- router rules ----
  for (const r of SEED_ROUTER_RULES) {
    const existing = db.prepare('SELECT id FROM router_rules WHERE tenant_id IS NULL AND name = ?').get(r.name);
    if (!existing) {
      run('INSERT INTO router_rules (id, tenant_id, name, task_type, match_expr, target_provider, target_model_id, brain_profile_id, priority, enabled, created_at) VALUES (?,NULL,?,?,?,?,?,?,?,1,?)',
        `rule_${r.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`, r.name, r.task_type, '{}', r.target_provider, null, null, r.priority, ts);
    }
  }

  // ---- skills ----
  for (const s of SEED_SKILLS) {
    const existing = db.prepare('SELECT id FROM skills WHERE tenant_id IS NULL AND name = ?').get(s.name);
    if (!existing) {
      run('INSERT INTO skills (id, tenant_id, name, description, category, spec, is_system, created_at) VALUES (?,NULL,?,?,?,?,1,?)',
        `skill_${s.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`, s.name, s.name, s.category, '{}', ts);
    }
  }

  // ---- prompts ----
  for (const p of SEED_PROMPTS) {
    const existing = db.prepare('SELECT id FROM prompts WHERE tenant_id IS NULL AND name = ?').get(p.name);
    if (!existing) {
      run('INSERT INTO prompts (id, tenant_id, name, category, body, variables, version, is_system, created_at, updated_at) VALUES (?,NULL,?,?,?,?,1,1,?,?)',
        `prompt_${p.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`, p.name, p.category, p.body, '[]', ts, ts);
    }
  }
}

function close() {
  if (_db) { _db.close(); _db = null; }
}

module.exports = { connect, close, nowIso, SCHEMA, SEED_PERMISSIONS, SEED_ROLE_MATRIX };
