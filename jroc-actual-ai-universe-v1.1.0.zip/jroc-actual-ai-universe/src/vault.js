'use strict';
/**
 * vault.js - Secrets Vault + API Key Vault.
 * Provider credentials are AES-256-GCM encrypted at rest. API keys are hashed.
 * The Model Router reads provider keys from here (vault takes precedence over
 * environment variables).
 */
const repo = require('./repo');
const { encryptSecret, decryptSecret, generateApiKey } = require('./crypto');

function setSecret({ tenantId, userId, name, value, provider = 'generic' }) {
  const existing = repo.row('SELECT id FROM secrets WHERE tenant_id = ? AND name = ?', tenantId, name);
  const hint = value ? `${String(value).slice(0, 3)}...${String(value).slice(-3)}` : '';
  const ciphertext = encryptSecret(value);
  let record;
  if (existing) {
    record = repo.update('secrets', tenantId, existing.id, {
      ciphertext, hint, provider, status: 'active', updated_at: new Date().toISOString(),
    });
  } else {
    record = repo.insert('secrets', tenantId, {
      name, provider, ciphertext, hint, status: 'active', updated_at: new Date().toISOString(),
    });
  }
  repo.audit({ tenantId, entity: 'secret', entityId: record.id, action: existing ? 'update' : 'create', userId, metadata: { name, provider } });
  return { id: record.id, name: record.name, provider: record.provider, hint: record.hint };
}

function getSecretValue(tenantId, name) {
  const rec = repo.row('SELECT ciphertext, status FROM secrets WHERE tenant_id = ? AND name = ?', tenantId, name);
  if (!rec || rec.status !== 'active') return null;
  try { return decryptSecret(rec.ciphertext); } catch { return null; }
}

function deleteSecret({ tenantId, userId, id }) {
  const rec = repo.get('secrets', tenantId, id);
  if (!rec) return false;
  repo.remove('secrets', tenantId, id);
  repo.audit({ tenantId, entity: 'secret', entityId: id, action: 'delete', userId, metadata: { name: rec.name } });
  return true;
}

function listSecrets(tenantId) {
  return repo.list('secrets', tenantId, { order: 'created_at DESC' }).map((s) => ({
    id: s.id, name: s.name, provider: s.provider, hint: s.hint, status: s.status, created_at: s.created_at, updated_at: s.updated_at,
  }));
}

/** Build a vault lookup bound to a tenant for the provider layer. */
function lookupFor(tenantId) {
  const cache = new Map();
  return (name) => {
    if (cache.has(name)) return cache.get(name);
    const val = getSecretValue(tenantId, name);
    cache.set(name, val);
    return val;
  };
}

/* ------------------------------ API keys ---------------------------------- */
function createApiKey({ tenantId, userId, name, scopes = ['*'] }) {
  const { raw, prefix, hash } = generateApiKey();
  const rec = repo.insert('api_keys', tenantId, {
    user_id: userId, name, prefix, key_hash: hash, scopes, status: 'active',
  });
  repo.audit({ tenantId, entity: 'api_key', entityId: rec.id, action: 'create', userId, metadata: { name } });
  return { id: rec.id, name, prefix, key: raw, scopes }; // raw returned once only
}

function listApiKeys(tenantId) {
  return repo.list('api_keys', tenantId, { order: 'created_at DESC' }).map((k) => ({
    id: k.id, name: k.name, prefix: k.prefix, scopes: safeJson(k.scopes, []), status: k.status,
    last_used_at: k.last_used_at, created_at: k.created_at,
  }));
}

function revokeApiKey({ tenantId, userId, id }) {
  const rec = repo.get('api_keys', tenantId, id);
  if (!rec) return false;
  repo.update('api_keys', tenantId, id, { status: 'revoked' });
  repo.audit({ tenantId, entity: 'api_key', entityId: id, action: 'revoke', userId });
  return true;
}

function safeJson(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

module.exports = { setSecret, getSecretValue, deleteSecret, listSecrets, lookupFor, createApiKey, listApiKeys, revokeApiKey };
