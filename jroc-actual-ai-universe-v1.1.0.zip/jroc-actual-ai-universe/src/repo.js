'use strict';
/**
 * repo.js - tenant-isolated repository layer + audit trail.
 * Every tenant-owned read/write goes through here so that
 * `tenant_id = current_tenant` is enforced in one place (spec section 31).
 */
const { connect, nowIso } = require('./db');
const { uuid } = require('./crypto');

function db() { return connect(); }

/** Set the session tenant used by the RLS-equivalent triggers. */
function setSessionTenant(tenantId) {
  db().prepare('UPDATE _app_session SET v = ? WHERE k = ?').run(String(tenantId || ''), 'tenant_id');
}
function sessionTenant() {
  return db().prepare('SELECT v FROM _app_session WHERE k = ?').get('tenant_id')?.v || '';
}

/** Run a function inside a tenant-scoped transaction. */
function withTenant(tenantId, fn) {
  const d = db();
  d.exec('BEGIN IMMEDIATE');
  try {
    setSessionTenant(tenantId);
    const out = fn(d);
    d.exec('COMMIT');
    return out;
  } catch (err) {
    try { d.exec('ROLLBACK'); } catch { /* ignore */ }
    throw err;
  } finally {
    setSessionTenant('');
  }
}

function rows(sql, ...params) { return db().prepare(sql).all(...params); }
function row(sql, ...params) { return db().prepare(sql).get(...params) || null; }
function run(sql, ...params) { return db().prepare(sql).run(...params); }

/* --------------------------- generic CRUD --------------------------------- */
const TENANT_TABLES = new Set([
  'users', 'projects', 'blueprints', 'agents', 'workers', 'teams', 'departments', 'swarms',
  'knowledge_nodes', 'memories', 'plugins', 'connectors', 'workflows', 'automations',
  'assets', 'deployments', 'deployment_events', 'audit_logs', 'notifications',
  'api_keys', 'secrets', 'jobs', 'builds', 'brain_profiles', 'router_rules', 'prompts', 'skills',
]);

function list(table, tenantId, { where = '', params = [], order = 'created_at DESC', limit = 500, offset = 0 } = {}) {
  if (!TENANT_TABLES.has(table)) throw new Error(`Refusing tenant query on ${table}`);
  const clause = where ? `AND ${where}` : '';
  return rows(
    `SELECT * FROM ${table} WHERE tenant_id = ? ${clause} ORDER BY ${order} LIMIT ? OFFSET ?`,
    tenantId, ...params, limit, offset,
  );
}

function get(table, tenantId, id) {
  if (!TENANT_TABLES.has(table)) throw new Error(`Refusing tenant query on ${table}`);
  return row(`SELECT * FROM ${table} WHERE tenant_id = ? AND id = ?`, tenantId, id);
}

function insert(table, tenantId, data) {
  if (!TENANT_TABLES.has(table)) throw new Error(`Refusing tenant write on ${table}`);
  const record = { id: uuid(), tenant_id: tenantId, created_at: nowIso(), ...data };
  const keys = Object.keys(record);
  const sql = `INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`;
  db().prepare(sql).run(...keys.map((k) => normalize(record[k])));
  return record;
}

function update(table, tenantId, id, patch) {
  if (!TENANT_TABLES.has(table)) throw new Error(`Refusing tenant write on ${table}`);
  const keys = Object.keys(patch);
  if (!keys.length) return get(table, tenantId, id);
  const setSql = keys.map((k) => `${k} = ?`).join(', ');
  db().prepare(`UPDATE ${table} SET ${setSql} WHERE tenant_id = ? AND id = ?`)
    .run(...keys.map((k) => normalize(patch[k])), tenantId, id);
  return get(table, tenantId, id);
}

function remove(table, tenantId, id) {
  if (!TENANT_TABLES.has(table)) throw new Error(`Refusing tenant write on ${table}`);
  return db().prepare(`DELETE FROM ${table} WHERE tenant_id = ? AND id = ?`).run(tenantId, id);
}

function normalize(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'object') return JSON.stringify(v);
  return v;
}

/* ------------------------------- audit ------------------------------------ */
function audit({ tenantId, entity, entityId = null, action, userId = null, metadata = {}, ip = null }) {
  try {
    db().prepare(
      `INSERT INTO audit_logs (id, tenant_id, entity, entity_id, action, user_id, metadata, ip, created_at)
       VALUES (?,?,?,?,?,?,?,?,?)`,
    ).run(uuid(), tenantId, entity, entityId, action, userId, JSON.stringify(metadata), ip, nowIso());
  } catch { /* auditing must never break the request path */ }
}

function notify({ tenantId, userId = null, level = 'info', title, body = '', metadata = {} }) {
  return insert('notifications', tenantId, { user_id: userId, level, title, body, metadata, read: 0 });
}

module.exports = {
  db, withTenant, setSessionTenant, sessionTenant,
  rows, row, run,
  list, get, insert, update, remove,
  audit, notify, normalize,
};
