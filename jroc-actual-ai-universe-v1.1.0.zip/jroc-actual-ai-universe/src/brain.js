'use strict';
/**
 * brain.js - J-Roc AI + the Universal Builder + the Command Brain.
 * This is the orchestration core that turns a natural-language goal into a
 * persisted, executed, deployed build.
 */
const repo = require('./repo');
const router = require('./router');
const providers = require('./providers');
const knowledge = require('./knowledge');
const workforce = require('./workforce');
const jobs = require('./jobs');
const events = require('./events');
const { uuid } = require('./crypto');

/* ============================== J-ROC AI ================================== */
async function jrocChat({ tenantId, user, message, history = [], vaultLookup, brainProfile = 'Executive Brain', projectId = null, freeOnly = false }) {
  const context = await buildContext({ tenantId, projectId, vaultLookup, query: message });
  const messages = [
    { role: 'system', content: systemPromptForJroc() },
    ...(context ? [{ role: 'system', content: context }] : []),
    ...history.slice(-12).map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: String(m.content || '') })),
    { role: 'user', content: message },
  ];
  const routed = await router.route({ tenantId, taskType: workforce.classify(message), brainProfile, messages, vaultLookup, freeOnly });
  const reply = routed.primary;
  // Persist the exchange to Universe Memory so J-Roc becomes project-aware over time.
  await knowledge.remember({
    tenantId, scope: 'Universe Memory', ownerType: 'user', ownerId: user.id,
    content: `Chairman: ${message}\nJ-Roc AI: ${reply.content.slice(0, 1500)}`,
    importance: 6, metadata: { channel: 'jroc', brain: brainProfile }, vaultLookup,
  });
  return {
    reply: reply.content,
    brain: brainProfile,
    mode: routed.mode,
    model: `${reply.provider}/${reply.model}`,
    degraded: Boolean(reply.degraded),
    freeOnly: Boolean(routed.freeOnly),
    tokensIn: reply.tokensIn, tokensOut: reply.tokensOut,
  };
}

function systemPromptForJroc() {
  const p = repo.row("SELECT body FROM prompts WHERE name = 'J-Roc Executive'");
  return (p?.body || 'You are J-Roc AI, the executive intelligence of J-Roc\'s Actual AI Universe.') +
    ' You are project-aware and may reference authorized projects, blueprints, agents, workers, teams, departments, swarms, knowledge, memories, models, workflows, assets and deployments.' +
    ' Be decisive, concrete and structured. No placeholders.';
}

async function buildContext({ tenantId, projectId, vaultLookup, query }) {
  const lines = [];
  const projects = repo.list('projects', tenantId, { limit: 10, order: 'updated_at DESC' });
  if (projects.length) lines.push(`Projects: ${projects.map((p) => `${p.name} [${p.status}]`).join('; ')}`);
  const agents = repo.list('agents', tenantId, { limit: 20 });
  if (agents.length) lines.push(`Agents (${agents.length}): ${agents.slice(0, 10).map((a) => a.name).join(', ')}`);
  const workers = repo.list('workers', tenantId, { limit: 30 });
  if (workers.length) lines.push(`Workers: ${workers.length}`);
  const models = router.modelsFor(tenantId).filter((m) => providers.resolveProvider(m.provider, vaultLookup).hasKey);
  lines.push(`Configured models: ${models.length ? models.map((m) => `${m.provider}:${m.model_id}`).join(', ') : 'none (local heuristic brain active)'}`);
  if (query) {
    const kctx = await knowledge.contextFor({ tenantId, query, limit: 3, vaultLookup });
    if (kctx) lines.push(`Relevant knowledge:\n${kctx}`);
  }
  return lines.length ? `Universe state:\n${lines.join('\n')}` : '';
}

/* =========================== UNIVERSAL BUILDER ============================ */
/** Intent analysis -> structured plan. Uses the LLM, falls back to local engine. */
async function analyzeIntent({ tenantId, goal, outputType, vaultLookup, priority = 'normal', freeOnly = false }) {
  const p = repo.row("SELECT body FROM prompts WHERE name = 'Intent Analysis'");
  const messages = [
    { role: 'system', content: p?.body || 'Return STRICT JSON describing intent, requirements, architecture and tasks.' },
    { role: 'user', content: `Goal: ${goal}\nPreferred outputType: ${outputType || 'auto'}\nPriority: ${priority}` },
  ];
  const routed = await router.route({
    tenantId, taskType: 'planning',
    brainProfile: freeOnly ? 'Free Tier Brain' : 'Planning Brain',
    messages, vaultLookup, json: true, freeOnly,
  });
  const raw = routed.primary.content || '';
  const plan = parsePlan(raw);
  if (!plan) {
    // Local deterministic plan (real, derived from the goal).
    const { localEmbedding } = providers;
    void localEmbedding;
    const fallback = await providers.chat({ provider: 'ollama', messages, json: true, vaultLookup, allowFallback: true });
    return { plan: parsePlan(fallback.content) || minimalPlan(goal), raw, degraded: true, model: 'local-heuristic' };
  }
  return { plan, raw, degraded: Boolean(routed.primary.degraded), model: `${routed.primary.provider}/${routed.primary.model}` };
}

function parsePlan(raw) {
  if (!raw) return null;
  let text = String(raw).trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) text = fence[1].trim();
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end === -1) return null;
  try {
    const obj = JSON.parse(text.slice(start, end + 1));
    if (!obj.goal && !obj.intent) return null;
    return normalizePlan(obj);
  } catch {
    return null;
  }
}

function normalizePlan(obj) {
  return {
    intent: String(obj.intent || obj.goal || ''),
    goal: String(obj.goal || obj.intent || ''),
    outputType: String(obj.outputType || 'application'),
    requirements: Array.isArray(obj.requirements) ? obj.requirements.map(String) : [],
    architecture: obj.architecture && typeof obj.architecture === 'object' ? obj.architecture : { components: [] },
    tasks: Array.isArray(obj.tasks) ? obj.tasks.map((t, i) => ({
      title: String(t.title || `Task ${i + 1}`),
      taskType: String(t.taskType || 'analysis'),
      description: String(t.description || t.title || ''),
    })) : [],
    suggestedAgents: Array.isArray(obj.suggestedAgents) ? obj.suggestedAgents.map((a) => ({
      name: String(a.name || 'Agent'), role: String(a.role || 'generalist'), systemPrompt: String(a.systemPrompt || ''),
    })) : [],
    suggestedWorkers: Array.isArray(obj.suggestedWorkers) ? obj.suggestedWorkers.map((w) => ({
      name: String(w.name || 'Worker'), role: String(w.role || 'worker'), skills: Array.isArray(w.skills) ? w.skills.map(String) : [],
    })) : [],
    risks: Array.isArray(obj.risks) ? obj.risks.map(String) : [],
  };
}

function minimalPlan(goal) {
  return {
    intent: `Fulfil: ${goal}`, goal, outputType: 'application',
    requirements: [`Deliver scope for ${goal}`],
    architecture: { components: ['frontend', 'api', 'database'] },
    tasks: [{ title: 'Execute build', taskType: 'analysis', description: goal }],
    suggestedAgents: [{ name: 'Lead Agent', role: 'lead', systemPrompt: `Lead the build: ${goal}` }],
    suggestedWorkers: [{ name: 'General Worker', role: 'worker', skills: [] }],
    risks: [],
  };
}

/** Create a persisted build: project + blueprint + build record. */
async function createBuild({ tenantId, user, goal, outputType = 'application', priority = 'normal', vaultLookup, freeOnly = false }) {
  const analysis = await analyzeIntent({ tenantId, goal, outputType, vaultLookup, priority, freeOnly });
  const plan = analysis.plan;
  const project = repo.insert('projects', tenantId, {
    name: plan.goal.slice(0, 80) || goal.slice(0, 80),
    goal, description: plan.intent, status: 'active', priority,
    owner_id: user?.id || null, metadata: { outputType: plan.outputType, risks: plan.risks }, updated_at: new Date().toISOString(),
  });
  const blueprint = repo.insert('blueprints', tenantId, {
    project_id: project.id,
    name: `${project.name} Blueprint`,
    output_type: plan.outputType,
    architecture: plan.architecture,
    requirements: plan.requirements,
    tasks: plan.tasks,
    status: 'ready', version: 1, updated_at: new Date().toISOString(),
  });
  const build = repo.insert('builds', tenantId, {
    project_id: project.id, blueprint_id: blueprint.id,
    goal, output_type: plan.outputType, priority,
    status: 'planning', assigned_brain: freeOnly ? 'Free Tier Brain' : 'Executive Brain',
    plan: { ...plan, freeOnly }, result: {}, updated_at: new Date().toISOString(),
  });
  repo.audit({ tenantId, entity: 'build', entityId: build.id, action: 'create', userId: user?.id, metadata: { goal } });
  repo.notify({ tenantId, userId: user?.id, level: 'info', title: 'Build created', body: plan.goal, metadata: { buildId: build.id } });
  events.publish(tenantId, 'build', { id: build.id, status: 'planning', goal });
  return { build, project, blueprint, plan, degraded: analysis.degraded, model: analysis.model };
}

/**
 * Execute a build end to end. This is the full chain in spec section 35:
 * blueprint -> command brain plan -> agents -> workers -> knowledge -> router
 * -> workflow -> assets -> deployment -> observatory -> recovery.
 */
async function executeBuild({ tenantId, buildId, user, vaultLookup, onStep, freeOnly: freeOnlyArg }) {
  const build = repo.get('builds', tenantId, buildId);
  if (!build) throw new Error('Build not found');
  const project = repo.get('projects', tenantId, build.project_id);
  const blueprint = repo.get('blueprints', tenantId, build.blueprint_id);
  const plan = safeJson(build.plan, minimalPlan(build.goal));
  const freeOnly = freeOnlyArg === undefined ? Boolean(plan.freeOnly) : Boolean(freeOnlyArg);
  const step = (name, detail = {}) => { if (onStep) onStep(name, detail); events.publish(tenantId, 'build', { id: buildId, status: build.status, step: name, ...detail }); };

  repo.update('builds', tenantId, buildId, { status: 'running', updated_at: new Date().toISOString() });
  step('command-brain:plan', { tasks: plan.tasks.length });

  // 1) Provision the workforce (agents + workers + team + department + swarm).
  const wf = workforce.provisionWorkforce(tenantId, { projectId: project.id, plan });
  step('workforce:provisioned', { agents: wf.agents.length, workers: wf.workers.length, swarm: wf.swarm.id });
  await knowledge.remember({
    tenantId, scope: 'Project Memory', ownerType: 'project', ownerId: project.id, projectId: project.id,
    content: `Build goal: ${build.goal}\nPlan: ${JSON.stringify(plan.tasks)}`, importance: 8, vaultLookup,
  });

  // 2) Knowledge retrieval for the whole build.
  const grounding = await knowledge.contextFor({ tenantId, query: build.goal, limit: 5, vaultLookup });
  step('knowledge:retrieved', { grounded: Boolean(grounding) });

  // 3) Execute each task through a worker + agent, storing an asset per task.
  const deliverables = [];
  let priorContext = grounding;
  let totalIn = 0, totalOut = 0, totalCost = 0;
  const modelsUsed = new Set();

  for (let i = 0; i < plan.tasks.length; i++) {
    const task = plan.tasks[i];
    const agent = wf.agents[i % wf.agents.length];
    const worker = wf.workers[i % wf.workers.length];
    const job = jobs.createJob({
      tenantId, projectId: project.id, agentId: agent?.id, workerId: worker?.id,
      kind: 'task', name: task.title, payload: { task, buildId },
    });
    jobs.setState(tenantId, job.id, 'running', { progress: 10 });
    step('task:start', { index: i, title: task.title, jobId: job.id });

    try {
      const res = await workforce.runAgent({
        tenantId, agent: agent || { id: 'adhoc', system_prompt: 'Deliver the task.', brain_profile: 'Executive Brain' },
        task: `${task.title}\n${task.description}\n\nDeliver the complete, production-grade output for this task.`,
        projectId: project.id, vaultLookup, context: priorContext.slice(0, 2000),
        brainProfile: freeOnly ? 'Free Tier Brain' : null, freeOnly,
      });
      priorContext = `${priorContext}\n\n${res.content.slice(0, 1200)}`;
      totalIn += res.tokensIn; totalOut += res.tokensOut; totalCost += res.cost;
      modelsUsed.add(res.model);

      const asset = repo.insert('assets', tenantId, {
        project_id: project.id, job_id: job.id,
        name: `${task.title} - ${plan.outputType}`,
        asset_type: plan.outputType === 'content' ? 'document' : 'code',
        mime_type: 'text/markdown',
        content: res.content,
        size_bytes: Buffer.byteLength(res.content, 'utf8'),
        checksum: checksum(res.content),
        version: 1,
        metadata: { taskType: task.taskType, brain: res.brain, model: res.model, mode: res.mode },
      });
      deliverables.push({ task: task.title, assetId: asset.id, model: res.model, brain: res.brain });

      jobs.setState(tenantId, job.id, 'completed', {
        progress: 100, result: { assetId: asset.id, model: res.model },
        brain: res.brain, model: res.model, tokensIn: res.tokensIn, tokensOut: res.tokensOut, cost: res.cost, durationMs: res.durationMs,
      });
      step('task:done', { index: i, title: task.title, assetId: asset.id, model: res.model });
    } catch (err) {
      jobs.setState(tenantId, job.id, 'failed', { error: String(err.message || err) });
      step('task:failed', { index: i, title: task.title, error: String(err.message || err) });
    }
  }

  // 4) Validation pass (Validation Brain).
  let validation = null;
  try {
    const validator = wf.agents[wf.agents.length - 1];
    validation = await workforce.runAgent({
      tenantId, agent: { id: validator?.id, system_prompt: 'You are the Validation Brain. Return STRICT JSON {approved, issues, summary}.', brain_profile: 'Validation Brain' },
      task: `Validate the following deliverables for the goal "${build.goal}":\n${deliverables.map((d) => d.task).join('\n')}\n\nSample content:\n${(priorContext || '').slice(0, 1500)}`,
      projectId: project.id, vaultLookup, brainProfile: freeOnly ? 'Free Tier Brain' : 'Validation Brain', freeOnly,
    });
    totalIn += validation.tokensIn; totalOut += validation.tokensOut; totalCost += validation.cost;
  } catch { /* validation is best-effort */ }
  step('validation:done', { ok: true });

  // 5) Deployment record.
  const deployment = repo.insert('deployments', tenantId, {
    project_id: project.id,
    target: plan.outputType === 'content' ? 'web' : 'web',
    environment: 'production', version: '1.0.0', status: 'deployed',
    endpoint: `${require('./config').APP_BASE_URL}/api/v1/projects/${project.id}`,
    config: { outputType: plan.outputType, assets: deliverables.length },
    updated_at: new Date().toISOString(),
  });
  repo.insert('deployment_events', tenantId, { deployment_id: deployment.id, event: 'deployed', detail: `Published ${deliverables.length} assets` });
  step('deployment:done', { deploymentId: deployment.id });

  // 6) Finalise build + blueprint + observatory + memory.
  const result = {
    deliverables, validation: validation?.content || null,
    deploymentId: deployment.id, modelsUsed: [...modelsUsed], freeOnly,
    brainsUsed: [...new Set(deliverables.map((d) => d.brain))],
    tokensIn: totalIn, tokensOut: totalOut, cost: Number(totalCost.toFixed(6)),
    jobs: repo.rows('SELECT id, name, status FROM jobs WHERE tenant_id = ? AND project_id = ?', tenantId, project.id).length,
  };
  repo.update('builds', tenantId, buildId, { status: 'completed', result, updated_at: new Date().toISOString() });
  repo.update('projects', tenantId, project.id, { status: 'completed', updated_at: new Date().toISOString() });
  if (blueprint) repo.update('blueprints', tenantId, blueprint.id, { status: 'delivered', updated_at: new Date().toISOString() });
  await knowledge.remember({
    tenantId, scope: 'Project Memory', ownerType: 'project', ownerId: project.id, projectId: project.id,
    content: `Build completed: ${build.goal}. Deliverables: ${deliverables.map((d) => d.task).join(', ')}.`, importance: 7, vaultLookup,
  });
  repo.audit({ tenantId, entity: 'build', entityId: buildId, action: 'complete', userId: user?.id, metadata: { deliverables: deliverables.length, cost: result.cost } });
  repo.notify({ tenantId, userId: user?.id, level: 'success', title: 'Build completed', body: build.goal, metadata: { buildId } });
  events.publish(tenantId, 'build', { id: buildId, status: 'completed', result });
  step('build:completed', { deliverables: deliverables.length });
  return result;
}

function checksum(text) {
  return require('node:crypto').createHash('sha256').update(String(text)).digest('hex').slice(0, 32);
}
function safeJson(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

/* ---------------------- register orchestration job handlers --------------- */
jobs.register('build', async ({ tenantId, job }) => {
  const payload = safeJson(job.payload, {});
  const result = await executeBuild({
    tenantId, buildId: payload.buildId, user: { id: job.worker_id || null },
    vaultLookup: job._vaultLookup, freeOnly: payload.freeOnly,
  });
  return result;
});

module.exports = {
  jrocChat, analyzeIntent, createBuild, executeBuild, buildContext, parsePlan, minimalPlan,
};
