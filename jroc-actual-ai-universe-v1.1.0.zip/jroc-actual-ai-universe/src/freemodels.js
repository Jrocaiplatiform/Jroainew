'use strict';
/**
 * freemodels.js - the Free Tier registry.
 *
 * Providers with a genuinely permanent, no-credit-card free API tier. All of
 * them are OpenAI-compatible chat-completions endpoints, so the Model Router
 * reaches them through the same transport as DeepSeek/Mistral/Qwen/Grok.
 *
 * Keys are resolved from the tenant Secrets Vault first, then environment.
 * Nothing is hard-coded. Free model IDs rotate over time, so every provider
 * exposes `models` (curated defaults) AND live discovery where the provider
 * offers a public /models endpoint.
 *
 * Verified against provider docs (2026). Rate limits are the documented free
 * ceilings and are shown in the UI, not enforced as hard guarantees.
 */

const FREE_PROVIDERS = [
  {
    id: 'openrouter',
    label: 'OpenRouter',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://openrouter.ai/api/v1',
    envKeys: ['OPENROUTER_API_KEY'],
    defaultModel: 'openrouter/free',
    docs: 'https://openrouter.ai/models?max_price=0',
    signup: 'https://openrouter.ai/settings/keys',
    rateLimit: { rpm: 20, rpd: 50, note: 'Rises to 1,000/day after a one-time $10 credit purchase; RPM stays 20.' },
    discovery: { path: '/models', public: true, filter: (m) => String(m.id || '').endsWith(':free') || m.id === 'openrouter/free' },
    models: [
      { id: 'openrouter/free', name: 'OpenRouter Free Router', capabilities: ['reasoning', 'coding', 'research', 'writing', 'analysis', 'creativity', 'planning'], context: 200000, note: 'Auto-routes to the best available free model.' },
      { id: 'deepseek/deepseek-r1:free', name: 'DeepSeek R1 (free)', capabilities: ['reasoning', 'analysis'], context: 163840 },
      { id: 'deepseek/deepseek-chat-v3-0324:free', name: 'DeepSeek V3 (free)', capabilities: ['coding', 'writing', 'analysis'], context: 163840 },
      { id: 'meta-llama/llama-3.3-70b-instruct:free', name: 'Llama 3.3 70B (free)', capabilities: ['reasoning', 'writing', 'research'], context: 131072 },
      { id: 'qwen/qwen-2.5-72b-instruct:free', name: 'Qwen 2.5 72B (free)', capabilities: ['reasoning', 'creativity', 'writing'], context: 32768 },
      { id: 'google/gemma-2-9b-it:free', name: 'Gemma 2 9B (free)', capabilities: ['writing', 'analysis'], context: 8192 },
      { id: 'mistralai/mistral-nemo:free', name: 'Mistral Nemo (free)', capabilities: ['writing', 'analysis'], context: 131072 },
    ],
  },
  {
    id: 'groq',
    label: 'Groq',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://api.groq.com/openai/v1',
    envKeys: ['GROQ_API_KEY'],
    defaultModel: 'llama-3.3-70b-versatile',
    docs: 'https://console.groq.com/docs/rate-limits',
    signup: 'https://console.groq.com/keys',
    rateLimit: { rpm: 30, rpd: 1000, note: '~500-700 tokens/sec. No credit card required.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B Versatile', capabilities: ['reasoning', 'coding', 'writing', 'analysis'], context: 131072 },
      { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant', capabilities: ['writing', 'analysis'], context: 131072 },
      { id: 'meta-llama/llama-4-scout-17b-16e-instruct', name: 'Llama 4 Scout', capabilities: ['reasoning', 'research', 'writing'], context: 131072 },
      { id: 'openai/gpt-oss-120b', name: 'GPT-OSS 120B', capabilities: ['reasoning', 'coding', 'analysis'], context: 131072 },
      { id: 'openai/gpt-oss-20b', name: 'GPT-OSS 20B', capabilities: ['coding', 'writing'], context: 131072 },
    ],
  },
  {
    id: 'gemini',
    label: 'Google AI Studio (Gemini)',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    envKeys: ['GEMINI_API_KEY', 'GOOGLE_AI_API_KEY', 'GOOGLE_API_KEY'],
    defaultModel: 'gemini-2.5-flash',
    docs: 'https://ai.google.dev/gemini-api/docs/rate-limits',
    signup: 'https://aistudio.google.com/apikey',
    rateLimit: { rpm: 15, rpd: 1500, note: 'Up to 1M-token context on Flash. Free tier may train on your data outside EU/UK/EEA.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', capabilities: ['reasoning', 'research', 'writing', 'analysis', 'coding'], context: 1048576 },
      { id: 'gemini-2.5-flash-lite', name: 'Gemini 2.5 Flash Lite', capabilities: ['writing', 'analysis'], context: 1048576 },
      { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', capabilities: ['reasoning', 'creativity', 'writing'], context: 1048576 },
    ],
  },
  {
    id: 'cerebras',
    label: 'Cerebras',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://api.cerebras.ai/v1',
    envKeys: ['CEREBRAS_API_KEY'],
    defaultModel: 'llama-3.3-70b',
    docs: 'https://inference-docs.cerebras.ai/support/rate-limits',
    signup: 'https://cloud.cerebras.ai/',
    rateLimit: { rpm: 30, tpd: 1000000, note: 'Up to ~2,100 tokens/sec. No credit card required.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'llama-3.3-70b', name: 'Llama 3.3 70B', capabilities: ['reasoning', 'coding', 'analysis'], context: 131072 },
      { id: 'llama3.1-8b', name: 'Llama 3.1 8B', capabilities: ['writing', 'analysis'], context: 32768 },
      { id: 'qwen-3-32b', name: 'Qwen 3 32B', capabilities: ['reasoning', 'coding'], context: 131072 },
    ],
  },
  {
    id: 'github',
    label: 'GitHub Models',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://models.github.ai/inference',
    envKeys: ['GITHUB_MODELS_TOKEN', 'GITHUB_TOKEN'],
    defaultModel: 'openai/gpt-4o-mini',
    docs: 'https://docs.github.com/en/github-models',
    signup: 'https://github.com/settings/tokens',
    rateLimit: { rpm: 15, rpd: 150, note: 'Free with any GitHub account. Use a fine-grained PAT with models:read.' },
    discovery: { path: '/catalog/models', public: false },
    models: [
      { id: 'openai/gpt-4o-mini', name: 'GPT-4o mini', capabilities: ['reasoning', 'coding', 'writing', 'analysis'], context: 128000 },
      { id: 'meta/Llama-3.3-70B-Instruct', name: 'Llama 3.3 70B', capabilities: ['reasoning', 'writing'], context: 128000 },
      { id: 'mistral-ai/Mistral-Nemo', name: 'Mistral Nemo', capabilities: ['writing', 'analysis'], context: 128000 },
      { id: 'microsoft/Phi-4', name: 'Phi-4', capabilities: ['reasoning', 'analysis'], context: 16000 },
    ],
  },
  {
    id: 'cloudflare',
    label: 'Cloudflare Workers AI',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/v1',
    envKeys: ['CLOUDFLARE_API_TOKEN'],
    accountEnvKey: 'CLOUDFLARE_ACCOUNT_ID',
    defaultModel: '@cf/meta/llama-3.1-8b-instruct',
    docs: 'https://developers.cloudflare.com/workers-ai/platform/pricing/',
    signup: 'https://dash.cloudflare.com/profile/api-tokens',
    rateLimit: { note: 'Free daily allocation of 10,000 Neurons. Requires your Cloudflare Account ID.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: '@cf/meta/llama-3.1-8b-instruct', name: 'Llama 3.1 8B', capabilities: ['writing', 'analysis'], context: 8192 },
      { id: '@cf/meta/llama-3.3-70b-instruct-fp8-fast', name: 'Llama 3.3 70B Fast', capabilities: ['reasoning', 'writing'], context: 24000 },
      { id: '@cf/qwen/qwen1.5-14b-chat-awq', name: 'Qwen 1.5 14B', capabilities: ['writing', 'analysis'], context: 8192 },
    ],
  },
  {
    id: 'mistralfree',
    label: 'Mistral (free tier)',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://api.mistral.ai/v1',
    envKeys: ['MISTRAL_API_KEY'],
    defaultModel: 'mistral-small-latest',
    docs: 'https://docs.mistral.ai/deployment/laplateforme/tier/',
    signup: 'https://console.mistral.ai/api-keys/',
    rateLimit: { rpm: 60, note: 'The "Experiment" free tier covers the small models; large models are paid.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'mistral-small-latest', name: 'Mistral Small', capabilities: ['writing', 'analysis', 'creativity'], context: 131072 },
      { id: 'open-mistral-nemo', name: 'Mistral Nemo', capabilities: ['writing', 'analysis'], context: 131072 },
      { id: 'mistral-embed', name: 'Mistral Embed', capabilities: ['embedding'], context: 8192, embedding: true },
    ],
  },
  {
    id: 'huggingface',
    label: 'Hugging Face',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://router.huggingface.co/v1',
    envKeys: ['HF_TOKEN', 'HUGGINGFACE_API_KEY'],
    defaultModel: 'meta-llama/Llama-3.3-70B-Instruct',
    docs: 'https://huggingface.co/docs/inference-providers/pricing',
    signup: 'https://huggingface.co/settings/tokens',
    rateLimit: { note: 'Monthly free inference credits on the free account; resets monthly.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'meta-llama/Llama-3.3-70B-Instruct', name: 'Llama 3.3 70B Instruct', capabilities: ['reasoning', 'writing'], context: 131072 },
      { id: 'Qwen/Qwen2.5-72B-Instruct', name: 'Qwen 2.5 72B', capabilities: ['reasoning', 'creativity'], context: 32768 },
      { id: 'mistralai/Mistral-7B-Instruct-v0.3', name: 'Mistral 7B', capabilities: ['writing', 'analysis'], context: 32768 },
    ],
  },
  {
    id: 'sambanova',
    label: 'SambaNova',
    kind: 'cloud',
    freeForever: true,
    baseUrl: 'https://api.sambanova.ai/v1',
    envKeys: ['SAMBANOVA_API_KEY'],
    defaultModel: 'Meta-Llama-3.3-70B-Instruct',
    docs: 'https://docs.sambanova.ai/cloud/docs/get-started/rate-limits',
    signup: 'https://cloud.sambanova.ai/apis',
    rateLimit: { note: 'Free tier with daily request caps. Very fast Llama inference.' },
    discovery: { path: '/models', public: false },
    models: [
      { id: 'Meta-Llama-3.3-70B-Instruct', name: 'Llama 3.3 70B', capabilities: ['reasoning', 'writing', 'coding'], context: 131072 },
      { id: 'Meta-Llama-3.1-8B-Instruct', name: 'Llama 3.1 8B', capabilities: ['writing', 'analysis'], context: 131072 },
    ],
  },
  {
    id: 'ollama',
    label: 'Ollama (local, unlimited)',
    kind: 'local',
    freeForever: true,
    baseUrl: 'http://localhost:11434/v1',
    envKeys: ['OLLAMA_BASE_URL'],
    defaultModel: 'llama3.1',
    docs: 'https://ollama.com/library',
    signup: 'https://ollama.com/download',
    rateLimit: { note: 'No limits — runs on your own hardware. Always free.' },
    discovery: { path: '/models', public: true },
    models: [
      { id: 'llama3.1', name: 'Llama 3.1', capabilities: ['reasoning', 'writing', 'coding', 'analysis'], context: 131072 },
      { id: 'qwen2.5', name: 'Qwen 2.5', capabilities: ['reasoning', 'creativity'], context: 32768 },
      { id: 'mistral', name: 'Mistral', capabilities: ['writing', 'analysis'], context: 32768 },
      { id: 'phi3', name: 'Phi 3', capabilities: ['reasoning'], context: 131072 },
    ],
  },
];

const BY_ID = Object.fromEntries(FREE_PROVIDERS.map((p) => [p.id, p]));

/** Resolve a free provider's runtime config (vault key > env, account id, base URL). */
function resolveFreeProvider(id, vaultLookup) {
  const def = BY_ID[id];
  if (!def) return null;
  let apiKey = '';
  for (const envKey of def.envKeys || []) {
    const fromVault = vaultLookup ? (vaultLookup(`provider.${id}`) || vaultLookup(envKey)) : null;
    if (fromVault) { apiKey = fromVault; break; }
    if (process.env[envKey]) { apiKey = process.env[envKey]; break; }
  }
  // Ollama needs no key.
  if (!apiKey && def.kind === 'local') apiKey = 'ollama';
  let baseUrl = def.baseUrl;
  if (def.accountEnvKey) {
    const accountId = process.env[def.accountEnvKey] || (vaultLookup ? vaultLookup(def.accountEnvKey) : '') || '';
    baseUrl = baseUrl.replace('{account_id}', accountId || 'ACCOUNT_ID');
  }
  return {
    id: def.id, label: def.label, kind: def.kind, baseUrl,
    apiKey, hasKey: Boolean(apiKey), defaultModel: def.defaultModel,
    freeForever: def.freeForever, rateLimit: def.rateLimit, docs: def.docs, signup: def.signup,
    envKeys: def.envKeys, models: def.models, discovery: def.discovery,
    accountEnvKey: def.accountEnvKey,
  };
}

/** All free providers with live key status. */
function listFreeProviders(vaultLookup) {
  return FREE_PROVIDERS.map((p) => {
    const r = resolveFreeProvider(p.id, vaultLookup);
    return {
      id: r.id, label: r.label, kind: r.kind, baseUrl: r.baseUrl, configured: r.hasKey,
      defaultModel: r.defaultModel, freeForever: r.freeForever, rateLimit: r.rateLimit,
      docs: r.docs, signup: r.signup, envKeys: r.envKeys, accountEnvKey: r.accountEnvKey,
      models: r.models,
      configuredVia: r.hasKey ? 'key' : 'none',
    };
  });
}

/** The secret name a user should store for a provider. */
function secretName(id) { return `provider.${id}`; }

module.exports = { FREE_PROVIDERS, BY_ID, resolveFreeProvider, listFreeProviders, secretName };
