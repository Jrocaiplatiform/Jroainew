'use strict';
/**
 * router.js - the Multi-Model Router (spec section 9).
 * Modes: single | dual | triple | consensus | rotating.
 * Routing inputs: task type, model capability, brain profile, priority,
 * availability, cost, speed, quality and DB-stored routing rules.
 */
const repo = require('./repo');
const providers = require('./providers');

let rotationCursor = 0;

function modelsFor(tenantId, { freeOnly = false } = {}) {
  const system = repo.rows('SELECT * FROM models WHERE tenant_id IS NULL AND enabled = 1');
  const tenant = repo.rows('SELECT * FROM models WHERE tenant_id = ? AND enabled = 1', tenantId);
  const all = [...system, ...tenant];
  return freeOnly ? all.filter((m) => m.free_tier === 1) : all;
}

/** Free-forever models only, ranked. */
function freeModels(tenantId) {
  return modelsFor(tenantId, { freeOnly: true });
}

function providerConfigured(providerId, vaultLookup) {
  try { return providers.resolveProvider(providerId, vaultLookup).hasKey; } catch { return false; }
}

/** Choose the best model for a task, honouring DB routing rules first. */
function selectModel({ tenantId, taskType = 'analysis', brainProfile = null, priority = 'normal', vaultLookup, preferQuality = true, exclude = [], freeOnly = false }) {
  const models = modelsFor(tenantId, { freeOnly }).filter((m) => !exclude.includes(m.id));
  const available = models.filter((m) => providerConfigured(m.provider, vaultLookup));
  const pool = available.length ? available : models; // fall back to configured-but-keyless (local brain handles it)

  // In free-only mode, provider-specific paid routing rules are irrelevant:
  // rank the free models directly by capability, quality, speed and cost (all $0).
  if (freeOnly) {
    if (!pool.length) return { model: null, rule: 'free-only:none' };
    return { model: rank(pool, preferQuality, priority)[0], rule: 'free-only' };
  }

  const rules = repo.rows(
    'SELECT * FROM router_rules WHERE (tenant_id IS NULL OR tenant_id = ?) AND enabled = 1 AND task_type = ? ORDER BY priority ASC',
    tenantId, taskType,
  );

  for (const rule of rules) {
    let candidates = pool;
    if (rule.target_model_id) candidates = candidates.filter((m) => m.id === rule.target_model_id);
    else if (rule.target_provider) candidates = candidates.filter((m) => m.provider === rule.target_provider);
    if (brainProfile) {
      const brainModels = repo.rows(
        `SELECT bm.model_id, bm.ordinal FROM brain_models bm
         JOIN brain_profiles bp ON bp.id = bm.brain_profile_id
         WHERE bp.name = ? ORDER BY bm.ordinal ASC`, brainProfile,
      ).map((r) => r.model_id);
      const restricted = candidates.filter((m) => brainModels.includes(m.id));
      if (restricted.length) candidates = restricted;
    }
    if (candidates.length) return { model: rank(candidates, preferQuality, priority)[0], rule: rule.name };
  }

  if (brainProfile) {
    const brainModels = repo.rows(
      `SELECT bm.model_id, bm.ordinal FROM brain_models bm
       JOIN brain_profiles bp ON bp.id = bm.brain_profile_id
       WHERE bp.name = ? ORDER BY bm.ordinal ASC`, brainProfile,
    ).map((r) => r.model_id);
    const restricted = pool.filter((m) => brainModels.includes(m.id));
    if (restricted.length) return { model: rank(restricted, preferQuality, priority)[0], rule: `brain-profile:${brainProfile}` };
  }
  if (!pool.length) return { model: null, rule: 'none' };
  return { model: rank(pool, preferQuality, priority)[0], rule: 'default' };
}

function rank(list, preferQuality, priority) {
  const qualityWeight = preferQuality ? 0.6 : 0.25;
  const speedWeight = preferQuality ? 0.15 : 0.45;
  const costWeight = priority === 'high' ? 0.05 : 0.3;
  const capWeight = 0.2;
  return [...list].sort((a, b) => score(b) - score(a));
  function score(m) {
    const costScore = 1 / (1 + (m.cost_in + m.cost_out) / 10);
    const cap = Array.isArray(JSON.parse(m.capabilities || '[]')) ? JSON.parse(m.capabilities || '[]').length / 7 : 0;
    return qualityWeight * (m.quality / 10) + speedWeight * (m.speed / 10) + costWeight * costScore + capWeight * cap;
  }
}

function selectBrainModels({ tenantId, brainProfile, vaultLookup, count = 1, exclude = [], freeOnly = false }) {
  const brain = repo.rows('SELECT * FROM brain_profiles WHERE (tenant_id IS NULL OR tenant_id = ?) AND name = ?', tenantId, brainProfile)[0];
  const mode = brain?.mode || 'single';
  const strategy = safeParse(brain?.strategy, {});
  const free = freeOnly || strategy.freeOnly === true || brainProfile === 'Free Tier Brain';
  const target = mode === 'consensus' ? Math.max(3, count) : mode === 'triple' ? 3 : mode === 'dual' ? 2 : count;
  const chosen = [];
  const used = [...exclude];
  for (let i = 0; i < target; i++) {
    const { model } = selectModel({ tenantId, taskType: 'analysis', brainProfile, vaultLookup, exclude: used, freeOnly: free });
    if (!model) break;
    used.push(model.id);
    chosen.push(model);
  }
  if (!chosen.length) {
    const { model } = selectModel({ tenantId, taskType: 'analysis', vaultLookup, exclude, freeOnly: free });
    if (model) chosen.push(model);
  }
  return { mode, models: chosen, freeOnly: free };
}

/**
 * Route a completion request. Returns the primary result plus, for multi-brain
 * modes, the individual model results and a consensus synthesis.
 */
async function route({ tenantId, taskType = 'analysis', brainProfile = null, messages, priority = 'normal', vaultLookup, temperature, maxTokens, json = false, exclude = [], freeOnly = false, failover = true }) {
  const { mode, models, freeOnly: free } = selectBrainModels({ tenantId, brainProfile, vaultLookup, exclude, freeOnly });
  if (!models.length) {
    const res = await providers.chat({ provider: 'ollama', messages, temperature, maxTokens, json, vaultLookup, allowFallback: true });
    return { mode: 'local', results: [res], primary: res, models: ['local-heuristic'], freeOnly: free };
  }

  const picked = mode === 'rotating' ? [models[rotationCursor++ % models.length]] : models;

  const results = [];
  for (const model of picked) {
    let res = await providers.chat({
      provider: model.provider, model: model.model_id, messages,
      temperature, maxTokens, json, vaultLookup, allowFallback: true,
    });
    // Failover: if a provider is unconfigured or errored and degraded, try the
    // next-ranked model of the same free/paid pool before falling back locally.
    if (failover && res.degraded && res.reason && res.reason !== 'no-key') {
      const alternatives = modelsFor(tenantId, { freeOnly: free })
        .filter((m) => m.id !== model.id && !picked.some((p) => p.id === m.id))
        .filter((m) => providerConfigured(m.provider, vaultLookup));
      for (const alt of alternatives.slice(0, 2)) {
        const retry = await providers.chat({
          provider: alt.provider, model: alt.model_id, messages,
          temperature, maxTokens, json, vaultLookup, allowFallback: true,
        });
        if (!retry.degraded) { retry.failoverFrom = `${model.provider}/${model.model_id}`; res = retry; break; }
      }
    }
    results.push({ ...res, modelName: model.name });
  }

  let primary = results[0];
  if ((mode === 'consensus' || mode === 'dual' || mode === 'triple') && results.length > 1) {
    primary = await consensus({ results, messages, vaultLookup, json });
  }
  return { mode, results, primary, models: picked.map((m) => m.model_id), freeOnly: free };
}

function safeParse(v, def) { try { return typeof v === 'string' ? JSON.parse(v) : (v ?? def); } catch { return def; } }

async function consensus({ results, messages, vaultLookup, json }) {
  const joined = results.map((r, i) => `--- Model ${i + 1} (${r.provider}/${r.model}) ---\n${r.content}`).join('\n\n');
  const synthMessages = [
    { role: 'system', content: 'You are the Consensus Brain. Synthesize the strongest single answer from multiple model outputs. Resolve disagreements, keep the best concrete detail, and return ONLY the merged answer.' },
    { role: 'user', content: `Original request:\n${messages.map((m) => `${m.role}: ${m.content}`).join('\n')}\n\nModel outputs:\n${joined}` },
  ];
  const best = results.reduce((a, b) => (a.tokensOut >= b.tokensOut ? a : b));
  try {
    const merged = await providers.chat({
      provider: best.provider, model: best.model, messages: synthMessages, vaultLookup, json, allowFallback: true,
    });
    return { ...merged, consensusOf: results.map((r) => `${r.provider}/${r.model}`) };
  } catch {
    return results[0];
  }
}

module.exports = { selectModel, selectBrainModels, route, modelsFor, freeModels };
