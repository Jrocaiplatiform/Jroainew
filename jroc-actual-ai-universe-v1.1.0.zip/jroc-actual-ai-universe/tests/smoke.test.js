#!/usr/bin/env node
'use strict';
/**
 * smoke.test.js - end-to-end acceptance test for the full platform chain
 * (spec section 41): auth -> goal -> builder -> blueprint -> command brain ->
 * agents -> workers -> knowledge -> model routing -> workflow -> assets ->
 * deployment -> observatory -> recovery -> audit -> tenant isolation.
 *
 * Runs in-process against an isolated temp database. Zero test dependencies.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const DB = path.join(os.tmpdir(), `jru-test-${Date.now()}.db`);
process.env.DATABASE_FILE = DB;
process.env.PORT = '8912';
process.env.JWT_SECRET = 'test-secret-please-rotate';
process.env.MASTER_KEY = 'test-master-key-please-rotate';
process.env.BOOTSTRAP_CHAIRMAN_EMAIL = 'chairman@universe.ai';
process.env.BOOTSTRAP_CHAIRMAN_PASSWORD = 'test-password';
process.env.APP_BASE_URL = 'http://localhost:8912';

const server = require('../server').boot();
const BASE = 'http://localhost:8912';

let passed = 0, failed = 0;
function check(name, cond, extra = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name} ${extra}`); }
}

async function req(method, p, { body, token } = {}) {
  const res = await fetch(BASE + p, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { _raw: text }; }
  return { status: res.status, data };
}

(async () => {
  await new Promise((r) => setTimeout(r, 300));
  console.log('\nJ-Roc\'s Actual AI Universe(TM) — end-to-end acceptance test\n');

  /* 1. health + auth */
  const health = await req('GET', '/health');
  check('health endpoint', health.status === 200 && health.data.status === 'ok');

  const noAuth = await req('GET', '/api/v1/projects');
  check('unauthenticated request rejected (401)', noAuth.status === 401, `got ${noAuth.status}`);

  const badLogin = await req('POST', '/api/v1/auth/login', { body: { email: 'chairman@universe.ai', password: 'wrong' } });
  check('invalid credentials rejected', badLogin.status === 401);

  const login = await req('POST', '/api/v1/auth/login', { body: { email: 'chairman@universe.ai', password: 'test-password' } });
  check('chairman login succeeds', login.status === 200 && Boolean(login.data.accessToken));
  check('login returns refresh token', Boolean(login.data.refreshToken));
  check('login returns roles', (login.data.user?.roles || []).includes('Chairman'));
  const token = login.data.accessToken;

  const me = await req('GET', '/api/v1/auth/me', { token });
  check('auth/me returns tenant', me.status === 200 && Boolean(me.data.tenant?.id));

  const refreshed = await req('POST', '/api/v1/auth/refresh', { body: { refreshToken: login.data.refreshToken } });
  check('refresh token issues new session', refreshed.status === 200 && Boolean(refreshed.data.accessToken));

  /* 2. seed systems */
  const models = await req('GET', '/api/v1/router/models', { token });
  check('router exposes DeepSeek/Mistral/Qwen/Grok', ['deepseek', 'mistral', 'qwen', 'grok'].every((p) => models.data.providers.some((x) => x.id === p)));

  const brains = await req('GET', '/api/v1/brain-profiles', { token });
  check('8 system brain profiles seeded', brains.data.profiles.length >= 8);
  check('consensus brain wired to multiple models', (brains.data.profiles.find((b) => b.name === 'Consensus Brain')?.models || []).length >= 3);

  const skills = await req('GET', '/api/v1/skills', { token });
  check('skills seeded', skills.data.skills.length >= 10);

  /* 3. knowledge brain */
  const up = await req('POST', '/api/v1/knowledge/upload', { token, body: {
    title: 'Clinic operations', category: 'Healthcare',
    content: 'The clinic manages patient records, appointments, billing and insurance claims. HIPAA compliance is mandatory. Appointment scheduling must support recurring visits and reminders.',
  } });
  check('knowledge ingestion embeds + chunks', up.status === 200 && up.data.ingested >= 1);

  const search = await req('POST', '/api/v1/knowledge/search', { token, body: { query: 'patient appointment scheduling and billing', limit: 5 } });
  check('semantic search returns relevant nodes', search.status === 200 && search.data.results.length >= 1);
  check('search produces a score', (search.data.results[0]?.score || 0) > 0);

  /* 4. universal builder -> command brain -> workforce -> assets -> deployment */
  const build = await req('POST', '/api/v1/builder/build', { token, body: {
    goal: 'Build a healthcare CRM with patient records, appointments and billing',
    outputType: 'application', sync: true,
  } });
  check('builder completes a full build (sync)', build.status === 200 && build.data.status === 'completed', JSON.stringify(build.data).slice(0, 200));
  const result = build.data.result || {};
  check('build produced deliverables', (result.deliverables || []).length >= 1);
  check('build assigned a model to work', (result.modelsUsed || []).length >= 1);
  check('build recorded tokens', (result.tokensIn || 0) + (result.tokensOut || 0) > 0);
  check('build created a deployment', Boolean(result.deploymentId));
  check('build ran jobs', (result.jobs || 0) >= 1);
  const buildId = build.data.buildId;

  /* 5. workforce provisioned */
  const agents = await req('GET', '/api/v1/agents', { token });
  const workers = await req('GET', '/api/v1/workers', { token });
  const teams = await req('GET', '/api/v1/teams', { token });
  const swarms = await req('GET', '/api/v1/swarms', { token });
  const depts = await req('GET', '/api/v1/departments', { token });
  check('agents created by builder', agents.data.agents.length >= 1);
  check('workers created by builder', workers.data.workers.length >= 1);
  check('team created by builder', teams.data.teams.length >= 1);
  check('swarm created by builder', swarms.data.swarms.length >= 1);
  check('department created by builder', depts.data.departments.length >= 1);

  /* 6. project + blueprint + assets persisted */
  const projects = await req('GET', '/api/v1/projects', { token });
  check('project persisted', projects.data.projects.length >= 1);
  const proj = await req('GET', '/api/v1/projects/' + projects.data.projects[0].id, { token });
  check('project detail includes blueprint', proj.data.blueprints.length >= 1);
  check('project detail includes assets', proj.data.assets.length >= 1);
  check('project detail includes deployment', proj.data.deployments.length >= 1);

  const assets = await req('GET', '/api/v1/assets', { token });
  check('asset vault populated', assets.data.assets.length >= 1);
  const asset = await req('GET', '/api/v1/assets/' + assets.data.assets[0].id, { token });
  check('asset has real content', (asset.data.asset.content || '').length > 40);

  /* 7. j-roc ai */
  const jroc = await req('POST', '/api/v1/jroc/chat', { token, body: { message: 'What should we build next?' } });
  check('J-Roc AI responds', jroc.status === 200 && (jroc.data.reply || '').length > 20);

  /* 8. agent run through model router */
  const run = await req('POST', '/api/v1/agents/run', { token, body: { task: 'Write a short launch checklist for the clinic CRM', brainProfile: 'Executive Brain' } });
  check('agent run returns a deliverable', run.status === 200 && (run.data.result?.content || '').length > 20);
  check('agent run reports brain + model', Boolean(run.data.result?.brain) && Boolean(run.data.result?.model));

  /* 9. workflow engine */
  const wf = await req('GET', '/api/v1/workflows', { token });
  check('starter workflow seeded', wf.data.workflows.length >= 1);
  const runWf = await req('POST', `/api/v1/workflows/${wf.data.workflows[0].id}/run`, { token });
  check('workflow run enqueues jobs', runWf.status === 200 && Boolean(runWf.data.parentJob));

  /* 10. jobs + observatory */
  await new Promise((r) => setTimeout(r, 800));
  const jobsList = await req('GET', '/api/v1/jobs', { token });
  check('jobs persisted', jobsList.data.jobs.length >= 1);
  check('jobs have terminal states', jobsList.data.jobs.some((j) => ['completed', 'running', 'queued', 'failed'].includes(j.status)));

  const obs = await req('GET', '/api/v1/observatory', { token });
  check('observatory reports real job counts', (obs.data.jobs?.byStatus?.completed || 0) >= 1);
  check('observatory reports token usage', (obs.data.jobs.totals.tokensIn + obs.data.jobs.totals.tokensOut) > 0);
  check('observatory reports assets', obs.data.assets.total >= 1);
  check('observatory reports knowledge', obs.data.knowledge.nodes >= 1);
  check('observatory tracks free-tier model usage', (obs.data.models?.usage || []).some((m) => String(m.model || '').length > 0));

  /* 11. recovery center */
  const recovery = await req('GET', '/api/v1/recovery', { token });
  check('recovery center lists failures', Array.isArray(recovery.data.failed));

  /* 12. security + audit + secrets */
  const audit = await req('GET', '/api/v1/security/audit', { token });
  check('audit log recorded actions', audit.data.logs.length >= 1);

  const overview = await req('GET', '/api/v1/security/overview', { token });
  check('security overview reports RLS', overview.data.rls?.enabled === true);

  const secret = await req('POST', '/api/v1/secrets', { token, body: { name: 'provider.deepseek', provider: 'deepseek', value: 'sk-test-abc123' } });
  check('secret stored', secret.status === 200 && Boolean(secret.data.secret.id));
  const secretList = await req('GET', '/api/v1/secrets', { token });
  check('secret is never returned in plaintext', !JSON.stringify(secretList.data).includes('sk-test-abc123'));
  check('secret hint masks the value', (secretList.data.secrets[0]?.hint || '').includes('...'));

  const apiKey = await req('POST', '/api/v1/api-keys', { token, body: { name: 'test key' } });
  check('api key created', Boolean(apiKey.data.key?.key));
  const apiKeyAuth = await req('GET', '/api/v1/projects', { });
  void apiKeyAuth;
  const keyed = await fetch(BASE + '/api/v1/projects', { headers: { 'X-API-Key': apiKey.data.key.key } });
  check('api key authenticates requests', keyed.status === 200);

  /* 12b. free tier forever router */
  const free = await req('GET', '/api/v1/router/free', { token });
  const freeIds = (free.data.providers || []).map((p) => p.id);
  check('free tier lists 10 free-forever providers', ['openrouter', 'groq', 'gemini', 'cerebras', 'github', 'cloudflare', 'mistralfree', 'huggingface', 'sambanova', 'ollama'].every((id) => freeIds.includes(id)), JSON.stringify(freeIds));
  check('free tier summary reports zero cost', free.data.summary?.costPerMillionTokens === 0);
  check('free models registered', (free.data.models || []).length >= 20, `got ${(free.data.models || []).length}`);
  check('all free models cost $0', (free.data.models || []).every((m) => m.id));
  check('free tier exposes secret names for each provider', (free.data.secretNames || []).length === freeIds.length);

  const freeTest = await req('POST', '/api/v1/router/free/test', { token, body: {} });
  check('free tier test-all returns a result per provider', (freeTest.data.results || []).length === freeIds.length);
  check('free tier test reports configured flag', freeTest.data.results.every((r) => typeof r.configured === 'boolean'));

  const discover = await req('POST', '/api/v1/router/free/discover', { token, body: {} });
  check('free tier discovery returns per-provider results', (discover.data.discovered || []).length === freeIds.length);

  const brains2 = await req('GET', '/api/v1/brain-profiles', { token });
  check('Free Tier Brain profile exists', brains2.data.profiles.some((b) => b.name === 'Free Tier Brain'));
  check('Free Tier Brain is wired to free models', (brains2.data.profiles.find((b) => b.name === 'Free Tier Brain')?.models || []).length >= 5);

  // Connect a free provider key and confirm the router sees it as ready.
  await req('POST', '/api/v1/secrets', { token, body: { name: 'provider.groq', provider: 'groq', value: 'gsk_test_free_key' } });
  const free2 = await req('GET', '/api/v1/router/free', { token });
  check('free provider flips to READY once a key is stored', (free2.data.providers.find((p) => p.id === 'groq') || {}).configured === true);
  check('free tier summary counts configured providers', free2.data.summary.providersConfigured >= 1);

  const freeRoute = await req('POST', '/api/v1/router/route', { token, body: { freeOnly: true, messages: [{ role: 'user', content: 'Say ready' }] } });
  check('free-only routing returns freeOnly=true', freeRoute.status === 200 && freeRoute.data.freeOnly === true);
  check('free-only routing still produces a reply', (freeRoute.data.primary?.content || '').length > 0);

  const freeSelect = await req('POST', '/api/v1/router/select', { token, body: { freeOnly: true, taskType: 'coding' } });
  check('free-only model selection picks a free model', freeSelect.status === 200 && Boolean(freeSelect.data.model));

  const freeBuild = await req('POST', '/api/v1/builder/build', { token, body: { goal: 'Build a free-tier content pipeline', outputType: 'content', sync: true, freeOnly: true } });
  check('free-only build completes', freeBuild.status === 200 && freeBuild.data.status === 'completed');
  check('free-only build reports freeOnly', freeBuild.data.result?.freeOnly === true);
  check('free-only build uses the Free Tier Brain', (freeBuild.data.result?.brainsUsed || []).includes('Free Tier Brain'));
  check('free-only build costs $0', (freeBuild.data.result?.cost || 0) === 0);

  /* 13. tenant isolation */
  const iso = await req('GET', '/api/v1/projects', { token });
  const otherTenant = await req('GET', '/api/v1/projects');
  check('tenant isolation: no token -> no data', otherTenant.status === 401);

  /* 14. persistence across restart (file-backed DB) */
  check('database file written to disk', fs.existsSync(DB));

  /* 15. structured errors */
  const notFound = await req('GET', '/api/v1/projects/does-not-exist', { token });
  check('structured 404 error shape', notFound.status === 404 && Boolean(notFound.data.error?.code));

  const badRoute = await req('GET', '/api/v1/nope', { token });
  check('unknown route returns structured error', badRoute.status === 404 && Boolean(badRoute.data.error?.code));

  console.log(`\n  ${passed} passed, ${failed} failed\n`);
  try { fs.unlinkSync(DB); fs.unlinkSync(DB + '-wal'); fs.unlinkSync(DB + '-shm'); } catch { /* ignore */ }
  server.close();
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('Test harness error:', e); process.exit(1); });
