/* ============================================================================
 * J-Roc's Actual AI Universe(TM) - application shell
 * Mobile + tablet + desktop PWA. Talks to the live backend only (no fixtures).
 * ==========================================================================*/
'use strict';

/* ------------------------------- state ---------------------------------- */
const S = {
  accessToken: localStorage.getItem('jru_access') || null,
  refreshToken: localStorage.getItem('jru_refresh') || null,
  user: JSON.parse(localStorage.getItem('jru_user') || 'null'),
  tenant: JSON.parse(localStorage.getItem('jru_tenant') || 'null'),
  route: location.hash.replace(/^#\/?/, '') || 'dashboard',
  freeOnly: localStorage.getItem('jru_freeonly') === '1',
  live: false,
  es: null,
  cache: {},
  chat: [],
};

/* ------------------------------- utils ---------------------------------- */
function el(tag, props = {}, ...kids) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
    else node.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(9)) {
    if (kid === null || kid === undefined || kid === false) continue;
    node.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return node;
}
const $ = (sel, root = document) => root.querySelector(sel);

function toast(msg, kind = '') {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast ' + kind;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, 3800);
}

function esc(s) { return String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function ago(iso) {
  if (!iso) return '';
  const d = (Date.now() - new Date(iso).getTime()) / 1000;
  if (d < 60) return 'just now';
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  return `${Math.floor(d / 86400)}d ago`;
}
function bytes(n) {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(Math.floor(Math.log(n) / Math.log(1024)), 3);
  return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${u[i]}`;
}
function statusPill(status) {
  const s = String(status || '').toLowerCase();
  const map = { completed: 'green', deployed: 'green', active: 'green', connected: 'green', success: 'green', ok: 'green', delivered: 'green',
    running: 'blue', planning: 'blue', queued: 'blue', idle: 'blue', draft: 'blue', ready: 'blue',
    recovering: 'amber', paused: 'amber', pending: 'amber', degraded: 'amber',
    failed: 'red', error: 'red', cancelled: 'red', revoked: 'red', disconnected: 'red' };
  return el('span', { class: `pill ${map[s] || ''}` }, status || '—');
}

/* -------------------------------- api ----------------------------------- */
async function api(path, { method = 'GET', body, raw = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (S.accessToken) headers.Authorization = `Bearer ${S.accessToken}`;
  let res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 401 && S.refreshToken && !path.includes('/auth/')) {
    const ok = await tryRefresh();
    if (ok) {
      headers.Authorization = `Bearer ${S.accessToken}`;
      res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    }
  }
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { _raw: text }; }
  if (!res.ok) {
    const err = new Error(data?.error?.message || `HTTP ${res.status}`);
    err.code = data?.error?.code; err.status = res.status; err.traceId = data?.error?.traceId;
    throw err;
  }
  return data;
}

async function tryRefresh() {
  try {
    const r = await fetch('/api/v1/auth/refresh', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: S.refreshToken }),
    });
    if (!r.ok) return false;
    const d = await r.json();
    if (!d.accessToken) return false;
    setSession(d);
    return true;
  } catch { return false; }
}

function setSession(d) {
  S.accessToken = d.accessToken; S.refreshToken = d.refreshToken || S.refreshToken;
  S.user = d.user || S.user;
  localStorage.setItem('jru_access', S.accessToken || '');
  localStorage.setItem('jru_refresh', S.refreshToken || '');
  localStorage.setItem('jru_user', JSON.stringify(S.user || null));
}

function clearSession() {
  S.accessToken = S.refreshToken = null; S.user = null; S.tenant = null; S.chat = [];
  ['jru_access', 'jru_refresh', 'jru_user', 'jru_tenant'].forEach((k) => localStorage.removeItem(k));
  if (S.es) { S.es.close(); S.es = null; S.live = false; }
}

/* ------------------------------- nav ------------------------------------ */
const NAV = [
  { group: 'Command' },
  { id: 'dashboard', label: 'Dashboard', icon: '◈', primary: true },
  { id: 'builder', label: 'Universal Builder', icon: '⬢', primary: true },
  { id: 'jroc', label: 'J-Roc AI', icon: '✦', primary: true },
  { id: 'projects', label: 'Projects', icon: '▤' },
  { id: 'blueprints', label: 'Blueprints', icon: '▦' },
  { group: 'Workforce' },
  { id: 'agents', label: 'Agents', icon: '⬡' },
  { id: 'workers', label: 'Workers', icon: '⬢' },
  { id: 'teams', label: 'Teams', icon: '⧉' },
  { id: 'departments', label: 'Departments', icon: '⌂' },
  { id: 'swarms', label: 'Swarms', icon: '❋' },
  { group: 'Intelligence' },
  { id: 'knowledge', label: 'Knowledge Brain', icon: '❖' },
  { id: 'memory', label: 'Memory', icon: '☷' },
  { id: 'router', label: 'Model Router', icon: '⇄' },
  { id: 'freemodels', label: 'Free Tier Router', icon: '⛁', primary: true },
  { id: 'brains', label: 'Brain Profiles', icon: '⌬' },
  { group: 'Systems' },
  { id: 'plugins', label: 'Plugin Hub', icon: '⊞' },
  { id: 'connectors', label: 'Connectors', icon: '⇋' },
  { id: 'workflows', label: 'Workflows', icon: '⟳' },
  { id: 'automations', label: 'Automations', icon: '⏱' },
  { id: 'assets', label: 'Asset Vault', icon: '▣' },
  { id: 'deployments', label: 'Deployments', icon: '⏏' },
  { group: 'Operations' },
  { id: 'observatory', label: 'Observatory', icon: '◎' },
  { id: 'recovery', label: 'Recovery', icon: '⚕' },
  { id: 'security', label: 'Security', icon: '⛨' },
  { id: 'settings', label: 'Settings', icon: '⚙' },
];
const MOBILE_NAV = ['dashboard', 'builder', 'jroc', 'freemodels', 'observatory'];

function renderShell() {
  const app = $('#app');
  app.innerHTML = '';
  const sidebar = el('aside', { class: 'sidebar', id: 'sidebar' },
    el('div', { class: 'brand' },
      el('div', { class: 'brand-mark' }, '◈'),
      el('div', { class: 'brand-txt' }, "J-ROC'S ACTUAL", el('small', {}, 'AI UNIVERSE™'))),
    ...NAV.map((n) => {
      if (n.group) return el('div', { class: 'nav-group' }, n.group);
      return el('div', {
        class: 'nav-item' + (S.route === n.id ? ' active' : ''), 'data-nav': n.id,
        onclick: () => { go(n.id); $('#sidebar')?.classList.remove('open'); },
      }, el('span', { class: 'nav-ico' }, n.icon), n.label);
    }),
    el('div', { class: 'side-foot' },
      el('div', { class: 'avatar' }, (S.user?.displayName || S.user?.email || 'U').charAt(0).toUpperCase()),
      el('div', { class: 'who' }, el('b', {}, S.user?.displayName || S.user?.email || 'User'), el('small', {}, (S.user?.roles || []).join(', ') || 'User')),
      el('button', { class: 'btn sm ghost', onclick: logout, title: 'Sign out' }, '⏻')),
  );

  const topbar = el('header', { class: 'topbar' },
    el('button', { class: 'menu-btn', onclick: () => $('#sidebar')?.classList.toggle('open') }, '☰'),
    el('h1', { id: 'page-title' }, 'Dashboard'),
    el('button', {
      class: 'pill ' + (S.freeOnly ? 'green' : ''), id: 'free-toggle', title: 'Route every build through free-forever providers only',
      onclick: toggleFreeOnly,
    }, S.freeOnly ? '⛁ FREE-ONLY ON' : '⛁ free-only off'),
    el('div', { class: 'live' }, el('span', { class: 'dot', id: 'live-dot' }), el('span', { id: 'live-txt' }, 'offline')),
  );

  const content = el('main', { class: 'content', id: 'content' });

  const mobileNav = el('nav', { class: 'mobile-nav' },
    ...MOBILE_NAV.map((id) => {
      const n = NAV.find((x) => x.id === id);
      return el('button', { class: 'mnav' + (S.route === id ? ' active' : ''), 'data-nav': id, onclick: () => go(id) },
        el('span', { class: 'nav-ico' }, n.icon), n.label.split(' ')[0]);
    }),
    el('button', { class: 'mnav', onclick: () => { go('settings'); } }, el('span', { class: 'nav-ico' }, '⚙'), 'More'),
  );

  const overlay = el('div', { class: 'overlay', id: 'overlay', onclick: () => { $('#sidebar')?.classList.remove('open'); $('#overlay')?.classList.remove('show'); } });
  app.append(sidebar, el('div', { class: 'main' }, topbar, content), mobileNav, overlay);
  document.querySelectorAll('.nav-item,.mnav').forEach((n) => {
    if (n.dataset.nav === S.route) n.classList.add('active');
  });
}

function toggleFreeOnly() {
  S.freeOnly = !S.freeOnly;
  localStorage.setItem('jru_freeonly', S.freeOnly ? '1' : '0');
  const t = $('#free-toggle');
  if (t) { t.className = 'pill ' + (S.freeOnly ? 'green' : ''); t.textContent = S.freeOnly ? '⛁ FREE-ONLY ON' : '⛁ free-only off'; }
  toast(S.freeOnly ? 'Free-only mode ON — all builds route through free providers' : 'Free-only mode off', S.freeOnly ? 'ok' : '');
}

function go(id) {
  S.route = id;
  location.hash = '#/' + id;
  const item = NAV.find((n) => n.id === id);
  const title = $('#page-title');
  if (title) title.textContent = item ? item.label : id;
  document.querySelectorAll('[data-nav]').forEach((n) => n.classList.toggle('active', n.dataset.nav === id));
  renderView(id);
  window.scrollTo({ top: 0, behavior: 'instant' });
}

/* ------------------------------ components ------------------------------ */
function pageHead(title, sub, actions) {
  return el('div', { class: 'spread', style: { marginBottom: '16px', flexWrap: 'wrap' } },
    el('div', {}, el('h2', {}, title), sub ? el('div', { class: 'muted small', style: { marginTop: '3px' } }, sub) : null),
    actions ? el('div', { class: 'row' }, ...actions) : null);
}

function loader(text = 'Loading…') { return el('div', { class: 'empty' }, text); }

async function loadInto(container, loaderFn, renderFn) {
  container.innerHTML = ''; container.append(loader());
  try {
    const data = await loaderFn();
    container.innerHTML = '';
    container.append(renderFn(data));
  } catch (e) {
    container.innerHTML = '';
    container.append(el('div', { class: 'empty' }, el('div', {}, '⚠ ' + e.message), el('div', { class: 'tiny dim', style: { marginTop: '6px' } }, e.code || '')));
  }
}

function modal(title, fields, onSubmit, submitLabel = 'Create') {
  const overlay = el('div', { class: 'overlay show', style: { display: 'grid', placeItems: 'center', padding: '16px' } });
  const form = el('form', { class: 'card', style: { maxWidth: '560px', width: '100%', maxHeight: '90dvh', overflowY: 'auto' } });
  form.append(el('h3', { style: { marginBottom: '14px' } }, title));
  const inputs = {};
  for (const f of fields) {
    const input = f.type === 'textarea'
      ? el('textarea', { class: 'input', placeholder: f.placeholder || '' })
      : f.type === 'select'
        ? el('select', { class: 'input' }, ...(f.options || []).map((o) => el('option', { value: o.value ?? o }, o.label ?? o)))
        : el('input', { class: 'input', type: f.type || 'text', placeholder: f.placeholder || '', value: f.value || '' });
    if (f.value !== undefined) input.value = f.value;
    inputs[f.name] = input;
    form.append(el('label', { class: 'field' }, el('label', {}, f.label || f.name), input));
  }
  form.append(el('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '8px' } },
    el('button', { class: 'btn ghost', type: 'button', onclick: () => overlay.remove() }, 'Cancel'),
    el('button', { class: 'btn primary', type: 'submit' }, submitLabel)));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = {};
    for (const [k, v] of Object.entries(inputs)) body[k] = v.value;
    try {
      await onSubmit(body);
      overlay.remove();
      toast('Saved', 'ok');
    } catch (err) { toast(err.message, 'err'); }
  });
  overlay.append(form);
  document.body.append(overlay);
}

/* ------------------------------- views ---------------------------------- */
const views = {};

/* ------------------------------ dashboard ------------------------------- */
views.dashboard = async (c) => {
  renderShell();
  const content = $('#content');
  const d = await api('/api/v1/dashboard').catch(() => ({}));
  const health = await api('/api/v1/brain/status').catch(() => ({}));

  content.append(pageHead('Command Deck', `Signed in as ${S.user?.displayName || S.user?.email}`, [
    el('button', { class: 'btn sm', onclick: () => go('observatory') }, '◎ Observatory'),
    el('button', { class: 'btn sm ghost', onclick: () => go('security') }, '⛨ Security'),
  ]));

  // Hero builder
  const input = el('input', { class: 'hero-input', placeholder: 'What would you like to build today?', onkeydown: (e) => { if (e.key === 'Enter') startBuild(input.value); } });
  content.append(el('div', { class: 'card', style: { marginBottom: '16px' } },
    el('div', { class: 'row', style: { marginBottom: '12px' } }, el('span', { class: 'pill purple' }, '⬢ UNIVERSAL BUILDER')),
    input,
    el('div', { class: 'row', style: { marginTop: '12px' } },
      el('button', { class: 'btn primary', onclick: () => startBuild(input.value) }, '▶ Build it'),
      el('button', { class: 'btn ghost', onclick: () => { go('builder'); } }, 'Open Builder'),
      el('button', { class: 'btn ghost', onclick: () => go('freemodels') }, '⛁ Free Tier Router'),
      el('span', { class: 'tiny dim' }, health.freeProviders?.length
        ? `${health.freeProviders.length} free providers ready${S.freeOnly ? ' · free-only ON' : ''}`
        : 'No keys yet — running on the local brain (add free keys in Free Tier Router)'))));

  const stats = el('div', { class: 'grid g4', style: { marginBottom: '16px' } },
    stat('Projects', d.projects?.length ?? 0, `${d.builds?.length ?? 0} builds`),
    stat('Agents', d.agents ?? 0, `${d.workers ?? 0} workers`),
    stat('Knowledge', d.knowledge ?? 0, 'nodes indexed'),
    stat('Active Jobs', d.activeJobs ?? 0, health.jobs?.running ? `${health.jobs.running} running` : 'idle'));
  content.append(stats);

  content.append(el('div', { class: 'grid g2' },
    el('div', { class: 'card' },
      el('div', { class: 'spread', style: { marginBottom: '12px' } }, el('h3', {}, 'Recent Projects'), el('button', { class: 'btn sm ghost', onclick: () => go('projects') }, 'All')),
      el('div', { class: 'list' }, ...(d.projects?.length ? d.projects.map((p) => el('div', { class: 'item', onclick: () => go('projects') },
        el('div', { class: 't' }, el('b', {}, p.name), el('small', {}, `${p.status} · ${ago(p.created_at)}`)), statusPill(p.status))) : [el('div', { class: 'empty' }, 'No projects yet. Use the builder above.')]))),
    el('div', { class: 'card' },
      el('div', { class: 'spread', style: { marginBottom: '12px' } }, el('h3', {}, 'Live Jobs'), el('span', { class: 'pill blue' }, `${d.activeJobs ?? 0} active`)),
      el('div', { class: 'list', id: 'live-jobs' }, ...(d.recentJobs?.length ? d.recentJobs.map(jobRow) : [el('div', { class: 'empty' }, 'No jobs yet.')])))),
  );

  if (d.notifications?.length) {
    content.append(el('div', { class: 'card', style: { marginTop: '16px' } },
      el('h3', { style: { marginBottom: '12px' } }, 'Notifications'),
      el('div', { class: 'list' }, ...d.notifications.map((n) => el('div', { class: 'item' },
        el('div', { class: 't' }, el('b', {}, n.title), el('small', {}, n.body)), el('span', { class: 'tiny dim' }, ago(n.created_at)))))));
  }
};

function stat(label, value, sub) {
  return el('div', { class: 'stat' }, el('span', {}, label), el('b', {}, String(value)), sub ? el('small', {}, sub) : null);
}
function jobRow(j) {
  return el('div', { class: 'item' },
    el('div', { class: 't' }, el('b', {}, j.name), el('small', {}, `${j.status} · ${ago(j.created_at)}`),
      j.status === 'running' ? el('div', { class: 'bar' }, el('i', { style: { width: `${j.progress || 0}%` } })) : null),
    statusPill(j.status));
}

async function startBuild(goal) {
  if (!goal || !goal.trim()) return toast('Enter what you want to build', 'err');
  toast('Dispatching to Universal Builder…');
  try {
    const r = await api('/api/v1/builder/build', { method: 'POST', body: { goal: goal.trim(), sync: false, freeOnly: S.freeOnly } });
    toast(`Build ${r.buildId.slice(0, 8)} running`, 'ok');
    go('builder');
    setTimeout(() => { const i = $('#builder-watch'); if (i) i.value = r.buildId; }, 300);
  } catch (e) { toast(e.message, 'err'); }
}

/* ------------------------------- builder -------------------------------- */
views.builder = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Universal Builder', 'Give a goal — the Command Brain plans, staffs and builds it.'));
  const goal = el('textarea', { class: 'input', placeholder: 'e.g. Build a healthcare CRM with patient records, appointments and billing' });
  const outType = el('select', { class: 'input' }, ...[
    ['application', 'Application'], ['content', 'Content / Media'], ['system', 'System'], ['research', 'Research'],
  ].map(([v, l]) => el('option', { value: v }, l)));
  const prio = el('select', { class: 'input' }, ...['low', 'normal', 'high'].map((p) => el('option', { value: p }, p)));
  const watch = el('input', { class: 'input', id: 'builder-watch', placeholder: 'Build ID to watch (optional)' });
  const log = el('div', { class: 'list', id: 'build-log' });

  content.append(el('div', { class: 'card' },
    el('label', { class: 'field' }, el('label', {}, 'Goal'), goal),
    el('div', { class: 'grid g2' },
      el('label', { class: 'field' }, el('label', {}, 'Output type'), outType),
      el('label', { class: 'field' }, el('label', {}, 'Priority'), prio)),
    el('div', { class: 'row' },
      el('button', { class: 'btn', onclick: async () => {
        try { const r = await api('/api/v1/builder/plan', { method: 'POST', body: { goal: goal.value, outputType: outType.value, freeOnly: S.freeOnly } });
          log.prepend(el('div', { class: 'item' }, el('div', { class: 't' }, el('b', {}, 'Plan generated'), el('small', {}, `${r.plan?.tasks?.length || 0} tasks · ${r.model || 'local'}`))));
          modal('Blueprint', [], () => {}); document.querySelector('.overlay .card')?.remove();
          showJson('Blueprint preview', r.plan);
        } catch (e) { toast(e.message, 'err'); }
      } }, '◈ Plan only'),
      el('button', { class: 'btn primary', onclick: async () => {
        if (!goal.value.trim()) return toast('Enter a goal', 'err');
        try {
          const r = await api('/api/v1/builder/build', { method: 'POST', body: { goal: goal.value, outputType: outType.value, priority: prio.value, sync: false, freeOnly: S.freeOnly } });
          watch.value = r.buildId;
          toast('Build running', 'ok');
          log.prepend(el('div', { class: 'item' }, el('div', { class: 't' }, el('b', {}, 'Build dispatched'), el('small', {}, r.buildId))));
        } catch (e) { toast(e.message, 'err'); }
      } }, '▶ Build (background)'),
      el('button', { class: 'btn', onclick: async () => {
        if (!goal.value.trim()) return toast('Enter a goal', 'err');
        toast('Building… this can take a while');
        try {
          const r = await api('/api/v1/builder/build', { method: 'POST', body: { goal: goal.value, outputType: outType.value, priority: prio.value, sync: true, freeOnly: S.freeOnly } });
          showJson('Build result', r.result);
        } catch (e) { toast(e.message, 'err'); }
      } }, '⏩ Build now (sync)'),
      el('button', { class: 'btn ghost', onclick: () => { go('builds'); } }, 'All builds'))));

  content.append(el('div', { class: 'card', style: { marginTop: '16px' } },
    el('div', { class: 'spread', style: { marginBottom: '12px' } }, el('h3', {}, 'Build Watch'),
      el('button', { class: 'btn sm', onclick: async () => {
        if (!watch.value) return toast('Enter a build id', 'err');
        try { const r = await api('/api/v1/builds/' + watch.value); showJson('Build ' + watch.value.slice(0, 8), r); } catch (e) { toast(e.message, 'err'); }
      } }, 'Inspect')),
    watch,
    el('div', { style: { marginTop: '14px' } }, log)));
};

views.builds = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Builds', 'Every Universal Builder run, persisted.'));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/builds'), (d) => el('div', { class: 'list' },
    ...(d.builds?.length ? d.builds.map((b) => el('div', { class: 'item', onclick: async () => {
      try { const r = await api('/api/v1/builds/' + b.id); showJson('Build detail', r); } catch (e) { toast(e.message, 'err'); }
    } }, el('div', { class: 't' }, el('b', {}, b.goal), el('small', {}, `${b.output_type} · ${ago(b.created_at)}`)), statusPill(b.status))) : [el('div', { class: 'empty' }, 'No builds yet.')])));
};

function showJson(title, obj) {
  const overlay = el('div', { class: 'overlay show', style: { display: 'grid', placeItems: 'center', padding: '14px' } });
  overlay.append(el('div', { class: 'card', style: { maxWidth: '860px', width: '100%', maxHeight: '88dvh', overflow: 'auto' } },
    el('div', { class: 'spread', style: { marginBottom: '12px' } }, el('h3', {}, title),
      el('button', { class: 'btn sm ghost', onclick: () => overlay.remove() }, 'Close')),
    el('pre', { class: 'out' }, JSON.stringify(obj, null, 2))));
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

/* -------------------------------- J-Roc --------------------------------- */
views.jroc = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('J-Roc AI', 'Executive intelligence — project-aware across the Universe.'));
  const chatBox = el('div', { class: 'chat', id: 'chat' });
  const paint = () => {
    chatBox.innerHTML = '';
    if (!S.chat.length) chatBox.append(el('div', { class: 'msg ai' }, "I'm J-Roc. Tell me what you need — I can advise, plan, or build it outright. Try: \"Plan a launch for my comic studio\" or \"Build a CRM for my clinic\"."));
    for (const m of S.chat) chatBox.append(el('div', { class: 'msg ' + m.role }, m.content, m.meta ? el('div', { class: 'meta' }, m.meta) : null));
    chatBox.scrollTop = chatBox.scrollHeight;
  };
  paint();
  const input = el('textarea', { class: 'input', placeholder: 'Ask J-Roc… (Enter to send)', style: { minHeight: '62px' }, onkeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } } });
  const brainSel = el('select', { class: 'input', style: { maxWidth: '220px' } },
    ...['Free Tier Brain', 'Executive Brain', 'Coding Brain', 'Research Brain', 'Reasoning Brain', 'Creative Brain', 'Planning Brain', 'Validation Brain', 'Consensus Brain'].map((b) => el('option', { value: b }, b)));

  async function send() {
    const text = input.value.trim(); if (!text) return;
    input.value = '';
    S.chat.push({ role: 'user', content: text }); paint();
    S.chat.push({ role: 'ai', content: '…thinking', meta: brainSel.value }); paint();
    try {
      const r = await api('/api/v1/jroc/chat', { method: 'POST', body: { message: text, history: S.chat.slice(0, -2).map((m) => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.content })), brainProfile: brainSel.value, freeOnly: S.freeOnly } });
      S.chat[S.chat.length - 1] = { role: 'ai', content: r.reply, meta: `${r.model} · ${r.mode}${r.degraded ? ' · local' : ''}` };
    } catch (e) { S.chat[S.chat.length - 1] = { role: 'ai', content: '⚠ ' + e.message }; }
    paint();
  }

  content.append(el('div', { class: 'card' },
    chatBox,
    el('div', { class: 'row', style: { marginTop: '12px' } }, brainSel,
      el('button', { class: 'btn primary', onclick: send }, 'Send'),
      el('button', { class: 'btn ghost', onclick: async () => { if (!input.value.trim()) return; const g = input.value; try { const r = await api('/api/v1/jroc/create', { method: 'POST', body: { what: g, freeOnly: S.freeOnly } }); toast('J-Roc is building: ' + r.buildId.slice(0, 8), 'ok'); input.value = ''; } catch (e) { toast(e.message, 'err'); } } }, '✦ Build this'),
      el('button', { class: 'btn ghost', onclick: () => { S.chat = []; paint(); } }, 'Clear'))));
};

/* ---------------------------- generic lists ----------------------------- */
function crudView({ title, sub, endpoint, key, columns, createFields, onRow, createLabel = 'New', extraActions }) {
  return async () => {
    renderShell();
    const content = $('#content');
    content.append(pageHead(title, sub, [
      createFields ? el('button', { class: 'btn primary', onclick: () => modal(createLabel, createFields, async (body) => {
        const payload = {};
        for (const f of createFields) {
          const v = body[f.name];
          if (v === '' || v === undefined) continue;
          payload[f.name] = f.type === 'json' ? safeParse(v) : f.type === 'list' ? v.split(',').map((s) => s.trim()).filter(Boolean) : v;
        }
        await api(endpoint, { method: 'POST', body: payload });
        go(S.route);
      }) }, '＋ ' + createLabel) : null,
      ...(extraActions || []),
      el('button', { class: 'btn sm ghost', onclick: () => go(S.route) }, '⟳'),
    ]));
    const box = el('div', { class: 'card' }); content.append(box);
    await loadInto(box, () => api(endpoint), (d) => {
      const items = d[key] || [];
      if (!items.length) return el('div', { class: 'empty' }, `No ${title.toLowerCase()} yet.`);
      return el('div', { class: 'list' }, ...items.map((it) => el('div', {
        class: 'item', onclick: () => onRow ? onRow(it) : showJson(title, it),
      },
        el('div', { class: 't' }, el('b', {}, it.name || it.title || it.goal || it.email || it.id.slice(0, 8)),
          el('small', {}, columns.map((col) => col(it)).filter(Boolean).join(' · '))),
        statusPill(it.status))));
    });
  };
}
function safeParse(s) { try { return JSON.parse(s); } catch { return s; } }

views.projects = crudView({
  title: 'Projects', sub: 'Every build, system and content project in the Universe.', endpoint: '/api/v1/projects', key: 'projects',
  createFields: [
    { name: 'name', label: 'Name', placeholder: 'Healthcare CRM' },
    { name: 'goal', label: 'Goal', type: 'textarea' },
    { name: 'priority', label: 'Priority', type: 'select', options: ['low', 'normal', 'high'] },
  ],
  columns: [(p) => p.priority, (p) => ago(p.created_at)],
  onRow: async (p) => { try { showJson('Project: ' + p.name, await api('/api/v1/projects/' + p.id)); } catch (e) { toast(e.message, 'err'); } },
});

views.blueprints = crudView({
  title: 'Blueprints', sub: 'Architecture, requirements and task plans.', endpoint: '/api/v1/blueprints', key: 'blueprints',
  columns: [(b) => b.output_type, (b) => `v${b.version}`],
});

views.agents = crudView({
  title: 'Agents', sub: 'Autonomous agents with system prompts, brains and memory.', endpoint: '/api/v1/agents', key: 'agents',
  createLabel: 'Agent',
  createFields: [
    { name: 'name', label: 'Name', placeholder: 'Research Agent' },
    { name: 'role', label: 'Role', placeholder: 'researcher' },
    { name: 'systemPrompt', label: 'System prompt', type: 'textarea' },
    { name: 'brainProfile', label: 'Brain', type: 'select', options: ['Free Tier Brain', 'Executive Brain', 'Coding Brain', 'Research Brain', 'Reasoning Brain', 'Creative Brain', 'Planning Brain', 'Validation Brain', 'Consensus Brain'] },
  ],
  columns: [(a) => a.role, (a) => a.brain_profile],
  extraActions: [el('button', { class: 'btn sm', onclick: () => modal('Run an agent', [
    { name: 'agentId', label: 'Agent ID (blank = ad-hoc)' }, { name: 'task', label: 'Task', type: 'textarea' },
    { name: 'brainProfile', label: 'Brain', type: 'select', options: ['Free Tier Brain', 'Executive Brain', 'Coding Brain', 'Research Brain', 'Reasoning Brain', 'Creative Brain', 'Planning Brain', 'Validation Brain', 'Consensus Brain'] },
  ], async (b) => { const r = await api('/api/v1/agents/run', { method: 'POST', body: { ...b, freeOnly: S.freeOnly } }); showJson('Agent run', r); }, 'Run') }, '▶ Run')],
});

views.workers = crudView({
  title: 'Workers', sub: 'Workers execute tasks under agents.', endpoint: '/api/v1/workers', key: 'workers',
  createLabel: 'Worker',
  createFields: [
    { name: 'name', label: 'Name' }, { name: 'role', label: 'Role' },
    { name: 'skills', label: 'Skills (comma separated)', type: 'list' },
    { name: 'brainProfile', label: 'Brain', type: 'select', options: ['Free Tier Brain', 'Executive Brain', 'Coding Brain', 'Research Brain', 'Reasoning Brain', 'Creative Brain', 'Planning Brain', 'Validation Brain', 'Consensus Brain'] },
  ],
  columns: [(w) => w.role, (w) => (safeParse(w.skills) || []).join(', ')],
});

views.teams = crudView({
  title: 'Teams', sub: 'Agents and workers grouped for coordinated delivery.', endpoint: '/api/v1/teams', key: 'teams',
  createLabel: 'Team', createFields: [{ name: 'name', label: 'Name' }, { name: 'purpose', label: 'Purpose', type: 'textarea' }, { name: 'strategy', label: 'Strategy', type: 'select', options: ['parallel', 'pipeline', 'mesh'] }],
  columns: [(t) => t.strategy, (t) => `${(t.members || []).length} members`],
});
views.departments = crudView({
  title: 'Departments', sub: 'Permanent organisational units.', endpoint: '/api/v1/departments', key: 'departments',
  createLabel: 'Department', createFields: [{ name: 'name', label: 'Name' }, { name: 'mandate', label: 'Mandate', type: 'textarea' }],
  columns: [(d) => `${(d.members || []).length} members`],
});
views.swarms = crudView({
  title: 'Swarms', sub: 'Mesh, star, pipeline and hierarchical worker swarms.', endpoint: '/api/v1/swarms', key: 'swarms',
  createLabel: 'Swarm', createFields: [{ name: 'name', label: 'Name' }, { name: 'objective', label: 'Objective', type: 'textarea' }, { name: 'topology', label: 'Topology', type: 'select', options: ['mesh', 'star', 'pipeline', 'hierarchical'] }],
  columns: [(s) => s.topology, (s) => `${(s.members || []).length} workers`],
});

views.knowledge = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Knowledge Brain', 'RAG · embeddings · vector + semantic search · knowledge graph.', [
    el('button', { class: 'btn primary', onclick: () => modal('Ingest knowledge', [
      { name: 'title', label: 'Title' },
      { name: 'category', label: 'Category', type: 'select', options: ['Business', 'Marketing', 'Sales', 'Finance', 'Software', 'Design', 'Comics', 'Publishing', 'Games', 'Video', 'Music', 'Healthcare', 'Education', 'Legal', 'Operations'] },
      { name: 'content', label: 'Content', type: 'textarea', placeholder: 'Paste documents, notes, specs…' },
    ], async (b) => { const r = await api('/api/v1/knowledge/upload', { method: 'POST', body: b }); toast(`Indexed ${r.ingested} chunk(s)`, 'ok'); go('knowledge'); }, 'Ingest') }, '＋ Ingest'),
  ]));
  const q = el('input', { class: 'input', placeholder: 'Semantic search…', onkeydown: (e) => { if (e.key === 'Enter') run(); } });
  const results = el('div', { class: 'card', style: { marginTop: '16px' } });
  async function run() {
    if (!q.value.trim()) return;
    await loadInto(results, () => api('/api/v1/knowledge/search', { method: 'POST', body: { query: q.value, limit: 10 } }), (d) => el('div', {},
      el('div', { class: 'tiny dim', style: { marginBottom: '10px' } }, `${d.results.length} results · embedding: ${d.embeddingModel}`),
      el('div', { class: 'list' }, ...d.results.map((r) => el('div', { class: 'item', onclick: () => showJson(r.node.title, r.node) },
        el('div', { class: 't' }, el('b', {}, r.node.title), el('small', {}, `${r.node.category} · score ${r.score.toFixed(3)}`)), el('span', { class: 'pill blue' }, r.node.category))))));
  }
  content.append(el('div', { class: 'card' }, el('div', { class: 'row' }, q, el('button', { class: 'btn primary', onclick: run }, 'Search'))));
  const listBox = el('div', { class: 'card', style: { marginTop: '16px' } });
  content.append(listBox);
  await loadInto(listBox, () => api('/api/v1/knowledge/nodes'), (d) => el('div', {},
    el('div', { class: 'tiny dim', style: { marginBottom: '10px' } }, `${d.nodes.length} nodes · categories: ${(d.categories || []).join(', ')}`),
    el('div', { class: 'list' }, ...(d.nodes.length ? d.nodes.slice(0, 60).map((n) => el('div', { class: 'item', onclick: () => showJson(n.title, n) },
      el('div', { class: 't' }, el('b', {}, n.title), el('small', {}, `${n.category} · ${ago(n.created_at)}`)), el('span', { class: 'pill' }, n.source))) : [el('div', { class: 'empty' }, 'No knowledge yet. Ingest something.')]))));
};

views.memory = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Memory', 'Universe, project, agent, worker, character, business, personal, document and archive memory.', [
    el('button', { class: 'btn primary', onclick: () => modal('Store memory', [
      { name: 'scope', label: 'Scope', type: 'select', options: ['Universe Memory', 'Project Memory', 'Agent Memory', 'Worker Memory', 'Character Memory', 'Business Memory', 'Personal Memory', 'Document Memory', 'Archive Memory'] },
      { name: 'content', label: 'Content', type: 'textarea' }, { name: 'importance', label: 'Importance (1-10)', type: 'number', value: '5' },
    ], async (b) => { await api('/api/v1/memories', { method: 'POST', body: { ...b, importance: Number(b.importance) } }); go('memory'); }) }, '＋ Remember'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/memories'), (d) => el('div', { class: 'list' },
    ...(d.memories?.length ? d.memories.map((m) => el('div', { class: 'item', onclick: () => showJson('Memory', m) },
      el('div', { class: 't' }, el('b', {}, m.content.slice(0, 80)), el('small', {}, `${m.scope} · importance ${m.importance} · ${ago(m.created_at)}`)))) : [el('div', { class: 'empty' }, 'No memories yet.')])));
};

views.router = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Model Router', 'Single · dual · triple · consensus · rotating brains across paid providers and the free-forever tier.', [
    el('button', { class: 'btn sm ' + (S.freeOnly ? 'primary' : ''), onclick: () => go('freemodels') }, '⛁ Free Tier Router'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/router/models'), (d) => el('div', {},
    el('h3', { style: { marginBottom: '12px' } }, 'Providers'),
    el('div', { class: 'grid g3', style: { marginBottom: '18px' } }, ...d.providers.map((p) => el('div', { class: 'stat' },
      el('div', { class: 'spread' }, el('span', {}, p.label), p.freeForever ? el('span', { class: 'pill green' }, 'FREE') : null),
      el('b', { style: { fontSize: '16px' } }, p.configured ? 'READY' : 'NO KEY'),
      el('small', {}, p.defaultModel)))),
    el('h3', { style: { marginBottom: '12px' } }, 'Models'),
    el('table', { class: 'tbl' },
      el('thead', {}, el('tr', {}, ...['Provider', 'Model', 'Quality', 'Speed', 'Cost in/out', 'Tier', 'Configured'].map((h) => el('th', {}, h)))),
      el('tbody', {}, ...d.models.map((m) => el('tr', {},
        el('td', {}, m.provider), el('td', {}, m.model_id), el('td', {}, String(m.quality)), el('td', {}, String(m.speed)),
        el('td', {}, m.freeTier ? '$0 / $0' : `$${m.cost_in}/$${m.cost_out}`),
        el('td', {}, m.freeTier ? el('span', { class: 'pill green' }, 'FREE') : el('span', { class: 'pill' }, 'paid')),
        el('td', {}, m.configured ? '✓' : '—')))))));
};

/* --------------------------- free tier router --------------------------- */
views.freemodels = async () => {
  renderShell();
  const content = $('#content');
  const toggleBtn = el('button', {
    class: 'btn sm ' + (S.freeOnly ? 'primary' : 'ghost'),
    onclick: () => { toggleFreeOnly(); go('freemodels'); },
  }, S.freeOnly ? '⛁ Free-only: ON' : '⛁ Free-only: off');

  content.append(pageHead('Free Tier Router',
    'Route every agent, worker and swarm through providers with a permanent free API tier. $0 per token, no credit card.', [
    toggleBtn,
    el('button', { class: 'btn sm', onclick: (e) => runFreeTest(e.currentTarget) }, '⚡ Test all'),
    el('button', { class: 'btn sm ghost', onclick: (e) => discoverFree(e.currentTarget) }, '⟳ Discover models'),
  ]));

  const box = el('div', { class: 'card' });
  content.append(box);

  const addKey = (p) => modal(`Connect ${p.label}`, [
    { name: 'value', label: 'API key', type: 'password', placeholder: p.envKeys?.[0] || 'key' },
    ...(p.accountEnvKey ? [{ name: 'account', label: 'Account ID', placeholder: p.accountEnvKey }] : []),
  ], async (b) => {
    await api('/api/v1/secrets', { method: 'POST', body: { name: `provider.${p.id}`, provider: p.id, value: b.value } });
    if (b.account && p.accountEnvKey) {
      await api('/api/v1/secrets', { method: 'POST', body: { name: p.accountEnvKey, provider: p.id, value: b.account } });
    }
    toast(`${p.label} connected`, 'ok');
    go('freemodels');
  }, 'Connect');

  await loadInto(box, () => api('/api/v1/router/free'), (d) => {
    const s = d.summary || {};
    const cards = d.providers.map((p) => el('div', { class: 'stat', style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
      el('div', { class: 'spread' },
        el('span', {}, p.label),
        el('span', { class: 'pill ' + (p.configured ? 'green' : '') }, p.configured ? 'READY' : 'NO KEY')),
      el('b', { style: { fontSize: '13px' } }, p.defaultModel || '—'),
      el('small', {}, (p.rateLimit && (p.rateLimit.rpm ? `${p.rateLimit.rpm} req/min` : (p.rateLimit.tpd ? `${(p.rateLimit.tpd / 1000).toFixed(0)}k tokens/day` : 'free tier'))) + (p.kind === 'local' ? ' · local, unlimited' : '')),
      el('div', { class: 'row', style: { marginTop: 'auto' } },
        el('button', { class: 'btn sm', onclick: () => addKey(p) }, p.configured ? 'Update key' : '＋ Add key'),
        el('button', { class: 'btn sm ghost', onclick: async (e) => {
          const btn = e.currentTarget; btn.disabled = true; btn.textContent = '…';
          try { const r = await api('/api/v1/router/free/test', { method: 'POST', body: { provider: p.id } });
            const res = r.results[0];
            btn.disabled = false; btn.textContent = 'Test';
            toast(res.ok ? `${p.label} OK · ${res.latencyMs}ms · "${res.reply}"` : `${p.label}: ${res.error}`, res.ok ? 'ok' : 'err');
          } catch (err) { btn.disabled = false; btn.textContent = 'Test'; toast(err.message, 'err'); }
        } }, 'Test'),
        p.signup ? el('a', { class: 'btn sm ghost', href: p.signup, target: '_blank', rel: 'noopener' }, 'Get key') : null,
      ),
      el('div', { class: 'tiny dim' }, p.rateLimit?.note || ''),
    ));

    const modelRows = d.models.slice(0, 60).map((m) => el('tr', {},
      el('td', {}, m.provider),
      el('td', {}, m.model_id),
      el('td', {}, String(m.quality)),
      el('td', {}, String(m.context_window ? Math.round(m.context_window / 1000) + 'k' : '—')),
      el('td', {}, m.configured ? el('span', { class: 'pill green' }, 'ready') : el('span', { class: 'pill' }, 'no key'))));

    return el('div', {},
      el('div', { class: 'grid g4', style: { marginBottom: '16px' } },
        stat('Providers ready', `${s.providersConfigured}/${s.providers}`, `${s.providers} free-forever providers`),
        stat('Free models', s.modelsConfigured || 0, `of ${s.models} registered`),
        stat('Cost / 1M tokens', '$0.00', 'free tier forever'),
        stat('Free Tier Brain', s.ready ? 'READY' : 'LOCAL', s.ready ? 'dual-brain, free models only' : 'add a key to activate')),
      el('div', { class: 'card', style: { background: 'transparent', border: 'none', padding: 0, marginBottom: '16px' } },
        el('div', { class: 'grid g3' }, ...cards)),
      el('div', { class: 'spread', style: { margin: '6px 0 12px' } },
        el('h3', {}, 'Free models registered'),
        el('span', { class: 'pill purple' }, 'Free Tier Brain')),
      el('table', { class: 'tbl' },
        el('thead', {}, el('tr', {}, ...['Provider', 'Model', 'Quality', 'Context', 'Status'].map((h) => el('th', {}, h)))),
        el('tbody', {}, ...(modelRows.length ? modelRows : [el('tr', {}, el('td', { colspan: 5 }, 'No free models registered.'))]))),
      el('div', { class: 'tiny dim', style: { marginTop: '14px' } }, d.note || ''),
    );
  });
};

async function runFreeTest(btn) {
  btn.disabled = true; const old = btn.textContent; btn.textContent = '⚡ Testing…';
  try {
    const r = await api('/api/v1/router/free/test', { method: 'POST', body: {} });
    const lines = r.results.map((x) => `${x.ok ? '✓' : '✗'} ${x.provider}${x.ok ? ` · ${x.latencyMs}ms` : ` · ${x.error}`}`).join('\n');
    btn.disabled = false; btn.textContent = old;
    showJson(`Free tier test — ${r.ok}/${r.tested} ready`, { summary: `${r.ok} of ${r.tested} responded`, results: r.results });
    toast(`${r.ok}/${r.tested} free providers responded`, r.ok ? 'ok' : 'err');
    void lines;
  } catch (e) { btn.disabled = false; btn.textContent = old; toast(e.message, 'err'); }
}

async function discoverFree(btn) {
  btn.disabled = true; const old = btn.textContent; btn.textContent = '⟳ Discovering…';
  try {
    const r = await api('/api/v1/router/free/discover', { method: 'POST', body: {} });
    btn.disabled = false; btn.textContent = old;
    const live = r.discovered.filter((x) => x.discovered).length;
    showJson('Live model discovery', r.discovered);
    toast(`${live} provider(s) returned live free-model lists`, live ? 'ok' : 'err');
  } catch (e) { btn.disabled = false; btn.textContent = old; toast(e.message, 'err'); }
}
views.brains = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Brain Profiles', 'Named reasoning profiles and their model wiring.'));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/brain-profiles'), (d) => el('div', { class: 'list' },
    ...d.profiles.map((b) => el('div', { class: 'item', onclick: () => showJson(b.name, b) },
      el('div', { class: 't' }, el('b', {}, b.name), el('small', {}, `${b.mode} · ${(b.models || []).map((m) => m.model_id).join(', ') || 'no models wired'}`)),
      el('span', { class: 'pill purple' }, b.mode)))));
};

views.plugins = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Plugin Hub', 'Microsoft, Google, GitHub, Stripe, AWS and custom connectors.', [
    el('button', { class: 'btn primary', onclick: () => modal('Connect plugin', [
      { name: 'provider', label: 'Provider', type: 'select', options: ['microsoft', 'google', 'github', 'gitlab', 'stripe', 'paypal', 'shopify', 'supabase', 'azure', 'aws', 'cloudflare', 'social', 'creative', 'database', 'custom'] },
      { name: 'name', label: 'Display name' }, { name: 'config', label: 'Config JSON', type: 'json', value: '{"baseUrl":""}' },
    ], async (b) => { await api('/api/v1/plugins/connect', { method: 'POST', body: { provider: b.provider, name: b.name, config: safeParse(b.config) } }); go('plugins'); }) }, '＋ Connect'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/plugins'), (d) => el('div', {},
    el('div', { class: 'list', style: { marginBottom: '16px' } }, ...(d.plugins?.length ? d.plugins.map((p) => el('div', { class: 'item' },
      el('div', { class: 't' }, el('b', {}, p.name), el('small', {}, `${p.provider} · ${p.last_test_ok ? 'tested ok' : 'untested'}`)),
      el('button', { class: 'btn sm', onclick: async (e) => { e.stopPropagation(); const r = await api('/api/v1/plugins/test', { method: 'POST', body: { id: p.id } }); toast(r.detail, r.ok ? 'ok' : 'err'); } }, 'Test'),
      statusPill(p.status))) : [el('div', { class: 'empty' }, 'No plugins connected.')])),
    el('h3', { style: { marginBottom: '10px' } }, 'Catalog'),
    el('div', { class: 'row' }, ...d.catalog.map((p) => el('span', { class: 'pill' }, p.label)))));
};

views.connectors = crudView({
  title: 'Connectors', sub: 'REST, GraphQL, database, local app and internal service connectors.', endpoint: '/api/v1/connectors', key: 'connectors',
  createLabel: 'Connector', createFields: [{ name: 'name', label: 'Name' }, { name: 'kind', label: 'Kind', type: 'select', options: ['REST', 'GraphQL', 'Database', 'Local', 'Internal'] }, { name: 'baseUrl', label: 'Base URL', placeholder: 'https://api.example.com' }],
  columns: [(x) => x.kind, (x) => x.base_url],
});

views.workflows = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Workflows', 'Pipelines, scheduled tasks, agent chains and business processes.', [
    el('button', { class: 'btn primary', onclick: () => modal('New workflow', [
      { name: 'name', label: 'Name' }, { name: 'description', label: 'Description' },
      { name: 'definition', label: 'Definition JSON', type: 'json', value: '{"steps":[{"name":"Research","op":"agent","prompt":"Research the topic"}]}' },
    ], async (b) => { await api('/api/v1/workflows', { method: 'POST', body: { name: b.name, description: b.description, definition: safeParse(b.definition) } }); go('workflows'); }) }, '＋ New'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/workflows'), (d) => el('div', { class: 'list' },
    ...(d.workflows?.length ? d.workflows.map((w) => el('div', { class: 'item' },
      el('div', { class: 't' }, el('b', {}, w.name), el('small', {}, `${(w.definition?.steps || []).length} steps · ${w.status}`)),
      el('button', { class: 'btn sm primary', onclick: async (e) => { e.stopPropagation(); try { const r = await api(`/api/v1/workflows/${w.id}/run`, { method: 'POST' }); toast('Workflow running', 'ok'); } catch (err) { toast(err.message, 'err'); } } }, '▶ Run'))) : [el('div', { class: 'empty' }, 'No workflows yet.')])));
};

views.automations = crudView({
  title: 'Automations', sub: 'Cron-scheduled and triggered workflows.', endpoint: '/api/v1/automations', key: 'automations',
  createLabel: 'Automation', createFields: [
    { name: 'name', label: 'Name' }, { name: 'cron', label: 'Cron (5-field)', placeholder: '0 9 * * 1' },
  ],
  columns: [(a) => a.cron || 'manual', (a) => a.next_run_at ? 'next ' + ago(a.next_run_at) : ''],
});

views.assets = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Asset Vault', 'Apps, code, images, video, audio, documents, comics, books, characters and datasets.'));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/assets'), (d) => el('div', { class: 'list' },
    ...(d.assets?.length ? d.assets.map((a) => el('div', { class: 'item', onclick: async () => { try { showJson(a.name, await api('/api/v1/assets/' + a.id)); } catch (e) { toast(e.message, 'err'); } } },
      el('div', { class: 't' }, el('b', {}, a.name), el('small', {}, `${a.asset_type} · ${bytes(a.size_bytes)} · ${ago(a.created_at)}`)), el('span', { class: 'pill' }, a.mime_type))) : [el('div', { class: 'empty' }, 'No assets yet — run a build.')])));
};

views.deployments = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Deployments', 'Web, mobile, desktop, docker, cloud and private-server targets.', [
    el('button', { class: 'btn sm', onclick: async () => { await api('/api/v1/deploy/web', { method: 'POST', body: {} }); go('deployments'); } }, '⏏ Web'),
    el('button', { class: 'btn sm', onclick: async () => { await api('/api/v1/deploy/mobile', { method: 'POST', body: {} }); go('deployments'); } }, '⏏ Mobile'),
    el('button', { class: 'btn sm', onclick: async () => { await api('/api/v1/deploy/desktop', { method: 'POST', body: {} }); go('deployments'); } }, '⏏ Desktop'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/deployments'), (d) => el('div', { class: 'list' },
    ...(d.deployments?.length ? d.deployments.map((dep) => el('div', { class: 'item', onclick: () => showJson('Deployment', dep) },
      el('div', { class: 't' }, el('b', {}, `${dep.target} · v${dep.version}`), el('small', {}, `${dep.environment} · ${ago(dep.created_at)}`)), statusPill(dep.status))) : [el('div', { class: 'empty' }, 'No deployments yet.')])));
};

/* ---------------------------- observatory ------------------------------- */
views.observatory = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Observatory', 'Real persisted system telemetry — models, agents, jobs, cost and performance.', [
    el('button', { class: 'btn sm ghost', onclick: () => go('observatory') }, '⟳ Refresh'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/observatory'), (o) => el('div', {},
    el('div', { class: 'grid g4', style: { marginBottom: '16px' } },
      stat('Jobs completed', o.jobs.byStatus.completed || 0, `${o.jobs.successRate}% success`),
      stat('Tokens', (o.jobs.totals.tokensIn + o.jobs.totals.tokensOut).toLocaleString(), `$${o.jobs.totals.cost.toFixed(4)} est. cost`),
      stat('Avg duration', `${o.jobs.avgDurationMs} ms`, `${o.jobs.byStatus.running || 0} running`),
      stat('Knowledge', o.knowledge.nodes, `${o.knowledge.memories} memories`)),
    el('div', { class: 'grid g2' },
      el('div', {}, el('h3', { style: { marginBottom: '10px' } }, 'Model usage'),
        el('table', { class: 'tbl' }, el('thead', {}, el('tr', {}, el('th', {}, 'Model'), el('th', {}, 'Runs'), el('th', {}, 'Tokens'))),
          el('tbody', {}, ...(o.models.usage.length ? o.models.usage.map((m) => el('tr', {}, el('td', {}, m.model), el('td', {}, String(m.n)), el('td', {}, String(m.tokens || 0)))) : [el('tr', {}, el('td', { colspan: 3 }, 'No model usage yet'))])))),
      el('div', {}, el('h3', { style: { marginBottom: '10px' } }, 'System'),
        el('div', { class: 'list' },
          kv('Node', o.system.node), kv('Uptime', `${o.system.uptimeSec}s`), kv('Memory', `${o.system.memoryMb} MB`),
          kv('SSE clients', String(o.events.total)), kv('Agents', String(o.agents.total)), kv('Workers', String(o.workers.total)),
          kv('Deployments', String(o.deployments.total)), kv('Assets', `${o.assets.total} (${bytes(o.assets.bytes)})`),
          kv('Configured providers', o.models.configured.join(', ') || 'local only')))),
    el('h3', { style: { margin: '18px 0 10px' } }, 'Activity (last 14 days)'),
    sparkline(o.daily)),
  );
};
function kv(k, v) { return el('div', { class: 'item', style: { cursor: 'default' } }, el('div', { class: 't' }, el('b', {}, v), el('small', {}, k))); }
function sparkline(rows) {
  if (!rows?.length) return el('div', { class: 'empty' }, 'No activity yet.');
  const max = Math.max(...rows.map((r) => r.n), 1);
  return el('div', { class: 'row', style: { alignItems: 'flex-end', gap: '6px', height: '120px' } },
    ...rows.map((r) => el('div', { style: { flex: '1', textAlign: 'center' } },
      el('div', { title: `${r.n} jobs`, style: { height: `${(r.n / max) * 90}px`, minHeight: '3px', background: 'linear-gradient(180deg,#6d8cff,#a56bff)', borderRadius: '5px' } }),
      el('div', { class: 'tiny dim' }, r.d.slice(5)))));
}

views.recovery = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Recovery Center', 'Failed jobs, workflows and deployments — retry and recover.', [
    el('button', { class: 'btn primary', onclick: async () => { try { const r = await api('/api/v1/recovery/retry', { method: 'POST', body: {} }); toast(`Recovered ${r.recovered.length} job(s)`, 'ok'); go('recovery'); } catch (e) { toast(e.message, 'err'); } } }, '⚕ Recover all'),
  ]));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => api('/api/v1/recovery'), (d) => el('div', {},
    el('h3', { style: { marginBottom: '10px' } }, `Failed jobs (${d.failed.length})`),
    el('div', { class: 'list', style: { marginBottom: '16px' } }, ...(d.failed.length ? d.failed.map((j) => el('div', { class: 'item' },
      el('div', { class: 't' }, el('b', {}, j.name), el('small', {}, j.error || j.status)),
      el('button', { class: 'btn sm', onclick: async (e) => { e.stopPropagation(); await api('/api/v1/recovery/retry', { method: 'POST', body: { jobId: j.id } }); toast('Requeued', 'ok'); go('recovery'); } }, 'Retry'))) : [el('div', { class: 'empty' }, 'No failures.')]))));
};

/* ------------------------------ security -------------------------------- */
views.security = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Security Center', 'JWT · refresh tokens · MFA · RBAC · tenant isolation · audit · secrets.'));
  const box = el('div', { class: 'card' }); content.append(box);
  const loader = () => Promise.all([
    api('/api/v1/security/overview'), api('/api/v1/security/audit'),
    api('/api/v1/secrets'), api('/api/v1/api-keys'),
  ]).then(([o, a, s, k]) => ({ o, a, s, k }));

  const secretForm = () => modal('Store provider secret', [
    { name: 'name', label: 'Name', placeholder: 'provider.deepseek' },
    { name: 'provider', label: 'Provider', type: 'select', options: ['deepseek', 'mistral', 'qwen', 'grok', 'ollama', 'generic'] },
    { name: 'value', label: 'Secret value', type: 'password' },
  ], async (b) => { await api('/api/v1/secrets', { method: 'POST', body: b }); go('security'); });

  const keyForm = () => modal('Create API key', [{ name: 'name', label: 'Name' }], async (b) => {
    const r = await api('/api/v1/api-keys', { method: 'POST', body: b });
    showJson('API key (copy now — shown once)', r.key); go('security');
  });

  const render = (d) => {
    const secrets = (d.s.secrets || []).map((s) => el('div', { class: 'item' },
      el('div', { class: 't' }, el('b', {}, s.name), el('small', {}, `${s.provider} · ${s.hint}`)),
      el('button', { class: 'btn sm danger', onclick: async (e) => { e.stopPropagation(); await api('/api/v1/secrets/' + s.id, { method: 'DELETE' }); go('security'); } }, 'Delete')));
    const keys = (d.k.keys || []).map((k) => el('div', { class: 'item' },
      el('div', { class: 't' }, el('b', {}, k.name), el('small', {}, `${k.prefix}… · ${k.last_used_at ? 'used ' + ago(k.last_used_at) : 'unused'}`)),
      el('button', { class: 'btn sm danger', onclick: async (e) => { e.stopPropagation(); await api('/api/v1/api-keys/' + k.id, { method: 'DELETE' }); go('security'); } }, 'Revoke')));
    const auditRows = (d.a.logs || []).slice(0, 40).map((l) => el('tr', {},
      el('td', {}, l.action), el('td', {}, l.entity), el('td', {}, ago(l.created_at))));
    return el('div', {},
      el('div', { class: 'grid g4', style: { marginBottom: '16px' } },
        stat('Users', d.o.users, `${d.o.activeSessions} sessions`),
        stat('API keys', d.o.apiKeys, `${d.o.secrets} secrets`),
        stat('Roles', d.o.roles.length, 'RBAC'),
        stat('Permissions', d.o.permissions.length, 'enforced')),
      el('div', { class: 'row', style: { marginBottom: '14px' } },
        el('span', { class: 'pill green' }, 'RLS: ' + d.o.rls.mechanism),
        el('span', { class: 'pill' }, 'Roles: ' + d.o.roles.join(', '))),
      el('div', { class: 'grid g2' },
        el('div', {},
          el('div', { class: 'spread', style: { marginBottom: '10px' } }, el('h3', {}, 'Secrets Vault'),
            el('button', { class: 'btn sm primary', onclick: secretForm }, '＋ Add')),
          el('div', { class: 'list' }, ...(secrets.length ? secrets : [el('div', { class: 'empty' }, 'No secrets stored.')]))),
        el('div', {},
          el('div', { class: 'spread', style: { marginBottom: '10px' } }, el('h3', {}, 'API Keys'),
            el('button', { class: 'btn sm primary', onclick: keyForm }, '＋ Create')),
          el('div', { class: 'list' }, ...(keys.length ? keys : [el('div', { class: 'empty' }, 'No API keys.')])))),
      el('h3', { style: { margin: '18px 0 10px' } }, 'Audit log'),
      el('table', { class: 'tbl' },
        el('thead', {}, el('tr', {}, el('th', {}, 'Action'), el('th', {}, 'Entity'), el('th', {}, 'When'))),
        el('tbody', {}, ...(auditRows.length ? auditRows : [el('tr', {}, el('td', { colspan: 3 }, 'No audit entries'))]))));
  };

  await loadInto(box, loader, render);
};
/* ------------------------------ settings -------------------------------- */
views.settings = async () => {
  renderShell();
  const content = $('#content');
  content.append(pageHead('Settings', 'Account, MFA, jobs and platform configuration.'));
  const box = el('div', { class: 'card' }); content.append(box);
  await loadInto(box, () => Promise.all([api('/api/v1/auth/me'), api('/api/v1/jobs'), api('/api/v1/prompts'), api('/api/v1/skills')]).then(([me, jobs, prompts, skills]) => ({ me, jobs, prompts, skills })), (d) => el('div', {},
    el('div', { class: 'grid g2' },
      el('div', {}, el('h3', { style: { marginBottom: '10px' } }, 'Account'),
        el('div', { class: 'list' },
          kv('Email', d.me.user.email), kv('Name', d.me.user.displayName), kv('Tenant', d.me.tenant.name),
          kv('Roles', d.me.user.roles.join(', ')), kv('MFA', d.me.user.mfaEnabled ? 'enabled' : 'disabled'))),
      el('div', {}, el('h3', { style: { marginBottom: '10px' } }, 'MFA'),
        el('button', { class: 'btn', onclick: async () => {
          const r = await api('/api/v1/auth/mfa', { method: 'POST', body: { action: 'setup' } });
          showJson('Scan in your authenticator', { secret: r.secret, uri: r.otpauthUri });
          setTimeout(() => modal('Enable MFA', [{ name: 'totp', label: '6-digit code' }], async (b) => { await api('/api/v1/auth/mfa', { method: 'POST', body: { action: 'enable', totp: b.totp } }); toast('MFA enabled', 'ok'); }), 400);
        } }, d.me.user.mfaEnabled ? 'Reconfigure MFA' : 'Set up MFA'),
        d.me.user.mfaEnabled ? el('button', { class: 'btn danger', style: { marginTop: '10px' }, onclick: () => modal('Disable MFA', [{ name: 'totp', label: '6-digit code' }], async (b) => { await api('/api/v1/auth/mfa', { method: 'POST', body: { action: 'disable', totp: b.totp } }); toast('MFA disabled', 'ok'); }) }, 'Disable MFA') : null)),
    el('h3', { style: { margin: '18px 0 10px' } }, `Recent jobs (${d.jobs.jobs.length})`),
    el('div', { class: 'list' }, ...d.jobs.jobs.slice(0, 12).map(jobRow)),
    el('h3', { style: { margin: '18px 0 10px' } }, `System prompts (${d.prompts.prompts.length})`),
    el('div', { class: 'row' }, ...d.prompts.prompts.map((p) => el('span', { class: 'pill', onclick: () => showJson(p.name, p) }, p.name))),
    el('h3', { style: { margin: '18px 0 10px' } }, `Skills (${d.skills.skills.length})`),
    el('div', { class: 'row' }, ...d.skills.skills.map((s) => el('span', { class: 'pill purple' }, s.name))),
  ));
};

/* ------------------------------ realtime -------------------------------- */
function connectLive() {
  if (S.es || !S.accessToken) return;
  try {
    const es = new EventSource('/api/v1/events?token=' + encodeURIComponent(S.accessToken));
    S.es = es;
    es.onopen = () => { S.live = true; paintLive(); };
    es.onerror = () => { S.live = false; paintLive(); };
    const handle = (type) => (e) => {
      try {
        const d = JSON.parse(e.data);
        if (type === 'job') { toast(`${d.name || 'Job'} → ${d.status}`); const lj = $('#live-jobs'); if (lj && d.status) { } }
        if (type === 'build') toast(`Build ${d.status}${d.step ? ' · ' + d.step : ''}`);
        if (type === 'deployment') toast(`Deployment ${d.status}`);
      } catch { /* ignore */ }
    };
    ['job', 'build', 'workflow', 'deployment', 'recovery', 'workforce', 'notification'].forEach((t) => es.addEventListener(t, handle(t)));
  } catch { /* SSE unsupported */ }
}
function paintLive() {
  const dot = $('#live-dot'), txt = $('#live-txt');
  if (dot) dot.classList.toggle('on', S.live);
  if (txt) txt.textContent = S.live ? 'live' : 'offline';
}

/* ------------------------------- auth ----------------------------------- */
function renderLogin() {
  const app = $('#app');
  app.hidden = false;
  app.innerHTML = '';
  const email = el('input', { class: 'input', type: 'email', placeholder: 'chairman@universe.ai', value: localStorage.getItem('jru_last_email') || '' });
  const password = el('input', { class: 'input', type: 'password', placeholder: '••••••••' });
  const totp = el('input', { class: 'input', placeholder: 'MFA code (if enabled)' });
  const err = el('div', { class: 'tiny', style: { color: '#ffb3c0', minHeight: '16px' } });
  const form = el('form', { class: 'card', style: { maxWidth: '420px', width: '100%' } },
    el('div', { class: 'brand', style: { padding: '0 0 14px' } }, el('div', { class: 'brand-mark' }, '◈'),
      el('div', { class: 'brand-txt' }, "J-ROC'S ACTUAL", el('small', {}, 'AI UNIVERSE™'))),
    el('h3', { style: { marginBottom: '14px' } }, 'Sign in'),
    el('label', { class: 'field' }, el('label', {}, 'Email'), email),
    el('label', { class: 'field' }, el('label', {}, 'Password'), password),
    el('label', { class: 'field' }, el('label', {}, 'MFA (optional)'), totp),
    err,
    el('button', { class: 'btn primary block', type: 'submit' }, 'Enter the Universe'),
    el('div', { class: 'tiny dim', style: { marginTop: '12px', textAlign: 'center' } }, 'Private system · authorised access only'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    try {
      const r = await api('/api/v1/auth/login', { method: 'POST', body: { email: email.value, password: password.value, totp: totp.value || undefined } });
      localStorage.setItem('jru_last_email', email.value);
      setSession(r);
      startApp();
    } catch (e2) { err.textContent = e2.message; }
  });
  app.append(el('div', { style: { display: 'grid', placeItems: 'center', minHeight: '100dvh', padding: '20px' } }, form));
}

async function logout() {
  try { await api('/api/v1/auth/logout', { method: 'POST', body: { refreshToken: S.refreshToken } }); } catch { /* ignore */ }
  clearSession();
  renderLogin();
}

/* ------------------------------- start ---------------------------------- */
async function startApp() {
  $('#boot').hidden = true;
  $('#app').hidden = false;
  try {
    const me = await api('/api/v1/auth/me');
    S.user = me.user; S.tenant = me.tenant;
    localStorage.setItem('jru_user', JSON.stringify(S.user));
    localStorage.setItem('jru_tenant', JSON.stringify(S.tenant));
  } catch {
    clearSession();
    return renderLogin();
  }
  renderShell();
  connectLive();
  go(S.route && views[S.route] ? S.route : 'dashboard');
}

async function renderView(id) {
  const view = views[id];
  if (!view) { $('#content').innerHTML = ''; $('#content').append(el('div', { class: 'empty' }, 'Unknown section: ' + id)); return; }
  try { await view(); } catch (e) { toast(e.message, 'err'); }
}

window.addEventListener('hashchange', () => {
  const id = location.hash.replace(/^#\/?/, '') || 'dashboard';
  if (id !== S.route) { S.route = id; if (S.user) go(id); }
});
window.addEventListener('resize', () => { if (window.innerWidth > 960) $('#sidebar')?.classList.remove('open'); });

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});

(async function init() {
  if (!S.accessToken && !S.refreshToken) return renderLogin();
  if (S.accessToken && S.refreshToken) {
    const ok = await tryRefresh();
    if (!ok) return renderLogin();
  }
  startApp();
})();
