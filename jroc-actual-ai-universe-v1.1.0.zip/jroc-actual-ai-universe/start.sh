#!/usr/bin/env bash
# J-Roc's Actual AI Universe(TM) - launcher (macOS / Linux)
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required (>= 22.5). Install from https://nodejs.org" >&2
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Node.js 22.5+ required (found $(node -v))." >&2
  exit 1
fi

if [ ! -f .env ]; then
  echo "No .env found - creating one from .env.example with generated secrets."
  cp .env.example .env
  JWT=$(node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))")
  MK=$(node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))")
  # portable in-place edit
  node -e "const f='.env',fs=require('fs');let s=fs.readFileSync(f,'utf8');s=s.replace(/^JWT_SECRET=.*/m,'JWT_SECRET='+process.argv[1]).replace(/^MASTER_KEY=.*/m,'MASTER_KEY='+process.argv[2]);fs.writeFileSync(f,s)" "$JWT" "$MK"
  echo "Generated JWT_SECRET and MASTER_KEY."
  echo "Default login: chairman@universe.ai / changeme  (change it!)"
fi

echo "Starting J-Roc's Actual AI Universe(TM)..."
exec node server.js
