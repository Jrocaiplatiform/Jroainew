# Database

Engine: **SQLite** (`node:sqlite`, built into Node ≥ 22.5) — ACID, single-file, zero setup.
Target: **PostgreSQL + pgvector** — the schema below is written in a Postgres-compatible shape so it ports 1:1.

## Conventions

| Concept | SQLite | Postgres target |
|---|---|---|
| Primary keys | `TEXT` UUID | `UUID` (`uuid-ossp` / `gen_random_uuid()`) |
| JSON columns | `TEXT` (JSON string) | `JSONB` |
| Timestamps | `TEXT` ISO-8601 | `TIMESTAMPTZ` |
| Embeddings | `TEXT` JSON float array | `VECTOR(1536)` |
| Tenant scope | `tenant_id` + session + trigger | `tenant_id` + `current_setting('app.tenant_id')` + RLS policy |
| Encryption | AES-256-GCM (app layer) | `pgcrypto` + app-layer AES-256-GCM |

Every tenant-owned table carries `tenant_id` and is indexed on it. Foreign keys are enforced (`PRAGMA foreign_keys = ON`).

## Tables

### Identity & access
- **tenants** — the Universe instance; `id, name, slug, status, plan, settings`
- **users** — `tenant_id, email, display_name, password_hash (scrypt), status, mfa_enabled, mfa_secret, settings`
- **roles** — system roles (`tenant_id NULL`) and tenant roles; `name, description, is_system`
- **permissions** — `code, description`
- **role_permissions** — role ↔ permission join
- **user_roles** — user ↔ role join
- **sessions** — refresh tokens (`refresh_hash`, `expires_at`, `revoked`, `ip`, `user_agent`)
- **api_keys** — `prefix, key_hash (sha256), scopes, status, last_used_at`
- **secrets** — Secrets Vault; `name, provider, ciphertext (AES-256-GCM), hint, status`

### Projects & builds
- **projects** — `name, goal, status, priority, owner_id, metadata`
- **blueprints** — `project_id, output_type, architecture (JSON), requirements (JSON), tasks (JSON), status, version`
- **builds** — `project_id, blueprint_id, goal, output_type, priority, status, assigned_brain, plan (JSON), result (JSON), error`

### Workforce
- **agents** — `name, role, system_prompt, brain_profile, memory_scope, project_id, status, config`
- **workers** — `agent_id, department_id, name, role, skills (JSON), permissions (JSON), brain_profile, memory_scope, status, config`
- **teams** — `department_id, name, purpose, strategy, status, config`
- **team_members** — `team_id, member_type (agent|worker), member_id`
- **departments** — `name, mandate, status`
- **department_members** — `department_id, member_type, member_id`
- **swarms** — `project_id, name, objective, topology, status, config`
- **swarm_members** — `swarm_id, worker_id, role`

### Intelligence
- **brain_profiles** — `name, description, mode (single|dual|triple|consensus|rotating), strategy (JSON), is_system`
- **models** — `provider, name, model_id, base_url, kind, capabilities (JSON), context_window, cost_in, cost_out, speed, quality, enabled, free_tier, rate_limit (JSON), docs_url`
  - `free_tier = 1` marks a free-forever model; the router's `freeOnly` mode selects only these.
- **brain_models** — brain ↔ model wiring with `weight, ordinal`
- **router_rules** — `task_type, match_expr (JSON), target_provider, target_model_id, brain_profile_id, priority, enabled`
- **knowledge_nodes** — `category, title, content, source, project_id, parent_id, embedding (JSON/VECTOR(1536)), dim, metadata`
- **memories** — `scope, owner_type, owner_id, project_id, key, content, importance, embedding`
- **prompts** — `name, category, body, variables (JSON), version, is_system`
- **skills** — `name, description, category, spec (JSON), is_system`
- **agent_skills** / **worker_skills** — skill assignments with `level`

### Integration & automation
- **plugins** — `name, provider, category, status, config, last_tested_at, last_test_ok`
- **connectors** — `plugin_id, name, kind (REST|GraphQL|Database|Local|Internal), base_url, spec, status`
- **workflows** — `project_id, name, description, definition (JSON), status, version`
- **automations** — `trigger (JSON), workflow_id, cron, enabled, last_run_at, next_run_at`

### Output & operations
- **assets** — `project_id, job_id, name, asset_type, mime_type, file_path, content, size_bytes, checksum, version, metadata`
- **deployments** — `project_id, target, environment, version, status, endpoint, config`
- **deployment_events** — `deployment_id, event, detail`
- **jobs** — `project_id, workflow_id, agent_id, worker_id, parent_id, kind, name, payload, result, status, state_log, progress, attempts, max_attempts, error, brain, model, tokens_in, tokens_out, cost, duration_ms, started_at, finished_at`
- **audit_logs** — `entity, entity_id, action, user_id, metadata, ip`
- **notifications** — `user_id, level, title, body, read, metadata`

## Job states

`queued · planning · running · paused · completed · failed · cancelled · recovering`

Retry policy: a failed job is set to `recovering`, re-queued with exponential backoff (5s × attempt, capped at 30s), up to `max_attempts` (default 3), then `failed` and surfaced in the Recovery Center.

## Indexes

`tenant_id` on every tenant table; `status` on jobs/agents/projects/deployments; `(status, created_at)` for the job queue; `project_id` on builds/assets/jobs/blueprints; `created_at` on audit/notifications; `task_type, priority` on router rules; `(tenant_id, email)` unique on users; `key_hash` unique on api_keys.

## Row-level security

SQLite has no native RLS, so isolation is enforced at three layers:

1. `repo.js` refuses any operation on a tenant table without a `tenantId`, and always appends `WHERE tenant_id = ?`.
2. `repo.withTenant()` sets the session tenant in `_app_session` inside a transaction.
3. A trigger rejects any insert/update whose `tenant_id` ≠ the session tenant.

Postgres target:

```sql
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON projects
  USING (tenant_id = current_setting('app.tenant_id', true)::uuid)
  WITH CHECK (tenant_id = current_setting('app.tenant_id', true)::uuid);
```

## Seed data

Roles: `Chairman, Admin, Manager, Agent, Worker, User`.
Permissions: the 23 core codes (`platform.read`, `projects.write`, `security.admin`, …).
Brain profiles: `Executive, Coding, Research, Reasoning, Creative, Planning, Validation, Consensus`.
Models: DeepSeek (chat/reasoner), Mistral (large/small), Qwen (max/plus), Grok 2, Ollama — **plus 37 free-forever models** across 10 providers (OpenRouter, Groq, Google AI Studio, Cerebras, GitHub Models, Cloudflare Workers AI, Mistral free tier, Hugging Face, SambaNova, Ollama), all `cost_in = cost_out = 0` and `free_tier = 1`.
Brain profiles: also includes **Free Tier Brain** (`mode: dual`, `strategy.freeOnly: true`), wired to two models from each free provider.
Router rules: coding→DeepSeek, reasoning→DeepSeek, research→Mistral, planning→Mistral, creativity→Qwen, analysis→Grok, writing→Qwen.
Skills: 15 across Software, Research, Marketing, Design, Finance, Operations, Comics, Publishing, Video, Music, Games, Healthcare, Education, Legal, Sales.
Prompts: Intent Analysis, J-Roc Executive, Task Executor, Validation.
Plus a starter workflow **Universe Health Check** and a weekly automation.

## Migrations

`schema` is defined in `src/db.js` and applied idempotently on every boot (`CREATE TABLE IF NOT EXISTS`). Additive migrations for older databases run in `db.migrate()` — currently adding `models.free_tier`, `models.rate_limit` and `models.docs_url` when missing. Use `npm run migrate` to verify and print table counts, `npm run reset` to rebuild from scratch.
