# Architecture

J-Roc's Actual AI Universe™ is one integrated system. The spec's ~27 backend services are implemented as cohesive modules behind a single API Gateway process, each with its own responsibility, persistence and events — the boundaries are the same, the deployment footprint is one Node process plus SQLite so it runs anywhere.

## Service map

| Spec service | Implementation | Responsibility |
|---|---|---|
| API Gateway | `server.js` | Routing, auth, RBAC, rate limiting, structured errors, static/PWA, SSE |
| Identity Service | `src/auth.js` | Login, logout, refresh, MFA, sessions, users, RBAC, bootstrap |
| Universal Builder | `src/brain.js` (`createBuild`, `executeBuild`) | Goal → intent → blueprint → project → build → deployment |
| J-Roc AI | `src/brain.js` (`jrocChat`) | Executive assistant, advisor, planner — project-aware |
| Command Brain | `src/brain.js` + `src/jobs.js` | Orchestration, task distribution, monitoring, recovery |
| Knowledge Brain | `src/knowledge.js` | RAG, embeddings, vector/hybrid search, knowledge graph, memory |
| Workforce / Agent / Worker / Team / Swarm / Department | `src/workforce.js` | Builders + agent execution |
| Model Router | `src/router.js` | single/dual/triple/consensus/rotating, DB-driven rules, free-only mode, failover |
| Free Tier Router | `src/freemodels.js` + `src/router.js` | 10 free-forever providers, live key test + model discovery, $0 routing |
| Brain Service | `src/router.js` + `brain_profiles` | Named brain profiles and model wiring |
| Prompt OS | `prompts` table + seed | Versioned system prompts |
| Blueprint Service | `blueprints` table | Architecture, requirements, tasks |
| Workflow Service | `src/workflow.js` | JSON workflows, pipelines, scheduled tasks |
| Automation Service | `src/workflow.js` | 5-field cron automations, 60s scheduler tick |
| Plugin / Connector Service | `src/api.js` + `src/vault.js` | Catalog, connect/test, custom connectors, live invocation |
| Asset Vault | `assets` table | Versioned, checksummed artifacts |
| Deployment Service | `src/api.js` | web/mobile/desktop/docker/cloud/private + events |
| Observatory | `/api/v1/observatory` | Real persisted telemetry |
| Recovery Service | `src/jobs.js` (`recover`) | Retry, recovery events |
| Security Service | `src/crypto.js`, `src/vault.js` | JWT, MFA, RBAC, RLS, secrets, API keys, audit |
| Audit Service | `src/repo.js` (`audit`) | Immutable action trail |
| Real-time | `src/events.js` | SSE stream (SignalR-equivalent) |
| Background execution | `src/jobs.js` | Persisted queue (Hangfire-equivalent), 8 states, retry |

## Request lifecycle

```
HTTP → server.js
  ├── security headers, CORS, rate limit
  ├── route match (method + path)
  ├── authenticate (JWT or X-API-Key)
  ├── authorize (permission required by route)
  ├── tenant scope (identity.tenantId) + vault lookup bound to tenant
  ├── handler (src/api.js) → repo/services
  └── structured JSON response  |  { error: { code, message, traceId } }
```

## Build execution (the core chain)

```
POST /api/v1/builder/build { goal }
  → brain.createBuild()
      ├── router.route(Planning Brain, json)  → intent/requirements/architecture/tasks
      ├── projects + blueprints + builds persisted
      └── audit + notification + event
  → jobs.enqueue(build job)              [background, real-time status]
      → brain.executeBuild()
          1. workforce.provisionWorkforce()   agents + workers + team + department + swarm
          2. knowledge.contextFor()           grounding
          3. per task: jobs.createJob('task') → workforce.runAgent()
                 ├── knowledge.contextFor + recall      (Knowledge Brain)
                 ├── router.route(brainProfile)         (Model Router)
                 └── assets.insert()                    (Asset Vault)
          4. Validation Brain pass
          5. deployments.insert() + deployment_events
          6. builds/projects/blueprints finalised, memory written, audit, notify, event
```

## Multi-model router

- **Modes:** `single`, `dual` (2 models), `triple` (3), `consensus` (3 + synthesis), `rotating` (round-robin cursor).
- **Selection order:** DB `router_rules` (task type, priority) → brain-profile model wiring → ranking.
- **Ranking inputs:** quality, speed, cost, capability breadth, and the request priority.
- **Provider abstraction:** all providers speak OpenAI-compatible chat completions, so one transport serves DeepSeek, Mistral, Qwen (DashScope compatible-mode), Grok (xAI), Ollama, every free-tier provider, and any custom endpoint.
- **Degradation:** a missing key or unreachable endpoint falls back to the Local Heuristic Brain and is flagged `degraded: true` everywhere.

## Free Tier Router

`src/freemodels.js` holds the registry of providers with a permanent, no-credit-card free API tier:

`openrouter · groq · gemini (Google AI Studio) · cerebras · github (GitHub Models) · cloudflare (Workers AI) · mistralfree · huggingface · sambanova · ollama (local)`

- **Key resolution:** tenant Secrets Vault (`provider.<id>`) → environment variable. Ollama needs none.
- **`freeOnly` flag:** threaded from the API through `brain.createBuild` → `analyzeIntent` → `jobs` payload → `executeBuild` → `workforce.runAgent` → `router.route`. When set, `router.selectModel` bypasses paid routing rules and ranks only `models.free_tier = 1`; `selectBrainModels` forces the **Free Tier Brain**.
- **Free Tier Brain:** a system brain profile (`mode: dual`, `strategy.freeOnly: true`) wired to two models from each free provider.
- **Cost accounting:** `workforce.estimateCost` returns `0` for any free-tier model, for `freeOnly` runs, and for the local brain, so the Observatory's cost is truthful.
- **Failover:** on a degraded provider result the router retries up to two alternative configured models from the same (free or paid) pool before falling back locally.
- **Discovery:** `providers.discoverModels` calls each provider's `/models` endpoint (public for OpenRouter and Ollama) and returns the current free-model list; free IDs rotate over time.
- **Live test:** `providers.testProvider` issues a real 16-token completion and reports measured latency and status — the UI's **Test all** shows measured truth, never an assumption.

## Tenant isolation (RLS-equivalent)

1. **Session tenant** — the repository sets `_app_session.tenant_id` for the duration of a tenant-scoped transaction.
2. **Repository guard** — `repo.js` refuses any read/write on a tenant table unless a `tenantId` is supplied, and always injects `WHERE tenant_id = ?`.
3. **Trigger guard** — a database trigger rejects any write whose `tenant_id` differs from the active session tenant.

In the Postgres target this maps to `current_setting('app.tenant_id')` + `CREATE POLICY` on every tenant table (see `docs/DATABASE.md`).

## Real-time

`GET /api/v1/events` (SSE, `Authorization` header or `?token=`) streams typed events: `job`, `build`, `workflow`, `deployment`, `recovery`, `workforce`, `notification`. The PWA subscribes once and updates live — no polling.

## Offline

The PWA ships an app-shell service worker (`public/sw.js`) with an offline fallback. API calls are always network-first so persisted data is never shown stale. Client-side session state (tokens, user, tenant) is cached in `localStorage`.

## Postgres migration path

The schema is written Postgres-compatible: `TEXT` UUID PKs, `TEXT` JSON (JSONB), ISO-8601 `TEXT` timestamps (TIMESTAMPTZ), and embeddings stored as JSON float arrays (`VECTOR(1536)`). To migrate: replace `src/db.js` with `pg` + the same DDL, swap `node:sqlite` calls for `pg` queries, and enable RLS policies. No domain logic changes.
