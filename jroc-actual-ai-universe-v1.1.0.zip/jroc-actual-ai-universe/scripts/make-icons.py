#!/usr/bin/env python3
"""Generate the PWA launcher icons (192 + 512) for J-Roc's Actual AI Universe."""
import math
import os

from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "..", "public")


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient(size, stops):
    """Vertical-ish diagonal gradient between colour stops."""
    img = Image.new("RGB", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = (x / size * 0.5 + y / size * 0.5)
            seg = min(int(t * (len(stops) - 1)), len(stops) - 2)
            local = t * (len(stops) - 1) - seg
            px[x, y] = lerp(stops[seg], stops[seg + 1], local)
    return img


def rounded_mask(size, radius):
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return m


def make(size):
    scale = size / 512
    base = Image.new("RGBA", (size, size), (5, 6, 15, 255))
    d = ImageDraw.Draw(base, "RGBA")

    # glow
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    for r in range(int(230 * scale), 0, -6):
        alpha = int(60 * (1 - r / (230 * scale)) ** 1.6)
        gd.ellipse([size / 2 - r, size / 2 - r, size / 2 + r, size / 2 + r], fill=(165, 107, 255, alpha))
    base = Image.alpha_composite(base, glow)
    d = ImageDraw.Draw(base, "RGBA")

    # orbital rings
    ring = Image.new("RGBA", (size * 2, size * 2), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    for ang in (0, 60, 120):
        ell = Image.new("RGBA", (size * 2, size * 2), (0, 0, 0, 0))
        ed = ImageDraw.Draw(ell)
        ed.ellipse([size * 2 / 2 - 170 * scale, size * 2 / 2 - 66 * scale,
                    size * 2 / 2 + 170 * scale, size * 2 / 2 + 66 * scale],
                   outline=(109, 140, 255, 210), width=max(2, int(9 * scale)))
        ell = ell.rotate(ang, resample=Image.BICUBIC, center=(size, size))
        ring = Image.alpha_composite(ring, ell)
    ring = ring.crop((size // 2, size // 2, size // 2 + size, size // 2 + size))
    base = Image.alpha_composite(base, ring)
    d = ImageDraw.Draw(base, "RGBA")

    # core
    core_r = 52 * scale
    core = gradient(size, [(109, 140, 255), (165, 107, 255), (66, 232, 224)])
    cmask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(cmask).ellipse([size / 2 - core_r, size / 2 - core_r, size / 2 + core_r, size / 2 + core_r], fill=255)
    base.paste(core, (0, 0), cmask)
    d = ImageDraw.Draw(base, "RGBA")
    d.ellipse([size / 2 - core_r, size / 2 - core_r, size / 2 + core_r, size / 2 + core_r],
              outline=(5, 6, 15, 255), width=max(3, int(10 * scale)))

    # nodes
    for (nx, ny), col in (((256, 86), (66, 232, 224)), ((403, 341), (109, 140, 255)), ((109, 341), (165, 107, 255))):
        r = 15 * scale
        d.ellipse([nx * scale - r, ny * scale - r, nx * scale + r, ny * scale + r], fill=col + (255,))

    # rounded corners + flatten
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(base, (0, 0), rounded_mask(size, int(112 * scale)))
    return out


for size in (192, 512):
    icon = make(size)
    path = os.path.join(OUT, f"icon-{size}.png")
    icon.save(path, "PNG")
    print("wrote", path)
