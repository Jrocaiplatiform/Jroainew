#!/usr/bin/env node
'use strict';
/** reset.js - delete the SQLite database (and WAL/SHM) for a clean rebuild. */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../src/config');

if (config.DATABASE_FILE === ':memory:') {
  console.log('In-memory database — nothing to reset.');
  process.exit(0);
}
for (const suffix of ['', '-wal', '-shm']) {
  const f = config.DATABASE_FILE + suffix;
  if (fs.existsSync(f)) { fs.unlinkSync(f); console.log('removed', f); }
}
console.log('Reset complete. Run `npm start` to recreate and reseed.');
