#!/usr/bin/env node
'use strict';
/** migrate.js - create/verify the schema and seed data. Idempotent. */
const db = require('../src/db');
const config = require('../src/config');

const d = db.connect();
const tables = d.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all();
const counts = {};
for (const t of tables) {
  try { counts[t.name] = d.prepare(`SELECT COUNT(*) n FROM ${t.name}`).get().n; } catch { counts[t.name] = '-'; }
}
console.log(`Database: ${config.DATABASE_FILE}`);
console.log(`Tables (${tables.length}):`);
for (const t of tables) console.log(`  ${t.name.padEnd(28)} ${counts[t.name]}`);
console.log('\nMigration complete.');
